import rule_0 from 'bpmnlint/rules/conditional-flows';
import rule_1 from 'bpmnlint/rules/end-event-required';
import rule_2 from 'bpmnlint/rules/event-sub-process-typed-start-event';
import rule_3 from 'bpmnlint/rules/fake-join';
import rule_4 from 'bpmnlint/rules/label-required';
import rule_5 from 'bpmnlint/rules/no-complex-gateway';
import rule_6 from 'bpmnlint/rules/no-disconnected';
import rule_7 from 'bpmnlint/rules/no-duplicate-sequence-flows';
import rule_8 from 'bpmnlint/rules/no-gateway-join-fork';
import rule_9 from 'bpmnlint/rules/no-implicit-split';
import rule_10 from 'bpmnlint/rules/no-inclusive-gateway';
import rule_11 from 'bpmnlint/rules/single-blank-start-event';
import rule_12 from 'bpmnlint/rules/single-event-definition';
import rule_13 from 'bpmnlint/rules/start-event-required';
import rule_14 from 'bpmnlint/rules/sub-process-blank-start-event';
import rule_15 from 'bpmnlint/rules/superfluous-gateway';
// import rule_16 from 'bpmnlint-plugin-playground/rules/no-manual-task';
const { is } = require('bpmnlint-utils');
const rule_16 = function () {
  function check(node, reporter) {
    if (is(node, 'bpmn:ManualTask')) {
      reporter.report(node.id, 'Element has disallowed type bpmn:ManualTask');
    }
  }
  return {
    check: check,
  };
};
var cache = {};

/**
 * A resolver that caches rules and configuration as part of the bundle,
 * making them accessible in the browser.
 *
 * @param {Object} cache
 */
function Resolver() {}

Resolver.prototype.resolveRule = function (pkg, ruleName) {
  const rule = cache[pkg + '/' + ruleName];

  if (!rule) {
    throw new Error('cannot resolve rule <' + pkg + '/' + ruleName + '>');
  }

  return rule;
};

Resolver.prototype.resolveConfig = function (pkg, configName) {
  throw new Error(
    'cannot resolve config <' + configName + '> in <' + pkg + '>',
  );
};

var resolver = new Resolver();

var rules = {
  'conditional-flows': 'error',
  'end-event-required': 'error',
  'event-sub-process-typed-start-event': 'error',
  'fake-join': 'warn',
  'label-required': 'error',
  'no-complex-gateway': 'error',
  'no-disconnected': 'error',
  'no-duplicate-sequence-flows': 'error',
  'no-gateway-join-fork': 'error',
  'no-implicit-split': 'error',
  'no-inclusive-gateway': 'error',
  'single-blank-start-event': 'error',
  'single-event-definition': 'error',
  'start-event-required': 'error',
  'sub-process-blank-start-event': 'error',
  'superfluous-gateway': 'warning',
  'playground/no-manual-task': 'warn',
};

var config = {
  rules: rules,
};

var bundle = {
  resolver: resolver,
  config: config,
};
cache['bpmnlint/conditional-flows'] = rule_0;
cache['bpmnlint/end-event-required'] = rule_1;
cache['bpmnlint/event-sub-process-typed-start-event'] = rule_2;
cache['bpmnlint/fake-join'] = rule_3;
cache['bpmnlint/label-required'] = rule_4;
cache['bpmnlint/no-complex-gateway'] = rule_5;
cache['bpmnlint/no-disconnected'] = rule_6;
cache['bpmnlint/no-duplicate-sequence-flows'] = rule_7;
cache['bpmnlint/no-gateway-join-fork'] = rule_8;
cache['bpmnlint/no-implicit-split'] = rule_9;
cache['bpmnlint/no-inclusive-gateway'] = rule_10;
cache['bpmnlint/single-blank-start-event'] = rule_11;
cache['bpmnlint/single-event-definition'] = rule_12;
cache['bpmnlint/start-event-required'] = rule_13;
cache['bpmnlint/sub-process-blank-start-event'] = rule_14;
cache['bpmnlint/superfluous-gateway'] = rule_15;
cache['bpmnlint-plugin-playground/no-manual-task'] = rule_16;

export default bundle;
export { config, resolver };
