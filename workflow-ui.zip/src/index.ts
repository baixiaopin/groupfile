// @ts-nocheck

// import 'antd/dist/antd.css';
import '@ngfed/fc-components/dist/ngfed.min.css';

// 模型
export { default as ModelType } from './pages/ModelType';
export { default as ModelManage } from './pages/ModelManage';
// export { default as ModelDesigner } from './pages/ModelDesigner';
export { default as ModelViewer } from './pages/ModelViewer';
// 流程
export { default as ProcessInstance } from './pages/ProcessInstance';
export { default as ProcessTask } from './pages/ProcessTask';
// export { default as HistoryProcess } from './pages/HistoryProcess';

// 流程追踪查看
export { default as ProcessViewerModel } from './pages/ProcessViewerModel';
// 历史流程实例
export { default as HistoryProcessInstance } from './pages/HistoryProcessInstance';
// 历史任务
export { default as HistoryTask } from './pages/HistoryTask';
// 组织架构树
export { default as OrgTree } from './pages/OrgTree';
// 授权待办
export { default as AuthorizedToDo } from './pages/AuthorizedToDo';
// 下一个节点
export { default as NextNode } from './pages/NextNode';
// 业务类型
export { default as BusinessesTypeManage } from './pages/BusinessesTypeManage';
// 业务模板
export { default as BusinessesTemplate } from './pages/BusinessesTemplate';
// 数据迁移
export { default as DataMigration } from './pages/DataMigration';
// 业务模型设计
export { default as BusinessesModelar } from './pages/BusinessesModelar';
export { default as BusinessesViewer } from './pages/BusinessViewer';
// 流程续跑
export { default as ProcessContinueRun } from './pages/ProcessContinueRun';
