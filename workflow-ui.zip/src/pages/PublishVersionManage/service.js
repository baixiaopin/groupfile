import request from '../../utils/request';

// 查询已发布版本
export function queryPublishedVersion(modelKey) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'queryLatestDefinitionByKey',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        appDefinitionKey: modelKey,
      },
    },
  });
}

// 删除已发布版本
export function deleteModelDefinition(modelDefineId) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'deleteModelDefinition',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        definitionId: modelDefineId,
      },
    },
  });
}

// 预览已发布版本（的模型）
export function previewPublishedVersion(modelKey) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'deleteModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        appDefinitionKey: modelKey,
      },
    },
  });
}
// 启动流程
export function startProcDefById(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'startProcDefById',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 流程实例的激活
export function activateModelDefinition(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'activateModelDefinition',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 流程实例的挂起
export function suspendModelDefinition(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'suspendModelDefinition',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
