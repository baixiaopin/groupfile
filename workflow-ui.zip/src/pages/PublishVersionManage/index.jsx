// @ts-nocheck
import React from 'react';
import {
  FcButton as Button,
  FcList as List,
  FcForm as Form,
  FcSelect as Select,
  FcInput as Input,
  FcRow as Row,
  FcCol as Col,
  FcModal as Modal,
  FcPopconfirm as Popconfirm,
  FcDrawer as Drawer,
  FcTable as Table,
  FcTooltip as Tooltip,
  FcMessage as message,
  FcDivider as Divider,
} from '@ngfed/fc-components';
import {
  queryPublishedVersion as apiQueryPublishedVersion,
  deleteModelDefinition as apiDeletePublishedVersion,
  startProcDefById,
  activateModelDefinition,
  suspendModelDefinition,
} from './service';
import ModelViewerNoReq from '../ModelViewerNoReq';

export default class PublishVersionManage extends React.Component {
  processVariables = React.createRef();
  state = {
    publishVersionList: [],
    xml: '',
    previewVisible: false,
    testVisible: false,
    testId: '',
    addTaskList: [],
    columns: [
      {
        title: '模型Key',
        dataIndex: 'key',

        ellipsis: {
          showTitle: false,
        },
        render: (key) => (
          <Tooltip placement="topLeft" title={key}>
            {key}
          </Tooltip>
        ),
      },
      {
        title: '模型名称',
        dataIndex: 'name',

        ellipsis: {
          showTitle: false,
        },
        render: (name) => (
          <Tooltip placement="topLeft" title={name}>
            {name}
          </Tooltip>
        ),
      },
      {
        title: '版本',
        dataIndex: 'version',

        ellipsis: {
          showTitle: false,
        },
        render: (name) => (
          <Tooltip placement="topLeft" title={name}>
            {name}
          </Tooltip>
        ),
      },
      {
        title: '描述',
        dataIndex: 'description',

        ellipsis: {
          showTitle: false,
        },
        render: (description) => (
          <Tooltip placement="topLeft" title={description}>
            {description}
          </Tooltip>
        ),
      },
      {
        title: '操作',
        dataIndex: 'action',

        width: 220,
        render: (text, record, index) => {
          return (
            <>
              <Popconfirm
                okText="是"
                cancelText="否"
                title="是否确认删除？"
                onConfirm={() => this.deletePublishedVersion(record)}
              >
                <a>删除</a>
              </Popconfirm>
              <Divider type="vertical"></Divider>
              <a onClick={() => this.openPreview(record)}>预览</a>

              <Divider type="vertical" style={{ margin: '0 6px' }} />
              <Popconfirm
                title={
                  record.suspended == true ? '是否要实例激活' : '是否要实例挂起'
                }
                onConfirm={() => {
                  this.suspended(record);
                }}
                onCancel={this.stopCancel}
                okText="确定"
                cancelText="取消"
              >
                <a>{record.suspended == true ? '激活' : '挂起'}</a>
              </Popconfirm>

              <Divider type="vertical"></Divider>
              <a onClick={() => this.test(record)}>调试流程</a>
            </>
          );
        },
      },
    ],
  };
  componentDidMount() {
    this.search();
  }
  search = () => {
    apiQueryPublishedVersion(this.props.modelKey).then((res) => {
      // console.log([res.body],res.body)
      if (res.body) {
        this.setState({
          publishVersionList:
            Array.isArray(res.body) == true ? res.body : [res.body],
        });
      }
    });
  };
  deletePublishedVersion = (record) => {
    apiDeletePublishedVersion(record.id).then((res) => {
      if (res.sysHead.retCd === '000000') {
        message.success('删除成功');
        this.search();
      }
    });
  };
  openPreview = (record) => {
    this.setState({
      previewVisible: true,
      xml: record.xml,
    });
  };
  closePreview = () => {
    this.setState({
      previewVisible: false,
    });
  };
  test = (e) => {
    this.setState({
      testId: e.id,
      testVisible: true,
    });
  };
  groupBy(arr, property) {
    return arr.reduce(function (memo, x) {
      if (!memo[x[property]]) {
        memo[x[property]] = [];
      }
      memo[x[property]].push(x);
      return memo;
    }, {});
  }
  testModalOk = async (e) => {
    try {
      const values = await this.processVariables.current.validateFields();
      let setting = this.processVariables.current.getFieldsValue();
      // 删除表单项名叫瞬时的值，如果直接在表单项中将其 value 设置成 "" 的话，则通不过表单非空校验
      for (const key in setting) {
        if (Object.prototype.hasOwnProperty.call(setting, key)) {
          if (key.includes('status') && setting[key] === 'shunshi') {
            setting[key] = '';
          }
        }
      }
      //  处理对象转化为数组并分类
      let arr = [];
      for (var key in setting) {
        let temp = {};
        temp.name = key;
        temp.value = setting[key];
        arr.push(temp);
      }
      let map = {};
      let dest = [];
      for (let i = 0; i < arr.length; i++) {
        let ai = arr[i];
        if (!map[ai.name.replace(/[^0-9]/gi, '')]) {
          dest.push({
            name: ai.name,
            value: ai.value,
            data: [ai],
          });
          map[ai.name.replace(/[^0-9]/gi, '')] = ai;
        } else {
          for (var j = 0; j < dest.length; j++) {
            let dj = dest[j];
            if (
              dj.name.replace(/[^0-9]/gi, '') == ai.name.replace(/[^0-9]/gi, '')
            ) {
              dj.data.push(ai);
              break;
            }
          }
        }
      }
      let newobj = {};
      // 将变量名设为key 变量值设为value
      dest.map((item, index) => {
        newobj[item.data[2].value] = item.data[3].value;
      });
      startProcDefById({
        definitionId: this.state.testId,
        variables: newobj,
      }).then((res) => {
        if (res.sysHead.retInf == '交易成功') {
          message.success('启动流程实例成功');
        }
        this.setState({ testVisible: false });
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };
  addTaskList = () => {
    const num = this.state.addTaskList;
    if (this.state.addTaskList.length == 0) {
      num.push(String(this.state.addTaskList.length));
    } else {
      num.push(String(Number(num[num.length - 1]) + 1));
    }
    this.setState({
      addTaskList: num,
    });
  };
  deletTaskAdd = (e) => {
    const addListTem = this.state.addTaskList;
    this.state.addTaskList.map((item, index) => {
      if (Number(item) == e) {
        addListTem.splice(index, 1);
        this.setState({ addTaskList: addListTem });
      }
    });
  };
  testModal = () => {
    this.setState({ testVisible: false, addTaskList: [] });
  };
  // 激活 挂起
  suspended = (e) => {
    // true 挂起转态
    if (e.suspended == true) {
      activateModelDefinition({
        definitionId: e.id,
      }).then((res) => {
        this.search();
        message.success('激活成功');
      });
    }
    // false 激活转态
    if (e.suspended == false) {
      suspendModelDefinition({
        definitionId: e.id,
      }).then((res) => {
        this.search();
        message.success('挂起成功');
      });
    }
  };
  stopCancel = (e) => {
    message.error('已取消');
  };
  render() {
    return (
      <>
        <Table
          dataSource={this.state.publishVersionList}
          rowKey={(record) => record.id}
          pagination={false}
          bordered
          columns={this.state.columns}
        ></Table>
        <Drawer
          title="预览"
          placement="top"
          visible={this.state.previewVisible}
          onClose={this.closePreview}
          width="100%"
          height="100%"
          footer={null}
        >
          {this.state.previewVisible && (
            <ModelViewerNoReq bpmnModelXml={this.state.xml} />
          )}
        </Drawer>

        {this.state.testVisible && (
          <Modal
            title="启动调试流程"
            visible={this.state.testVisible}
            okText="确认"
            cancelText="取消"
            width="50%"
            onOk={this.testModalOk}
            onCancel={this.testModal}
          >
            <Form
              labelAlign="center"
              layout="horizontal"
              ref={this.processVariables}
              style={{ marginLeft: 20 }}
            >
              <Form.Item
                label="流程名称"
                style={{ width: '80%', margin: '8px 0', textAlign: 'center' }}
              >
                <Input defaultValue="超级管理员发起的流程"></Input>
              </Form.Item>
              <Form.Item
                label="业务关联"
                style={{ width: '80%', margin: '8px 0', textAlign: 'center' }}
              >
                <Input defaultValue="无关联业务"></Input>
                <div>
                  <Button
                    style={{ float: 'left', marginTop: 10 }}
                    type="primary"
                    onClick={this.addTaskList}
                  >
                    添加
                  </Button>
                </div>
              </Form.Item>

              <Form.Item
                label="流程变量"
                style={{ width: '80%', margin: '8px 0', textAlign: 'center' }}
              >
                <List
                  header={
                    <Row style={{ width: '100%', padding: 0 }}>
                      <Col style={{ width: '20%', textAlign: 'center' }}>
                        范围
                      </Col>
                      <Col style={{ width: '20%', textAlign: 'center' }}>
                        类型
                      </Col>
                      <Col style={{ width: '20%', textAlign: 'center' }}>
                        变量名称
                      </Col>
                      <Col style={{ width: '20%', textAlign: 'center' }}>
                        变量值
                      </Col>
                      <Col style={{ width: '20%', textAlign: 'center' }}>
                        操作
                      </Col>
                    </Row>
                  }
                  bordered
                  dataSource={this.state.addTaskList}
                  renderItem={(item, index) => (
                    <List.Item style={{ padding: 0 }}>
                      <Row style={{ width: '100%' }}>
                        <Col style={{ width: '20%', textAlign: 'center' }}>
                          <Form.Item
                            name={'trya' + index}
                            style={{
                              margin: '8px 0',
                              textAlign: 'center',
                            }}
                            rules={[{ required: true, message: '请选择' }]}
                          >
                            <Select style={{ width: '90%' }}>
                              <Select.Option value="false">全局</Select.Option>
                              <Select.Option value="shunshi">
                                瞬时
                              </Select.Option>
                              <Select.Option value="true">任务</Select.Option>
                            </Select>
                          </Form.Item>
                        </Col>
                        <Col style={{ width: '20%', textAlign: 'center' }}>
                          <Form.Item
                            name={'try' + index}
                            style={{
                              margin: '8px 0',
                              textAlign: 'center',
                            }}
                            rules={[{ required: true, message: '请选择' }]}
                          >
                            <Select style={{ width: '90%' }}>
                              <Select.Option value="String">
                                String
                              </Select.Option>
                              <Select.Option value="Long">Long</Select.Option>
                              <Select.Option value="Integer">
                                Integer
                              </Select.Option>
                              <Select.Option value="Double">
                                Double
                              </Select.Option>
                              <Select.Option value="Boolean">
                                Boolean
                              </Select.Option>
                              <Select.Option value="Date">Date</Select.Option>
                            </Select>
                          </Form.Item>
                        </Col>
                        <Col style={{ width: '20%', textAlign: 'center' }}>
                          <Form.Item
                            style={{
                              margin: '8px 0',
                              textAlign: 'center',
                            }}
                            name={'name' + index}
                            style={{
                              margin: '8px 0',
                              textAlign: 'center',
                            }}
                            rules={[{ required: true, message: '请输入' }]}
                          >
                            <Input style={{ width: '90%' }}></Input>
                          </Form.Item>
                        </Col>
                        <Col style={{ width: '20%', textAlign: 'center' }}>
                          <Form.Item
                            name={'value' + index}
                            style={{
                              margin: '8px 0',
                              textAlign: 'center',
                            }}
                            rules={[{ required: true, message: '请输入' }]}
                          >
                            <Input style={{ width: '90%' }}></Input>
                          </Form.Item>
                        </Col>
                        <Col
                          style={{
                            width: '20%',
                            margin: '10px 0px',
                            textAlign: 'center',
                          }}
                        >
                          <a
                            onClick={() => {
                              this.deletTaskAdd(item);
                            }}
                          >
                            删除
                          </a>
                        </Col>
                      </Row>
                    </List.Item>
                  )}
                ></List>
              </Form.Item>
            </Form>
          </Modal>
        )}
      </>
    );
  }
}
