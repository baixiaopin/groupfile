import request from '../../utils/request';

// 查询历史模型
export function queryHistoryModels({ id }) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelVersionResSVC',
        stdIntfcInd: 'getHistoryModels',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
        includeNewVersion: false,
      },
    },
  });
}

// 发布为最新版本
export function setAsMasterVersion({ id, modelHistoryId }) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelVersionResSVC',
        stdIntfcInd: 'executeHistoryModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
        modelHistoryId,
      },
    },
  });
}

// 更新模型
export function updateModel({ id, key, name, modelType, description }) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'updateModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: { id, key, name, modelType, description },
    },
  });
}

// 发布模型，也叫部署模型
export function publishModel(record) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'deployModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        modelId: record.id,
      },
    },
  });
}

/**
 * 删除模型
 * @param {*} id
 */
export function deleteModel(id) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'deleteModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
      },
    },
  });
}
