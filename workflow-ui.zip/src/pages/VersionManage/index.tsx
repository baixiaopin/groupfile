// @ts-nocheck
import React from 'react';
import {
  FcPopconfirm as Popconfirm,
  FcDrawer as Drawer,
  FcTable as Table,
  FcTooltip as Tooltip,
  FcMessage as message,
  FcDivider as Divider,
} from '@ngfed/fc-components';
var modelType;
import ModelViewerHistory from '../ModelViewerHistory';

import {
  queryHistoryModels as apiQueryHistoryModes,
  setAsMasterVersion as apiSetAsMasterVersion,
} from './service';
import { getModelTypeOptions as apiQueryModelTypeOptions } from '../ModelType/service';
import Moment from 'moment';
class VersionManage extends React.Component {
  state = {
    histortModelList: [],
    modelTypeOptionList: [],
    modelPreviewVisible: false,
    currentModel: {},
    columns: [
      {
        title: 'key',

        dataIndex: 'key',
        ellipsis: {
          showTitle: false,
        },
        render: (key) => (
          <Tooltip placement="topLeft" title={key}>
            {key}
          </Tooltip>
        ),
      },
      {
        title: '名称',

        dataIndex: 'name',
        ellipsis: {
          showTitle: false,
        },
        render: (name) => (
          <Tooltip placement="topLeft" title={name}>
            {name}
          </Tooltip>
        ),
      },
      {
        title: '版本号',

        dataIndex: 'version',
        ellipsis: {
          showTitle: false,
        },
        render: (version) => (
          <Tooltip placement="topLeft" title={version}>
            {version}
          </Tooltip>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'created',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => (
          <Tooltip
            placement="topLeft"
            title={text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
          >
            {text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
          </Tooltip>
        ),
      },
      {
        title: '修改时间',
        dataIndex: 'lastUpdated',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => (
          <Tooltip
            placement="topLeft"
            title={text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
          >
            {text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
          </Tooltip>
        ),
      },

      {
        title: '描述',

        dataIndex: 'description',
        ellipsis: {
          showTitle: false,
        },
        render: (description) => (
          <Tooltip placement="topLeft" title={description}>
            {description}
          </Tooltip>
        ),
      },
      {
        title: '操作',

        dataIndex: 'action',
        width: 220,
        render: (text, record, index) => {
          return (
            <>
              <Popconfirm
                title="确认发布为最新版本？"
                okText="是"
                cancelText="否"
                onConfirm={() => this.setAsMasterVersion(record)}
              >
                <a>发布为最新版本</a>
              </Popconfirm>
              <Divider type="vertical" />
              <a onClick={() => this.openModelPreview(record)}>模型预览</a>
            </>
          );
        },
      },
    ],
  };

  componentDidMount() {
    this.getModelTypeOptions();
    this.getHistoryModels();
  }

  // 获取模型类型
  getModelTypeOptions = () => {
    apiQueryModelTypeOptions().then((res) => {
      this.setState({
        modelTypeOptionList: res.body,
      });
    });
  };

  // 获取历史模型
  getHistoryModels = () => {
    apiQueryHistoryModes({
      id: this.props.modelId,
    }).then((res) => {
      this.setState({
        histortModelList: res.body,
      });
    });
  };

  // 格式化模型类型
  formatModelType = (dataSource, targetValue) => {
    // console.log(dataSource)
    if (targetValue) {
      return dataSource.map((item) => {
        if (item.value === targetValue) {
          modelType = item.title;
        } else {
          if (item.children) {
            this.formatModelType(item.children, targetValue);
          }
        }
        return modelType;
      });
    }
  };

  // 发布为最新版本
  setAsMasterVersion = (record) => {
    apiSetAsMasterVersion({
      id: record.modelId,
      modelHistoryId: record.id,
    }).then((res) => {
      if (res.sysHead.retCd === '000000') {
        message.success('设置成功');
        this.getHistoryModels();
      }
    });
  };

  // 模型预览
  openModelPreview = (record) => {
    this.setState({
      modelPreviewVisible: true,
      currentModel: record,
    });
  };

  closeModelPreview = () => {
    this.setState({
      modelPreviewVisible: false,
    });
  };

  render() {
    return (
      <>
        <Table
          rowKey={(record) => record.id}
          dataSource={this.state.histortModelList}
          pagination={false}
          bordered
          columns={this.state.columns}
        ></Table>
        {this.state.modelPreviewVisible && (
          <Drawer
            title="模型预览"
            placement="top"
            visible={this.state.modelPreviewVisible}
            onClose={this.closeModelPreview}
            width="100%"
            height="100%"
            footer={null}
          >
            <ModelViewerHistory
              modelId={this.state.currentModel.modelId}
              modelHistoryId={this.state.currentModel.id}
            />
          </Drawer>
        )}
      </>
    );
  }
}

export default VersionManage;
