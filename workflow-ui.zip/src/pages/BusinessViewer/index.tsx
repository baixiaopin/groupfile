// @ts-nocheck
import React from 'react';
import NodeWrap from './NodeWrap';
import './index.less';
// render function...
class BusinessViewer extends React.Component {
  state = {
    nodeConfig: {
      activityId: 'sid-start-node',
      nodeName: '开始',
      type: '00',
      conditionList: [],
      nodeUserList: [],
      childNode: null,
      conditionNodes: [],
    },
    taskData: {},
    designOrViewer: false,
  };

  /**
   * this.props.businessViewer 传值过来的json流程图数据
   * this.props.taskData 传值过来的节点运行任务数据
   * designOrViewer 判断是流程查看时的预览还是任务时的流程预览，以渲染不同的页面头部
   */
  componentWillMount() {
    console.log(this.props.businessViewer);
    const businessViewer = this.props.businessViewer;
    if (businessViewer) {
      this.setState({
        nodeConfig: this.props.businessViewer,
        taskData: this.props.taskData ? this.props.taskData : '',
        designOrViewer: false,
      });
    }
    const nodeConfig = this.props.businessViewerXml;
    console.log(nodeConfig);
    if (nodeConfig) {
      this.setState({ nodeConfig: nodeConfig, designOrViewer: true });
    }
  }
  componentDidMount() {}
  // 关闭设计器，调用父组件事件
  closeModelar = () => {
    this.props.closeModelar();
  };
  render() {
    return (
      <div>
        {/* 判断是否是设计时候的预览，是就加载头部 */}
        {this.state.designOrViewer && (
          <div className="fd-nav">
            <div className="fd-nav-left">
              <div className="fd-nav-back" onClick={this.closeModelar}>
                <i className="anticon1 bus-anticon-left"> {'<'} </i>
              </div>
              <div className="fd-nav-title">流程预览</div>
            </div>
            {/* <div className="fd-nav-right">
            <button
              type="button"
              className="ant-btn button-publish"
            // onClick={this.publish}
            >
              <span>发 布</span>
            </button>
          </div> */}
          </div>
        )}

        <div className={this.state.designOrViewer ? 'fd-nav-content' : ''}>
          <section className="dingflow-design-bus-viewer">
            <div className="box-scale" id="box-scale">
              <NodeWrap
                nodeConfigData={this.state.nodeConfig}
                taskData={this.state.taskData}
              ></NodeWrap>
              <div className="end-node">
                <div className="end-node-circle"></div>
                <div className="end-node-text">流程结束</div>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default BusinessViewer;
