// @ts-nocheck
import React from 'react';

import { FcForm as Form, FcPopover as Popover } from '@ngfed/fc-components';
import NewNodeRf from './NodeWrap';
import './index.less';
import { getInfosByIds } from '../BusinessesTemplate/service';
// render function...
class NodeWrap extends React.Component {
  state = {
    nodeConfig: this.props.nodeConfigData,
    RightSttingvisible: false,
    taskData: {},
    activityStatus: '',
  };
  componentDidMount() {
    console.log(this.state.nodeConfig, 'nodeWrap');
  }
  componentWillMount() {
    const taskData = this.props.taskData;
    for (let key in taskData) {
      if (Object.prototype.hasOwnProperty.call(taskData, key)) {
        console.log('key-value', key, taskData[key]);
        if (taskData[key].status == '1' && taskData[key].numOfExecution == '1')
          this.setState({ activityStatus: key, taskData: this.props.taskData });
      }
    }
  }
  setPerson = (e) => {
    console.log(e);
    // alert(e.nodeName)
    this.setState({
      RightSttingvisible: true,
    });
  };
  // 右侧设置
  showDrawer = () => {
    this.setState({
      RightSttingvisible: true,
    });
  };

  onClose = () => {
    this.setState({
      RightSttingvisible: false,
    });
  };
  // 回显审核人
  getInfosByIds = (e) => {
    getInfosByIds({
      ids: e,
    }).then((res) => {
      console.log(res);
    });
  };
  render() {
    const {
      activityId,
      assignee,
      nodeName,
      throughStrategy,
      candidateUsers,
    } = this.state.nodeConfig;
    return (
      <div>
        {this.state.nodeConfig.type != '04' && (
          <div
            className={
              this.state.nodeConfig.activityId == this.state.activityStatus
                ? 'node-wrap runStatuss'
                : 'node-wrap'
            }
          >
            <div
              className={
                this.state.nodeConfig.type == '00'
                  ? 'start-node node-wrap-box node-wrap-box-bus-viewer'
                  : 'node-wrap-box node-wrap-box-bus-viewer '
              }
              style={{ background: 'white' }}
            >
              <div
                className={
                  this.state.nodeConfig.activityId == this.state.activityStatus
                    ? 'ngfed_overlay_run'
                    : 'ngfed_overlay'
                }
              >
                <div
                  className="title"
                  style={{
                    background:
                      this.state.nodeConfig.type == '01'
                        ? 'rgb(255, 148, 62)'
                        : this.state.nodeConfig.type == '02'
                        ? 'rgb(50, 150, 250)'
                        : 'rgb(87, 106, 149)',
                  }}
                >
                  {this.state.nodeConfig.type == '01' && (
                    <>
                      <span
                        className="iconfontReviewer"
                        style={{ width: 15, height: 15 }}
                      ></span>
                      <i style={{ paddingLeft: 12, fontStyle: 'normal' }}>
                        审核人
                      </i>
                    </>
                  )}
                  {this.state.nodeConfig.type == '02' && (
                    <span className="iconfontSong">抄送人</span>
                  )}
                  {this.state.nodeConfig.type == '00' && <span>发起人</span>}
                </div>
                <Popover
                  placement="rightTop"
                  title={'节点信息'}
                  content={
                    <Form>
                      <Form.Item
                        label="节点id"
                        style={{ fontWeight: 500, marginBottom: 0 }}
                      >
                        {activityId}
                      </Form.Item>
                      <Form.Item
                        label="节点名字"
                        style={{ fontWeight: 500, marginBottom: 0 }}
                      >
                        {nodeName}
                      </Form.Item>
                      <Form.Item
                        label={
                          this.state.nodeConfig.type == '00'
                            ? '发起人'
                            : '节点审核人'
                        }
                        style={{ fontWeight: 500, marginBottom: 0 }}
                      >
                        {assignee || candidateUsers}
                      </Form.Item>
                    </Form>
                  }
                  trigger="click"
                >
                  <div
                    className="content"
                    onClick={() => {
                      this.setPerson(this.state.nodeConfig);
                    }}
                  >
                    {this.state.nodeConfig.type == '00' && (
                      <div className="text">开始</div>
                    )}
                    {this.state.nodeConfig.type == '02' && (
                      <div className="text">
                        {this.state.nodeConfig.nodeName}
                      </div>
                    )}
                    {this.state.nodeConfig.type == '01' && (
                      <div className="text">
                        {this.state.nodeConfig.nodeName}
                      </div>
                    )}
                    <i className="anticon anticon-right-workflow arrow"></i>
                  </div>
                </Popover>
              </div>
            </div>
            {/* 连线 */}
            <div className="add-node-btn-box">
              <div className="add-node-btn"></div>
            </div>
          </div>
        )}
        {/* 类型等于04 且网关后跟两个节点 */}
        {this.state.nodeConfig.type == '04' &&
          this.state.nodeConfig.conditionNodes[0].childNode &&
          this.state.nodeConfig.conditionNodes.length > 0 && (
            <div className="branch-wrap">
              <div className="branch-box-wrap">
                <div className="branch-box">
                  {/* <Button className="add-branch" >{this.state.nodeConfig.nodeName + '1111'}</Button> */}

                  {this.state.nodeConfig.conditionNodes.map((item, index) => {
                    return (
                      <>
                        <div className="col-box">
                          <div className="condition-node">
                            <div className="condition-node-box"></div>

                            {item.childNode && (
                              <NewNodeRf
                                nodeConfigData={item.childNode}
                                taskData={this.state.taskData}
                              ></NewNodeRf>
                            )}
                            {index == 0 && (
                              <>
                                <div className="top-left-cover-line-bus"></div>
                                <div className="bottom-left-cover-line-bus"></div>
                              </>
                            )}

                            {index ==
                              this.state.nodeConfig.conditionNodes.length -
                                1 && (
                              <>
                                <div className="top-right-cover-line-bus"></div>
                                <div className="bottom-right-cover-line-bus"></div>
                              </>
                            )}
                          </div>
                        </div>
                      </>
                    );
                  })}
                </div>
                <div className="add-node-btn-box">
                  <div className="add-node-btn"></div>
                </div>
              </div>
            </div>
          )}

        {this.state.nodeConfig.childNode && (
          <NewNodeRf
            nodeConfigData={this.state.nodeConfig.childNode}
            taskData={this.state.taskData}
          ></NewNodeRf>
        )}
      </div>
    );
  }
}

export default NodeWrap;
