// @ts-nocheck
import {
  FcButton as Button,
  FcCard as Card,
  FcForm as Form,
  FcModal as Modal,
  FcInput as Input,
  FcTable as Table,
  FcConfigProvider as ConfigProvider,
  FcTooltip as Tooltip,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import React from 'react';
import ProcessViewerModel from '../ProcessViewerModel/index';
import { selectHistoricTasks, processInstancePreview } from './service.js';
import zhCN from 'antd/lib/locale/zh_CN';
import Moment from 'moment';
import Tags from '@/components/Tags';
class HistoryTask extends React.Component {
  state = {
    loading: false,
    visible: false,
    viewVisible: false,
    xmlData: [],
    taskData: [],
    data: [],
    pageNum: '',
    pageSize: '',
    total: '',
    activityAssignee: {},
    columns: [
      {
        title: '紧急程度',
        dataIndex: 'priority',
        key: 'priority',
        align: 'center',
        ellipsis: {
          showTitle: false,
        },
        render: (priority) => (
          <>
            <Tags value={priority}></Tags>
          </>
        ),
      },
      {
        title: '模型名称',
        dataIndex: 'modelName',
        key: 'modelName',
        ellipsis: {
          showTitle: false,
        },
        render: (modelName) => (
          <Tooltip placement="topLeft" title={modelName}>
            {modelName}
          </Tooltip>
        ),
      },
      {
        title: '任务名称',
        dataIndex: 'procInstName',
        key: 'procInstName',
        ellipsis: {
          showTitle: false,
        },
        render: (procInstName) => (
          <Tooltip placement="topLeft" title={procInstName}>
            {procInstName}
          </Tooltip>
        ),
      },
      {
        title: '任务类型',
        dataIndex: 'taskType',
        key: 'taskType',
        ellipsis: {
          showTitle: false,
        },
        render: (taskType) => <>{this.checkoutTasktype(taskType)}</>,
      },
      {
        title: '当前环节',
        dataIndex: 'procTaskName',
        key: 'procTaskName',
        ellipsis: {
          showTitle: false,
        },
        render: (procTaskName) => (
          <Tooltip placement="topLeft" title={procTaskName}>
            {procTaskName}
          </Tooltip>
        ),
      },
      {
        title: '处理人',
        dataIndex: 'assignee',
        key: 'assignee',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => (
          <Tooltip
            placement="topLeft"
            title={
              String(record.assigneeName ? record.assigneeName : text) +
              ' (' +
              String(text) +
              ')'
            }
          >
            {String(record.assigneeName ? record.assigneeName : text) +
              ' (' +
              String(text) +
              ')'}
          </Tooltip>
        ),
      },

      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',

        ellipsis: {
          showTitle: false,
        },
        render: (createTime) => {
          return createTime ? (
            <Tooltip
              placement="topLeft"
              title={Moment(createTime).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(createTime).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      {
        title: '结束时间',
        dataIndex: 'endTime',
        key: 'id',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      {
        title: '操作',
        dataIndex: 'action',
        key: 'id',

        width: 130,
        render: (text, record, index) => {
          return (
            <>
              <a
                onClick={() => {
                  this.clickView(record);
                }}
              >
                流程查看
              </a>
            </>
          );
        },
      },
    ],
  };
  checkoutTasktype = (taskType) => {
    switch (taskType) {
      case '01':
        return '普通任务';
      case '02':
        return '委派任务';
      case '03':
        return '已解决待审核任务';
      case '04':
        return '转办任务';
      case '05':
        return '会签任务';
      case '06':
        return '待认领任务';
      default:
        return '授权代办任务';
    }
  };
  searchFormRef = React.createRef();
  componentDidMount() {
    this.search();
  }
  search = () => {
    this.setState({ loading: true });
    const value = this.searchFormRef.current.getFieldsValue();
    selectHistoricTasks({
      ...value,
      pageNum: 1,
      pageSize: 10,
    }).then((res) => {
      if (res?.sysHead?.retCd == '000000') {
        this.setState({
          data: res.body?.list,
          pageNum: res.body?.pageNum,
          pageSize: res.body?.pageSize,
          total: res.body?.total,
        });
      }
      this.setState({ loading: false });
    });
  };

  reset = () => {
    this.searchFormRef.current.resetFields();
    this.search();
  };
  viewHandleOk = () => {
    this.setState({ viewVisible: false, xmlData: [], taskData: [] });
  };

  paginationChange = (page, pageSize) => {
    const value = this.searchFormRef.current.getFieldsValue();
    selectHistoricTasks({
      ...value,
      pageNum: page,
      pageSize: pageSize,
    }).then((res) => {
      this.setState({
        data: res.body.list,
        pageNum: res.body.pageNum,
        pageSize: res.body.pageSize,
        total: res.body.total,
      });
    });
  };
  // 流程查看
  clickView = (value) => {
    this.setState({ loading: true });
    processInstancePreview({
      processInstanceId: value.procInstId,
    })
      .then((res) => {
        if (res?.sysHead?.retCd == '000000') {
          this.setState({
            activityAssignee: res.body?.activityAssignee,
            xmlData: res.body?.bpmnModelXml,
            taskData: res.body?.taskData,
            processInstanceId: value.procInstId,
            loading: false,
            viewVisible: true,
          });
        } else {
          this.setState({ loading: false });
        }
      })
      .then(() => {});
  };
  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Spin spinning={this.state.loading}>
          <Card style={{ marginBottom: 8 }}>
            <Form
              ref={this.searchFormRef}
              layout="inline"
              onFinish={this.search}
              style={{ marginLeft: 16 }}
            >
              {/* <Form.Item
                label="模型名称"
                name="modelName"
                style={{ marginBottom: 0 }}
              >
                <Input  />
              </Form.Item> */}
              <Form.Item
                label="任务名称"
                name="procInstName"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="当前环节"
                name="procTaskName"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="处理人"
                name="assignee"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item style={{ margin: 'auto 0px' }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.reset}>
                  重置
                </Button>
              </Form.Item>
            </Form>
          </Card>
          <Card title="历史任务">
            <Table
              rowKey={(record) => record.id}
              dataSource={this.state.data}
              pagination={{
                showTotal: (total) => `共 ${total} 条数据`,
                showSizeChanger: true,
                // props
                current: this.state.pageNum,
                pageSize: this.state.pageSize,
                total: this.state.total,
                onChange: (page, pageSize) => {
                  this.paginationChange(page, pageSize);
                },
              }}
              bordered
              columns={this.state.columns}
            ></Table>
            {this.state.viewVisible && (
              <Modal
                visible={this.state.viewVisible}
                title="流程查看"
                width="60%"
                onOk={this.viewHandleOk}
                onCancel={this.viewHandleOk}
                footer={null}
              >
                <ProcessViewerModel
                  activityAssignee={this.state.activityAssignee}
                  taskData={this.state.taskData}
                  xmlData={this.state.xmlData}
                  processInstanceId={this.state.processInstanceId}
                ></ProcessViewerModel>
              </Modal>
            )}
          </Card>
        </Spin>
      </ConfigProvider>
    );
  }
}

// 导出一个流程设计组件
export default HistoryTask;
