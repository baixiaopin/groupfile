import request from '../../utils/request';

export function selectHistoricTasks(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'selectHistoricTasks',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 查询流程图
export function processInstancePreview(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'processInstancePreview',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
