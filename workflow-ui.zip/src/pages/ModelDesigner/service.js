import request from '../../utils/request';

// 新建流程图
export function saveModel(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'saveModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 更新流程图
export function saveModelXML(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'saveModelXML',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

export function getModelXML(id) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'getModelXML',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
      },
    },
  });
}

// 校验流程网关节点出线
export function getFalseFlowLineActivityId(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'getFalseFlowLineActivityId',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
