// @ts-nocheck
import React from 'react';
import fileDrop from 'file-drops';
// bpmn的左边工具栏以及编辑节点样式
import 'bpmn-js/dist/assets/diagram-js.css';
// bpmn的字体图标样式
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn.css';
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-codes.css';
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css';
// 自定义工具栏图标样式
import '../../assets/CustomPalette.css';
// 也不知道是什么作用的自定义样式
import '../../assets/Bpmn.css';
// 自定义的左边工具栏样式，必须使用 CSS Module
import styles from '../../assets/Bpmn.module.less';
import 'bpmn-js-bpmnlint/dist/assets/css/bpmn-js-bpmnlint.css';
// 编辑工具组件
import EditingTools from '@/components/editingTools';
// import FullModal from '@/components/fullModal';
import styless from './index.module.less';
// 自定义Modeler
import BpmnModeler from '@/components/modeler';

import bpmnlintConfig from '../../../packed-config';
import lintModule from 'bpmn-js-bpmnlint';
import PropertiesView from '@/components/modeler/customPanel';
// 而这个引入的是右侧属性栏里的内容
import propertiesProviderModule from 'bpmn-js-properties-panel/lib/provider/camunda';

import {
  saveModel,
  saveModelXML,
  getModelXML,
  getFalseFlowLineActivityId,
} from './service.js';
import {
  FcMessage as message,
  FcModal as Modal,
  FcRow as Row,
  FcCol as Col,
  FcNotification as notification,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import flowableModdle from './flowable.json';
let xmlStr = '';
class ModelDesign extends React.Component {
  constructor(props) {
    super(props);
  }
  state = {
    scale: 1, // 流程图比例
    svgVisible: false, // 预览图片
    svgSrc: '', // 图片地址
    modeler: null,
    xmlTemp: '',
    checkBpmn: '',
    loading: false,
  };

  componentDidMount() {
    // console.log(this.props.modelData);
    this.setState({ loading: true });
    let sign = null;
    if (this.props.modelData.id) {
      //  有id实例化bpmn的时候没有加入模型校验
      this.bpmnModeler = new BpmnModeler({
        container: '#canvas',
        additionalModules: [
          // 右边的属性栏
          propertiesProviderModule,
        ],
        // 兼容flowable
        moddleExtensions: {
          flowable: flowableModdle,
        },
      });
      // 调用getModelXML方法获取bpmn
      getModelXML(this.props.modelData.id).then((res) => {
        if (res.sysHead.retCd == '000000') {
          xmlStr = res.body.bpmnModelXml;
          this.importXml(xmlStr);
          // 不会因为进入程序因接口padding而报错,将xml保存下来，用于保存的时候检验流程图是否更改
          setTimeout(async (e) => {
            const { xml } = await this.bpmnModeler.saveXML({ format: false });
            this.setState({ xmlTemp: xml });
          }, 500);
        }
        this.setState({ loading: false });
      });
    } else {
      // 调用setUrlParam方法，每次进入的时候进行模型校验
      this.setUrlParam('linting', true);
      // 建模
      this.bpmnModeler = new BpmnModeler({
        linting: {
          bpmnlint: bpmnlintConfig,
          active: this.getUrlParam('linting'),
        },
        container: '#canvas',
        additionalModules: [
          // 右边的属性栏
          propertiesProviderModule,
          // 没有id实例化bpmn的时候加入模型校验
          lintModule,
        ],
        moddleExtensions: {
          flowable: flowableModdle,
        },
      });
      this.setState({ loading: false });
      /**
       * 调用importXml方法 将XML渲染为流程图
       */
      this.importXml(this.props.modelData.modelXml);
    }

    // 添加toggle事件控制是否校验
    var that = this;
    this.bpmnModeler.on('linting.toggle', function (event) {
      const active = event.active;
      that.setUrlParam('linting', active);
    });

    const dndHandler = fileDrop('Drop BPMN Diagram here.', function (files) {
      that.bpmnModeler.importXML(files[0].textContent);
    });

    document.querySelector('body').addEventListener('dragover', dndHandler);
    this.setState({
      modeler: this.bpmnModeler,
    });
  }

  /**
   * 用来在url上设置一个参数，控制是否校验模型
   * @param name 参数名
   * @param value 传值过来url是否有校验的参数
   */
  setUrlParam = (name, value) => {
    var url = new URL(window.location.href);
    if (value) {
      url.searchParams.set(name, 1);
    } else {
      url.searchParams.delete(name);
    }
    window.history.replaceState({}, null, url.href);
  };

  /**
   * 获取刚开始的url参数
   * @param name url参数
   */
  getUrlParam = (name) => {
    var url = new URL(window.location.href);
    return url.searchParams.has(name);
  };

  /**
   * 渲染xml
   *  @param  data  数据
   */
  importXml = (data) => {
    var that = this;
    /**
     * 调用bpmn的importXml方法将字符串换成图显示出来
     */
    this.bpmnModeler.importXML(data, function (err) {
      if (!err) {
        var definitions = that.bpmnModeler.get('canvas').getRootElement()
          .businessObject.$parent;
        // 这里是成功的回调，渲染到canvas画布上，zoom可以配置自适应画布，保证渲染图位于中间的位置
        that.bpmnModeler.get('canvas').zoom('fit-viewport', 'auto');
      } else {
        console.log('something went wrong:', err);
      }
    });
  };

  /**
   * 下载xml/svg
   *  @param  type  类型  svg / xml
   *  @param  data  数据
   *  @param  name  文件名称
   */
  download = (type, data, name) => {
    let dataTrack = '';
    const a = document.createElement('a');
    switch (type) {
      case 'xml':
        dataTrack = 'bpmn';
        break;
      case 'svg':
        dataTrack = 'svg';
        break;
      default:
        break;
    }
    name = name || `diagram.${dataTrack}`;
    a.setAttribute(
      'href',
      `data:application/bpmn20-xml;charset=UTF-8,${encodeURIComponent(data)}`,
    );
    a.setAttribute('target', '_blank');
    a.setAttribute('dataTrack', `diagram:download-${dataTrack}`);
    a.setAttribute('download', name);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // 导入 xml 文件
  handleOpenFile = (e) => {
    const that = this;
    if (e.target.files[0] !== undefined) {
      const file = e.target.files[0];
      const reader = new FileReader();
      let data = '';
      reader.readAsText(file);
      reader.onload = function (event) {
        data = event.target.result;
        that.renderDiagram(data, 'open');
      };
    }
  };

  // 更新节点颜色
  setColor = (currentElement, properties) => {
    const modeling = this.bpmnModeler.get('modeling');
    modeling.setColor(currentElement, properties);
  };

  // 保存
  handleSave = async () => {
    this.setState({ loading: true });
    const { xml } = await this.bpmnModeler.saveXML({ format: false });
    // const elementRegistry = this.bpmnModeler.get('elementRegistry');
    // console.log(elementRegistry.get('Flow_04qz8tf'));

    // getFalseFlowLineActivityId({
    //   modelXml: xml,
    // }).then((res) => {
    //   if (res.body) {
    //     for (let key in res.body) {
    //       this.setColor(elementRegistry.get(key), {
    //         fill: '#dc5a5a',
    //         stroke: '#dc5a5a',
    //       });
    //     }
    //   }
    // });
    // 判断是否有更改流程
    if (this.state.xmlTemp == xml) {
      this.setState({ loading: false });
      message.warn('请更新流程图后再保存！');
    }
    // 如果不相等
    if (this.state.xmlTemp != xml) {
      // 清除url后的参数
      this.setUrlParam('linting', false);
      this.setState({ xmlTemp: xml });
      // 判断不是新建的bpmn 有id
      if (this.props.modelData.id) {
        saveModelXML({
          id: this.props.modelData.id,
          bpmnModelXml: xml,
        }).then((res) => {
          if (res?.sysHead?.retCd === '000000') {
            setTimeout(() => {
              message.success('保存成功！');
              this.props.closeProcessDesign();
            }, 100);
          }
        });
        this.setState({ loading: false });
      } else {
        // 是新建的模型 没有id
        if (this.state.checkBpmn.split(',')[0] == '0 Errors') {
          saveModel({
            bpmnModelXml: xml,
            description: this.props.modelData.description,
            key: this.props.modelData.key,
            name: this.props.modelData.name,
            type: this.props.modelData.type,
            specificType: this.props.modelData.specificType,
          }).then((res) => {
            if (res?.sysHead?.retCd === '000000') {
              setTimeout(() => {
                message.success('保存成功！');
                this.props.closeProcessDesign();
              }, 100);
              this.setState({ checkBpmn: 'false' });
            }
            this.setState({ loading: false });
          });
        } else {
          this.setState({ loading: false });
          message.error('请检查流程图' + this.state.checkBpmn);
        }
      }
    }
  };

  // 前进
  handleRedo = () => {
    this.bpmnModeler.get('commandStack').redo();
  };

  // 后退
  handleUndo = () => {
    this.bpmnModeler.get('commandStack').undo();
  };

  // 下载 SVG 格式
  handleDownloadSvg = () => {
    this.bpmnModeler.saveSVG({ format: true }, (err, data) => {
      this.download('svg', data);
    });
  };

  // 下载 XML 格式
  handleDownloadXml = () => {
    this.bpmnModeler.saveXML({ format: true }, (err, data) => {
      this.download('xml', data);
    });
  };

  // 流程图放大缩小
  handleZoom = (radio) => {
    const newScale = !radio
      ? 1.0 // 不输入radio则还原
      : this.state.scale + radio <= 0.2 // 最小缩小倍数
      ? 0.2
      : this.state.scale + radio;

    this.bpmnModeler.get('canvas').zoom(newScale);
    this.setState({
      scale: newScale,
    });
  };

  // 渲染 xml/bpmn 格式
  renderDiagram = (xml) => {
    this.bpmnModeler.importXML(xml, (err) => {
      if (err) {
        notification.error({
          message: '提示',
          description: '导入失败',
        });
      }
    });
  };

  // 预览图片
  handlePreview = () => {
    this.bpmnModeler.saveSVG({ format: true }, (err, data) => {
      this.setState({
        svgSrc: data,
        svgVisible: true,
      });
    });
  };

  // 折叠
  handlePanelFold = () => {
    const { hidePanel } = this.state;
    this.setState(
      {
        hidePanel: !hidePanel,
        hideCount: 1,
      },
      () => {},
    );
  };

  // 返回列表
  handleBack() {
    router.push('/bpmn/processManage');
  }

  // 关闭预览流程图弹窗
  handleCancel = () => {
    this.setState({
      svgSrc: '',
      svgVisible: false,
    });
  };

  // 传值校验bpmn是否通过
  checkError = (e) => {
    this.setState({ checkBpmn: e });
    // console.log('校验是否通过');
  };
  render() {
    const { svgVisible, svgSrc, loading } = this.state;
    return (
      <Spin spinning={loading}>
        <div className={styles.container}>
          <Row style={{ display: 'flex', flexFlow: 'nowrap' }}>
            <Col flex="auto">
              {/* 画布 */}
              <div className={styles.canvas} id="canvas" />
            </Col>
            <Col flex="308px">
              {/* 右侧自定义属性栏 */}
              <PropertiesView
                checkError={this.checkError}
                modeler={this.state.modeler}
              ></PropertiesView>
            </Col>
          </Row>
          {/* 编辑工具 */}
          <EditingTools
            onOpenFIle={this.handleOpenFile}
            onSave={this.handleSave}
            onUndo={this.handleUndo}
            onRedo={this.handleRedo}
            onDownloadSvg={this.handleDownloadSvg}
            onDownloadXml={this.handleDownloadXml}
            onZoomIn={() => this.handleZoom(0.1)}
            onZoomOut={() => this.handleZoom(-0.1)}
            onZoomReset={() => this.handleZoom()}
            onPreview={this.handlePreview}
          />
          {/* 查看流程图弹窗 */}
          {svgVisible && (
            // <FullModal visible={svgVisible} onCancel={this.handleCancel}>
            //   <div
            //     dangerouslySetInnerHTML={{
            //       __html: svgSrc,
            //     }}
            //   />
            // </FullModal>
            <Modal
              title={''}
              visible={svgVisible}
              onCancel={this.handleCancel}
              width={'calc(100% - 20px)'}
              height={'calc(100% - 10px)'}
              footer={null}
              className={styless.fullModal}
            >
              <div
                dangerouslySetInnerHTML={{
                  __html: svgSrc,
                }}
              />
            </Modal>
          )}
        </div>
      </Spin>
    );
  }
}

// 导出一个流程设计组件
export default ModelDesign;
