// @ts-nocheck
import React from 'react';
// import BpmnViewer from 'bpmn-js/lib/NavigatedViewer';
import BpmnViewer from 'bpmn-js/lib/Modeler';
import './index.less';

import { getModelXML as apiGetModelXML } from '../ModelDesigner/service';

class ModelViewer extends React.Component {
  state = {
    taskList: [],
  };
  componentDidMount() {
    if (!this.props.modelId) {
      alert('缺少');
      return;
    }
    this.getModelXML();
  }

  // 获取模型的XML
  async getModelXML() {
    const res = await apiGetModelXML(this.props.modelId);
    const modelXML = res.body.bpmnModelXml;
    // this.taskList = this.props.taskData;
    let bpmnViewer = new BpmnViewer({
      container: document.getElementById('canvas'),
    });
    let _self = this;
    bpmnViewer.importXML(modelXML, function (err) {
      if (err) {
        console.log('加载失败', err);
      } else {
        let canvas = bpmnViewer.get('canvas');
        canvas.zoom('fit-viewport', 'auto');
        // let overlays = bpmnViewer.get('overlays');
        // let overlayHtml = document.createElement('div');
        // overlays.add('StartEvent_1', {
        //   position: {
        //     top: 0,
        //     right: 0,
        //   },
        //   html: overlayHtml
        // });

        // 判断开始节点或结束节点完成
        if (bpmnViewer._definitions.rootElements.length == 1) {
          bpmnViewer._definitions.rootElements[0].flowElements.forEach(
            (n, index) => {
              if (n.$type === 'bpmn:StartEvent') {
                canvas.addMarker(n.id, 'start-event');
              }
              if (n.$type === 'bpmn:UserTask') {
                canvas.addMarker(n.id, 'user-task');
              }
              if (n.$type === 'bpmn:ServiceTask') {
                canvas.addMarker(n.id, 'service-task');
              }
              if (n.$type === 'bpmn:ExclusiveGateway') {
                canvas.addMarker(n.id, 'highlight');
              }
            },
          );
        }

        if (bpmnViewer._definitions.rootElements.length == 2) {
          bpmnViewer._definitions.rootElements[1].flowElements.forEach(
            (n, index) => {
              if (n.$type === 'bpmn:StartEvent') {
                canvas.addMarker(n.id, 'highlight');
              }
              if (n.$type === 'bpmn:UserTask') {
                canvas.addMarker(n.id, 'user-task');
              }
              if (n.$type === 'bpmn:ServiceTask') {
                canvas.addMarker(n.id, 'service-task');
              }
              if (n.$type === 'bpmn:ParallelGateway') {
                canvas.addMarker(n.id, 'highlight');
              }
              if (n.$type === 'bpmn:ExclusiveGateway') {
                canvas.addMarker(n.id, 'highlight');
              }
            },
          );
        }
      }
    });
  }

  render() {
    return (
      <div className="containers box1 boxx">
        <div id="canvas" className="canvas"></div>
      </div>
    );
  }
}

export default ModelViewer;
