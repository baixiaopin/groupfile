// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcTag as Tag,
  FcCard as Card,
  FcTree as Tree,
  FcForm as Form,
  FcInput as Input,
  FcTable as Table,
  FcSelect as Select,
  FcRow as Row,
  FcCol as Col,
  FcRadio as Radio,
} from '@ngfed/fc-components';
import {
  getListOrgTrees,
  getOrgAndOrgGruopTrees,
  listPosition,
  getOrgAndChildOrg,
  listUserByOrg,
  getRoleByOrgId,
} from './service';
const { Column } = Table;
const { Option } = Select;
const { DirectoryTree } = Tree;
const { Search } = Input;
class OrgTree extends React.Component {
  newBuildExecutionListenersReff = React.createRef();
  monitor = React.createRef();
  state = {
    selectType: 'user',
    selectTree: '',
    delegateList: [],
    selectedRowKeys: [],
    orgTreeData: [],
    pageNum: 1,
    pageSize: '',
    total: '',
    search: '',
    // 传值控制类型
    typeUser: true,
    typeOrg: true,
    typePost: true,
    typeRole: true,
    treeData: null,
    // 控制变量是否自动生成
    onChangeActivity: 1,
    activityIdUserVar: '',
    autoExpandParent: true,
  };
  componentDidMount() {
    console.log(this.props.activityId);
    if (this.props.candidateUserVarType == 'org') {
      this.setState(
        {
          typeUser: false,
          typePost: false,
          typeRole: false,
          selectType: 'org',
        },
        () => {
          this.selectType('org');
        },
      );
    } else {
      getListOrgTrees().then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({ treeData: res.body });
        }
      });
      listUserByOrg({
        pageSize: 5,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    if (this.props.candidateUserVarOrg) {
      const selectedRowKeys = this.props.candidateUserVarOrg.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      this.setState({
        selectedRowKeys: selectedRowKeys,
        delegateList: this.props.candidateUserVarOrg,
      });
    }
  }
  onExpand = (expandedKeys) => {};
  onSelect = (keys, event) => {
    this.setState({ selectTree: keys[0], search: '' });
    // 选用户类型树
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: 5,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选角色树
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: 5,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选岗位树
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: 5,
        pageNum: 1,
        orgId: event.node.orgGroup == false ? keys[0] : null,
        orgGroupId: event.node.orgGroup == true ? keys[0] : null,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选择机构树
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: 5,
        pageNum: 1,
        key: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
          });
        }
      });
    }
  };
  // 选择处理人用户类型
  selectType = (e) => {
    // 清除旧值
    this.setState({
      search: '',
      selectTree: '',
    });
    // 用户
    if (e == 'user') {
      getListOrgTrees().then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({ treeData: res.body, selectType: 'user' });
        }
        listUserByOrg({
          pageSize: 5,
          pageNum: 1,
        }).then((res) => {
          if (res.sysHead.retCd == '000000') {
            this.setState({
              orgTreeData: res.body.list,
              pageNum: res.body.current,
              pageSize: res.body.pageSize,
              total: res.body.total,
            });
          }
        });
      });
    }
    // 候选人
    if (e == 'candidateUsers') {
      getListOrgTrees().then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            treeData: res.body,
            selectType: 'candidateUsers',
          });
        }
        listUserByOrg({
          pageSize: 5,
          pageNum: 1,
        }).then((res) => {
          if (res.sysHead.retCd == '000000') {
            this.setState({
              orgTreeData: res.body.list,
              pageNum: res.body.current,
              pageSize: res.body.pageSize,
              total: res.body.total,
            });
          }
        });
      });
    }
    // 角色
    if (e == 'role') {
      getListOrgTrees().then((res) => {
        // console.log(res)
        if (res.sysHead.retCd == '000000') {
          this.setState({ treeData: res.body, selectType: 'role' });
        }
        getRoleByOrgId({
          pageSize: 5,
          pageNum: 1,
        }).then((res) => {
          if (res.sysHead.retCd == '000000') {
            this.setState({
              orgTreeData: res.body.list,
              pageNum: res.body.current,
              pageSize: res.body.pageSize,
              total: res.body.total,
            });
          }
        });
      });
    }
    // 机构
    if (e == 'org') {
      getListOrgTrees().then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({ treeData: res.body, selectType: 'org' });
        }
        getOrgAndChildOrg({
          pageSize: 5,
          pageNum: 1,
        }).then((res) => {
          if (res.sysHead.retCd == '000000') {
            const result = res?.body?.orgAndChildOrgByOrgId
              ? res?.body?.orgAndChildOrgByOrgId
              : res.body;
            this.setState({
              orgTreeData: result,
            });
          }
        });
      });
    }
    // 岗位
    if (e == 'post') {
      getOrgAndOrgGruopTrees().then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({ treeData: res.body, selectType: 'post' });
        }
        listPosition({
          pageSize: 5,
          pageNum: 1,
        }).then((res) => {
          if (res.sysHead.retCd == '000000') {
            this.setState({
              orgTreeData: res.body.list,
              pageNum: res.body.current,
              pageSize: res.body.pageSize,
              total: res.body.total,
            });
          }
        });
      });
    }
    if (e == 'userVar') {
      this.setState({
        selectType: 'userVar',
        treeData: [],
        activityIdUserVar: '',
        onChangeActivity: '1',
      });
    }
    // 候选用户变量
    if (e == 'candidateUserVar') {
      this.setState({
        selectType: 'candidateUserVar',
        treeData: [],
        activityIdUserVar: '',
        onChangeActivity: '1',
      });
    }
    // 传值给父组件选中的类型
    this.props.transferSelectType(e);
  };
  // 分页设置
  paginationChange = (page, pageSize) => {
    // console.log('分页');
    let reg = /^[0-9]+.?[0-9]*$/;
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: pageSize,
        pageNum: page,
        empName: this.state.search,
        orgId: this.state.selectTree,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        positionId:
          reg.test(this.state.search) == true ? this.state.search : '',
        positionName:
          reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        roleId: reg.test(this.state.search) == true ? this.state.search : '',
        roleName: reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: pageSize,
        pageNum: page,
        key: this.state.selectTree,
        orgNo: reg.test(this.state.search) == true ? this.state.search : '',
        orgName: reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        const result = res?.body?.orgAndChildOrgByOrgId
          ? res?.body?.orgAndChildOrgByOrgId
          : res.body;
        this.setState({
          orgTreeData: result,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
  };
  deletById = (value) => {
    const arrDelegateLis = this.state.delegateList.filter(
      (item) => item.id !== value,
    );
    const arrSelectedRowKeys = this.state.selectedRowKeys.filter(
      (item) => item !== value,
    );
    this.setState(
      {
        delegateList: arrDelegateLis,
        selectedRowKeys: arrSelectedRowKeys,
      },
      () => {
        this.props.transfer(this.state.delegateList, this.state.selectType);
      },
    );
  };
  deletAll = () => {
    this.setState({ delegateList: [], selectedRowKeys: [] }, () => {
      this.props.transfer(this.state.delegateList);
    });
  };
  // 查询组织架构树
  onChangeStruct = (e) => {
    this.setState({ searchStruct: e.value });
  };
  onSearch = (value) => {
    console.log(value.target.value);
    this.setState({ search: value.target.value });
    // 根据selectType选择用户种类的不同，调用不同的方法
    // 判断value值是否是纯数字
    let reg = /^[0-9]+.?[0-9]*$/;
    //  如果选中的是用户和候选人
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: 5,
        pageNum: 1,
        // orgId: this.state.selectTree,
        empNo: reg.test(value.target.value) == true ? value.target.value : '',
        empName: reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        // console.log(res);
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    //如果选中的岗位
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: 5,
        pageNum: 1,
        // orgId: this.state.selectTree,
        positionId:
          reg.test(value.target.value) == true ? value.target.value : '',
        positionName:
          reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    // 选择机构树
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: 5,
        pageNum: 1,
        // key: this.state.selectTree,
        orgNo: reg.test(value.target.value) == true ? value.target.value : '',
        orgName: reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
          });
        }
      });
    }
    // 选角色树
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: 5,
        pageNum: 1,
        roleId: reg.test(value.target.value) == true ? value.target.value : '',
        roleName:
          reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
  };

  /**
   * 单选按钮函数
   * @param value 单选按钮值
   */
  onChangeActivity = (value) => {
    // console.log(value)
    this.setState({ onChangeActivity: value.target.value });
    // 2 代表默认变量 用户变量和候选用户变量公用这个方法。
    if (value.target.value == '2') {
      if (this.state.selectType == 'userVar') {
        this.setState(
          { activityIdUserVar: this.props.activityId + 'User' },
          () => {
            this.props.transfer(this.state.activityIdUserVar);
            this.props.transferSelectType(this.state.selectType);
          },
        );
      } else {
        this.setState(
          { activityIdUserVar: this.props.activityId + 'CandidateUser' },
          () => {
            this.props.transfer(this.state.activityIdUserVar);
            this.props.transferSelectType(this.state.selectType);
          },
        );
      }
    } else {
      this.setState({ activityIdUserVar: '' }, () => {
        this.props.transfer(this.state.activityIdUserVar);
        this.props.transferSelectType(this.state.selectType);
      });
    }
  };

  /**
   * 输入框值改变，将值赋给Input框同时传值出去
   */
  onChangeActivityId = (value) => {
    // console.log(value.target.value)
    this.setState({ activityIdUserVar: value.target.value }, () => {
      this.props.transfer(this.state.activityIdUserVar);
      this.props.transferSelectType(this.state.selectType);
    });
  };

  /**
   *
   * @param e
   */
  onkeyUpUserVar = (e) => {
    this.setState({ activityIdUserVar: e.replace(/[^a-zA-z0-9]/g, '') });
  };
  render() {
    const {
      selectedRowKeys,
      delegateList,
      selectType,
      orgTreeData,
      treeData,
      autoExpandParent,
    } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        let delegateListTemp = delegateList.concat(selectedRows);
        // 数组去重 选中的角色
        let obj = {};
        let peon = delegateListTemp.reduce((cur, next) => {
          obj[selectType == 'role' ? next.roleId : next.id]
            ? ''
            : (obj[selectType == 'role' ? next.roleId : next.id] =
                true && cur.push(next));
          return cur;
        }, []);
        let selectedRowKeyss = selectedRowKeys.concat(
          this.state.selectedRowKeys,
        );
        const unique = [...new Set(selectedRowKeyss)];

        orgTreeData.map((item) => {
          if (selectedRowKeys.indexOf(item.id) == -1) {
            unique.map((_item, index) => {
              if (_item == item.id) {
                unique.splice(index, 1);
              }
            });
            peon.map((_item, index) => {
              if (_item.id == item.id) {
                peon.splice(index, 1);
              }
            });
          }
        });
        this.props.transfer(peon);
        if (selectType == 'user') {
          this.setState({
            selectedRowKeys: unique,
            delegateList: [peon[peon.length - 1]],
          });
        } else {
          this.setState({
            selectedRowKeys: unique,
            delegateList: peon,
          });
        }
      },
    };
    return (
      <div>
        <Row>
          <Col span={6}>
            <Card bordered>
              {this.props?.searchVisable && (
                <Select
                  value={this.state.selectType}
                  style={{ width: '90%', marginBottom: 10 }}
                  onChange={this.selectType}
                >
                  {this.state.typeUser && (
                    <>
                      <Select.Option value="user">用户</Select.Option>
                      <Select.Option value="candidateUsers">
                        候选人
                      </Select.Option>
                    </>
                  )}
                  {this.state.typeOrg && (
                    <>
                      <Select.Option value="org">机构</Select.Option>
                    </>
                  )}
                  {this.state.typePost && (
                    <>
                      <Select.Option value="post">岗位</Select.Option>
                    </>
                  )}
                  {this.state.typeRole && (
                    <>
                      <Select.Option value="role">角色</Select.Option>
                    </>
                  )}
                </Select>
              )}
              <div className={StyleSheet.ngfedpagination}>
                {treeData ? (
                  <Tree
                    onExpand={this.onExpand}
                    defaultExpandParent
                    height={this.props?.searchVisable ? '402px' : '436px'}
                    autoExpandParent={autoExpandParent}
                    defaultExpandedKeys={['99999']}
                    onSelect={this.onSelect}
                    treeData={treeData}
                  />
                ) : (
                  '加载中...'
                )}
              </div>
            </Card>
          </Col>
          <Col span={13}>
            <Card bordered bodyStyle={{ paddingBottom: 0 }}>
              {/* 用户变量 */}
              {this.state.selectType == 'userVar' && (
                <div>
                  <div>
                    <Form.Item label="请选择：" style={{ width: '50%' }}>
                      <Radio.Group
                        onChange={this.onChangeActivity}
                        defaultValue={1}
                      >
                        <Radio value={1}>手动输入</Radio>
                        <Radio value={2}>默认生成变量</Radio>
                      </Radio.Group>
                    </Form.Item>
                  </div>

                  <Form.Item label="变量值" style={{ width: '50%' }}>
                    <Input
                      value={this.state.activityIdUserVar}
                      onChange={this.onChangeActivityId}
                      disabled={
                        this.state.onChangeActivity == '1' ? false : true
                      }
                      onKeyUp={() =>
                        this.onkeyUpUserVar(this.state.activityIdUserVar)
                      }
                      allowClear
                    ></Input>
                    {this.state.activityIdUserVar != '' && (
                      <div style={{ fontSize: 12, color: 'gray' }}>
                        变量请以英文字母、下划线和数字组合
                      </div>
                    )}
                  </Form.Item>
                </div>
              )}
              {/* 候选人变量 */}
              {this.state.selectType == 'candidateUserVar' && (
                <div>
                  <div>
                    <Form.Item label="请选择：" style={{ width: '50%' }}>
                      <Radio.Group
                        onChange={this.onChangeActivity}
                        defaultValue={1}
                      >
                        <Radio value={1}>手动输入</Radio>
                        <Radio value={2}>默认生成变量</Radio>
                      </Radio.Group>
                    </Form.Item>
                  </div>

                  <Form.Item label="变量值" style={{ width: '50%' }}>
                    <Input
                      value={this.state.activityIdUserVar}
                      onChange={this.onChangeActivityId}
                      disabled={
                        this.state.onChangeActivity == '1' ? false : true
                      }
                      onKeyUp={() =>
                        this.onkeyUpUserVar(this.state.activityIdUserVar)
                      }
                      allowClear
                    ></Input>
                    {this.state.activityIdUserVar != '' && (
                      <div style={{ fontSize: 12, color: 'gray' }}>
                        变量请以英文字母、下划线和数字组合
                      </div>
                    )}
                  </Form.Item>
                </div>
              )}
              {/* 类型不等于机构和变量 */}
              {this.state.selectType != 'userVar' &&
                this.state.selectType != 'candidateUserVar' &&
                this.state.selectType != 'org' && (
                  <>
                    <Search
                      placeholder="请输入查询"
                      allowClear
                      // enterButton="查询"
                      onChange={this.onSearch}
                      value={this.state.search}
                      onBlur={() => {
                        this.setState({ searchStruct: '' });
                      }}
                      style={{ marginBottom: 8 }}
                    ></Search>
                    <Table
                      rowSelection={{
                        ...rowSelection,
                        type:
                          this.state.selectType == 'user'
                            ? 'radio'
                            : 'checkbox',
                      }}
                      dataSource={this.state.orgTreeData}
                      bordered={false}
                      tableLayout="fixed"
                      pagination={{
                        showSizeChanger: true,
                        current: this.state.pageNum,
                        pageSize: this.state.pageSize,
                        total: this.state.total,
                        onChange: (page, pageSize) => {
                          this.paginationChange(page, pageSize);
                        },
                      }}
                      rowKey={(record) =>
                        this.state.selectType == 'role'
                          ? record.roleId
                          : record.id
                      }
                    >
                      <Column
                        title={
                          this.state.selectType == 'user' ||
                          this.state.selectType == 'candidateUsers'
                            ? '用户名'
                            : this.state.selectType == 'post'
                            ? '岗位名称'
                            : '角色名'
                        }
                        dataIndex={
                          this.state.selectType == 'user' ||
                          this.state.selectType == 'candidateUsers'
                            ? 'empName'
                            : this.state.selectType == 'post'
                            ? 'positionName'
                            : 'roleName'
                        }
                        key="name"
                      ></Column>
                      <Column
                        title={
                          this.state.selectType == 'user' ||
                          this.state.selectType == 'candidateUsers'
                            ? '工号'
                            : this.state.selectType == 'post'
                            ? '岗位Id'
                            : '角色Id'
                        }
                        dataIndex={
                          this.state.selectType == 'user' ||
                          this.state.selectType == 'candidateUsers'
                            ? 'code'
                            : this.state.selectType == 'post'
                            ? 'id'
                            : 'roleId'
                        }
                        key="code"
                      ></Column>
                    </Table>
                  </>
                )}
              {/* 机构没有分页 */}
              {this.state.selectType != 'userVar' &&
                this.state.selectType != 'candidateUserVar' &&
                this.state.selectType == 'org' && (
                  <>
                    <Search
                      placeholder="请输入查询"
                      allowClear
                      enterButton="查询"
                      onChange={this.onSearch}
                      value={this.state.search}
                      style={{ marginBottom: 8 }}
                    ></Search>
                    <Table
                      rowSelection={{
                        ...rowSelection,
                      }}
                      pagination={false}
                      pagination={{
                        showSizeChanger: true,
                        pageSize: 5,
                      }}
                      dataSource={this.state.orgTreeData}
                      bordered={false}
                      rowKey={(record) => record.id}
                    >
                      <Column
                        title="机构名称"
                        dataIndex="name"
                        key="name"
                      ></Column>
                      <Column title="机构Id" dataIndex="id" key="id"></Column>
                    </Table>
                  </>
                )}
            </Card>
          </Col>
          <Col span={5}>
            <Card bordered>
              {this.state.delegateList &&
                this.state.delegateList.map((item, index) => {
                  return (
                    <Tag
                      style={{
                        lineHeight: '35px',
                        marginBottom: '8px',
                        height: '40px',
                      }}
                      color="blue"
                      closable
                      onClose={(e) => {
                        e.preventDefault();
                        this.deletById(item.id);
                      }}
                      key={index}
                    >
                      {this.state.selectType == 'role'
                        ? item.roleName
                        : item.name}
                    </Tag>
                  );
                })}
              <br />
              {this.state.delegateList.length != 0 && (
                <Button
                  style={{ marginTop: 30 }}
                  onClick={this.deletAll}
                  type="primary"
                >
                  清空
                </Button>
              )}
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}
export default OrgTree;
