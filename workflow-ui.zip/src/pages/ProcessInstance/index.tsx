// @ts-nocheck
import {
  FcButton as Button,
  FcCard as Card,
  FcDivider as Divider,
  FcForm as Form,
  FcInput as Input,
  FcModal as Modal,
  FcPopconfirm as Popconfirm,
  FcConfigProvider as ConfigProvider,
  FcTable as Table,
  FcTooltip as Tooltip,
  FcMessage as message,
  FcBreadcrumb as Breadcrumb,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import './index.less';
import React from 'react';
import ProcessViewerModel from '../ProcessViewerModel/index';

import {
  queryProcessInstances,
  processInstancePreview,
  queryTaskInstances,
  selectHistoricTasks,
  activateProcessInstance,
  suspendProcessInstance,
} from './service.js';
import zhCN from 'antd/lib/locale/zh_CN';
import Moment from 'moment';
class ProcessInstance extends React.Component {
  state = {
    loading: false,
    visible: false,
    viewVisible: false,
    xmlData: [],
    taskData: [],
    tableTata: [],
    processInstanceId: '',
    pageNum: '',
    pageSize: '',
    total: '',
    detailModal: false,
    dataTask: [],
    dataHistory: [],
    activityAssignee: {},
    columns: [
      {
        title: '流程定义名称',
        dataIndex: 'processDefinitionName',
        key: 'processDefinitionName',

        ellipsis: {
          showTitle: false,
        },
        render: (processDefinitionName) => (
          <Tooltip placement="topLeft" title={processDefinitionName}>
            {processDefinitionName}
          </Tooltip>
        ),
      },
      {
        title: '模型Key',
        dataIndex: 'processDefinitionKey',
        key: 'processDefinitionKey',

        ellipsis: {
          showTitle: false,
        },
        render: (processDefinitionKey) => (
          <Tooltip placement="topLeft" title={processDefinitionKey}>
            {processDefinitionKey}
          </Tooltip>
        ),
      },
      {
        title: '业务Key',
        dataIndex: 'businessKey',
        key: 'id',

        ellipsis: {
          showTitle: false,
        },
        render: (businessKey) => (
          <Tooltip placement="topLeft" title={businessKey}>
            {businessKey}
          </Tooltip>
        ),
      },
      {
        title: '发起人',
        dataIndex: 'startedBy',
        key: 'startedBy',

        ellipsis: {
          showTitle: false,
        },
        render: (startedBy) => (
          <Tooltip placement="topLeft" title={startedBy}>
            {startedBy}
          </Tooltip>
        ),
      },
      {
        title: '发起时间',
        dataIndex: 'started',
        key: 'id',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      {
        title: '流程定义版本',
        dataIndex: 'processDefinitionVersion',
        key: 'id',

        ellipsis: {
          showTitle: false,
        },
        render: (processDefinitionVersion) => (
          <Tooltip placement="topLeft" title={processDefinitionVersion}>
            {processDefinitionVersion}
          </Tooltip>
        ),
      },
      {
        title: '操作',
        dataIndex: 'action',
        key: 'id',

        width: 260,
        render: (text, record, index) => {
          return (
            <>
              <a
                onClick={() => {
                  this.clickView(record);
                }}
              >
                流程查看
              </a>
              <Divider type="vertical" style={{ margin: '0 6px' }} />

              <a
                onClick={() => {
                  this.detailProcess(record);
                }}
              >
                流程详情
              </a>
              <Divider type="vertical" style={{ margin: '0 6px' }} />
              <Popconfirm
                title={
                  record.suspended == true ? '是否要实例激活' : '是否要实例挂起'
                }
                onConfirm={() => {
                  this.suspended(record);
                }}
                onCancel={this.stopCancel}
                okText="确定"
                cancelText="取消"
              >
                <a>{record.suspended == true ? '激活' : '挂起'}</a>
              </Popconfirm>
            </>
          );
        },
      },
    ],
    columnsTask: [
      {
        title: '流程实例id',
        dataIndex: 'processInstanceId',
        key: 'processInstanceId',

        ellipsis: {
          showTitle: false,
        },
        render: (processInstanceId) => (
          <Tooltip placement="topLeft" title={processInstanceId}>
            {processInstanceId}
          </Tooltip>
        ),
      },
      {
        title: '流程名称',
        dataIndex: 'name',
        key: 'name',

        ellipsis: {
          showTitle: false,
        },
        render: (name) => (
          <Tooltip placement="topLeft" title={name}>
            {name}
          </Tooltip>
        ),
      },
      {
        title: '处理人',
        dataIndex: 'assignee',
        key: 'assignee',

        ellipsis: {
          showTitle: false,
        },
        render: (assignee) => (
          <Tooltip placement="topLeft" title={assignee}>
            {assignee}
          </Tooltip>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',

        ellipsis: {
          showTitle: false,
        },
        render: (createTime) => {
          return createTime ? (
            <Tooltip
              placement="topLeft"
              title={Moment(createTime).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(createTime).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
    ],
    columnsHistory: [
      {
        title: '流程实例id',
        dataIndex: 'processInstanceId',
        key: 'processInstanceId',

        ellipsis: {
          showTitle: false,
        },
        render: (processInstanceId) => (
          <Tooltip placement="topLeft" title={processInstanceId}>
            {processInstanceId}
          </Tooltip>
        ),
      },
      {
        title: '流程节点名称',
        dataIndex: 'name',
        key: 'name',

        ellipsis: {
          showTitle: false,
        },
        render: (name) => (
          <Tooltip placement="topLeft" title={name}>
            {name}
          </Tooltip>
        ),
      },
      {
        title: '处理人',
        dataIndex: 'assignee',
        key: 'assignee',

        width: 100,
        ellipsis: {
          showTitle: false,
        },
        render: (assignee) => (
          <Tooltip placement="topLeft" title={assignee}>
            {assignee}
          </Tooltip>
        ),
      },
      {
        title: '开始时间',
        dataIndex: 'startTime',
        key: 'startTime',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      {
        title: '结束时间',
        dataIndex: 'endTime',
        key: 'id',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
    ],
  };

  searchFormRef = React.createRef();
  componentDidMount() {
    this.search();
  }

  // 查询
  search = () => {
    const fieldsValue = this.searchFormRef.current.getFieldsValue();
    this.setState({ loading: true });
    queryProcessInstances({
      pageNum: 1,
      pageSize: 10,
      ...fieldsValue,
    }).then((res) => {
      // console.log(Array.isArray(res.body))
      if (res.body && Array.isArray(res.body.instances)) {
        let arr = JSON.parse(JSON.stringify(res.body.instances));
        arr.map((item) => {
          item.startedBy = item.startedBy.id;
        });
        this.setState({
          tableTata: arr,
          pageNum: res.body.pageNum,
          pageSize: res.body.pageSize,
          total: res.body.total,
          loading: false,
        });
      }
    });
  };

  reset = () => {
    this.searchFormRef.current.resetFields();
    this.search();
  };
  clickView = (value) => {
    this.setState({ loading: true });
    processInstancePreview({
      processInstanceId: value.id,
    })
      .then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            xmlData: res.body.bpmnModelXml,
            taskData: res.body.taskData,
            activityAssignee: res.body?.activityAssignee,
            processInstanceId: value.id,
          });
        }
        this.setState({ loading: false });
      })
      .then(() => {
        this.setState({ viewVisible: true });
      });
  };
  viewHandleOk = () => {
    this.setState({
      viewVisible: false,
      xmlData: [],
      taskData: [],
      activityAssignee: {},
      processInstanceId: '',
    });
  };
  suspended = (e) => {
    // true 挂起转态
    this.setState({ loading: true });
    if (e.suspended == true) {
      activateProcessInstance({
        processInstanceId: e.id,
      }).then((res) => {
        if (res?.sysHead?.retCd == '000000') {
          this.search();
          message.success('激活成功');
        }
        this.setState({ loading: false });
      });
    }
    // false 激活转态
    if (e.suspended == false) {
      suspendProcessInstance({
        processInstanceId: e.id,
      }).then((res) => {
        this.search();
        message.success('挂起成功');
      });
    }
  };
  stopCancel = (e) => {
    message.error('已取消');
  };
  paginationChange = (page, pageSize) => {
    this.setState({ loading: true });
    queryProcessInstances({
      pageNum: page,
      pageSize: pageSize,
    }).then((res) => {
      if (res === undefined) {
      } else {
        let arr = JSON.parse(JSON.stringify(res.body.instances));
        arr.map((item) => {
          item.startedBy = item.startedBy.id;
        });
        this.setState({
          tableTata: arr,
          pageNum: res.body.pageNum,
          pageSize: res.body.pageSize,
          total: res.body.total,
          loading: false,
        });
      }
    });
  };
  // 流程详情
  detailProcess = (e) => {
    this.setState({ loading: true });
    // 查询流程任务
    queryTaskInstances({
      processInstanceId: e.id,
    }).then((res) => {
      console.log(res);
      if (res?.sysHead?.retCd == '000000') {
        this.setState({ dataTask: res.body.list });
      }
      this.setState({ loading: false });
    });
    // 查询历史任务
    selectHistoricTasks({
      processInstanceId: e.id,
    }).then((res) => {
      if (res?.sysHead?.retCd == '000000') {
        this.setState({ dataHistory: res.body.list });
      }
      this.setState({ loading: false });
    });
    this.setState({ detailModal: true });
  };
  detalilHandleOk = () => {
    this.setState({ detailModal: false });
  };
  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Spin spinning={this.state.loading}>
          <Card style={{ marginBottom: 8 }}>
            <Form
              ref={this.searchFormRef}
              layout="inline"
              onFinish={this.search}
              style={{ marginLeft: 16 }}
            >
              <Form.Item
                label="流程定义名称"
                name="processDefinitionName"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item label="业务key" name="key" style={{ marginBottom: 0 }}>
                <Input />
              </Form.Item>
              <Form.Item style={{ margin: 'auto 0' }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.reset}>
                  重置
                </Button>
              </Form.Item>
            </Form>
          </Card>
          <Card title="流程实例">
            <Table
              rowKey={(record) => record.id}
              dataSource={this.state.tableTata}
              pagination={{
                showTotal: (total) => `共 ${total} 条数据`,
                showSizeChanger: true,
                // props
                current: this.state.pageNum,
                pageSize: this.state.pageSize,
                total: this.state.total,
                onChange: (page, pageSize) => {
                  this.paginationChange(page, pageSize);
                },
              }}
              bordered
              columns={this.state.columns}
            ></Table>

            {this.state.viewVisible && (
              <Modal
                visible={this.state.viewVisible}
                title="流程查看"
                width="70%"
                onOk={this.viewHandleOk}
                onCancel={this.viewHandleOk}
                footer={null}
              >
                <ProcessViewerModel
                  activityAssignee={this.state.activityAssignee}
                  processInstanceId={this.state.processInstanceId}
                  taskData={this.state.taskData}
                  xmlData={this.state.xmlData}
                ></ProcessViewerModel>
              </Modal>
            )}
          </Card>
          {this.state.detailModal && (
            <Modal
              visible={this.state.detailModal}
              title="流程详情"
              width="60%"
              onOk={this.detalilHandleOk}
              onCancel={this.detalilHandleOk}
              footer={[
                <Button key="back" onClick={this.detalilHandleOk}>
                  取消
                </Button>,
                <Button
                  key="submit"
                  type="primary"
                  onClick={this.detalilHandleOk}
                >
                  确认
                </Button>,
              ]}
            >
              <Breadcrumb>流程任务</Breadcrumb>
              <Table
                rowKey={(record) => record.id}
                dataSource={this.state.dataTask}
                bordered
                columns={this.state.columnsTask}
                scroll={{ y: 300 }}
                // pagination={false}
              ></Table>
              <Breadcrumb style={{ marginTop: 20 }}>已完成任务</Breadcrumb>
              <Table
                rowKey={(record) => record.id}
                dataSource={this.state.dataHistory}
                bordered
                columns={this.state.columnsHistory}
                scroll={{ y: 300 }}
                // pagination={false}
              ></Table>
            </Modal>
          )}
        </Spin>
      </ConfigProvider>
    );
  }
}

// 导出一个流程实例组件
export default ProcessInstance;
