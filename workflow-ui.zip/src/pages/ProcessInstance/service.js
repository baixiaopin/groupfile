import request from '../../utils/request';

export function queryProcessInstances(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'queryProcessInstances',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

export function processInstancePreview(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'processInstancePreview',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 流程详情，流程任务
export function queryTaskInstances(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'queryTaskInstances',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 历史任务完成
export function selectHistoricTasks(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'selectHistoricTasks',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 流程实例的激活
export function activateProcessInstance(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'activateProcessInstance',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 流程实例的挂起
export function suspendProcessInstance(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'suspendProcessInstance',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
