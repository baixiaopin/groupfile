import request from '../../utils/request';

/**
 * 查询业务类型列表
 */
export function listBusinessModelType() {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'listBusinessModelType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {},
    },
  });
}

/**
 * 条件查询
 * @param {*} data
 */
export function listTypeByNameAndCode(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'listTypeByNameAndCode',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 新增业务类型
 * @param {*} data
 */
export function saveBusinessModelType(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'saveBusinessModelType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 更新业务类型
 * @param {*} data
 */
export function updateBusinessModelTypeById(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'updateBusinessModelTypeById',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 删除业务类型
 * @param {*} data
 */
export function removeBusinessModelType(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'removeBusinessModelType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 查询插件bea
 */
export function getServicePlugIn(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'RepositorySVC',
        stdIntfcInd: 'getServicePlugIn',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
