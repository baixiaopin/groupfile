// @ts-nocheck
// 业务配置组件
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcMessage as message,
  FcPopconfirm as Popconfirm,
  FcModal as Modal,
  FcInput as Input,
  FcTable as Table,
  FcSelect as Select,
  FcBadge as Badge,
  FcTabs as Tabs,
} from '@ngfed/fc-components';
const { TabPane } = Tabs;
import StyleSheet from '../index.less';
import Paramater from './Paramater';
class BusinessConfig extends Component {
  formRef = React.createRef();
  state = {
    paramaterVisable: false,
    // 配置列表
    columnsBusiness: [
      {
        dataIndex: 'keyV',
        key: 'keyV',
        title: 'key',
        width: '25%',
        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.keyV}
              style={{ width: '150px' }}
              onChange={(value) => this.handleChangeKey(value, record, index)}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'value',
        key: 'value',
        title: '插件类型',
        render: (_, record, index) => {
          return (
            <Select
              placeholder="默认值"
              onChange={(value) => this.handleChangeType(value, record, index)}
              value={record.value}
              style={{ width: '100px' }}
              dropDownAbove
            >
              <Select.Option value="Object">Object</Select.Option>
              <Select.Option value="Boolean">Boolean</Select.Option>
              <Select.Option value="String">String</Select.Option>
              <Select.Option value="Array">Array</Select.Option>
              <Select.Option value="Arrays">Arrays</Select.Option>
            </Select>
          );
        },
      },
      {
        dataIndex: 'description',
        key: 'description',
        title: '描述',
        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.description}
              onChange={(value) => this.handleChangeDec(value, record, index)}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'description',
        key: 'description',
        title: '参数',
        render: (_, record, index) => {
          if (record.value == 'Array' || record.value == 'Arrays') {
            return (
              <Badge
                count={record.paramaterData?.length}
                style={{ backgroundColor: '#52c41a' }}
              >
                <Button
                  type="primary"
                  onClick={(value) => {
                    this.paramater(value, record, index);
                  }}
                >
                  配置
                </Button>
              </Badge>
            );
          } else {
            return <Button disabled>配置</Button>;
          }
        },
      },
      {
        dataIndex: 'action',
        key: 'action',
        title: '操作',

        render: (_, record, index) => {
          return (
            <>
              <Popconfirm
                title="确定删除这条数据吗？"
                onConfirm={() => this.handleDelete(index)}
              >
                <a type="link">删除</a>
              </Popconfirm>
            </>
          );
        },
      },
    ],
    columnsServe: [
      {
        dataIndex: 'keyV',
        key: 'keyV',
        title: 'Bea',
        width: '20%',
        render: (_, record, index) => {
          return (
            <Select
              placeholder="默认值"
              onChange={(value) =>
                this.handleChangeServeKey(value, record, index)
              }
              value={record.name}
              style={{ width: '150px' }}
              dropDownAbove
            >
              {this.props.servicePlugIn &&
                this.props.servicePlugIn.map((item, index) => {
                  return (
                    <>
                      <Select.Option key={index} value={JSON.stringify(item)}>
                        {item.name}
                      </Select.Option>
                    </>
                  );
                })}
            </Select>
          );
        },
      },
      {
        dataIndex: 'value',
        key: 'value',
        title: '插件类型',
        width: '20%',
        render: (_, record, index) => {
          return (
            <Select
              placeholder="默认值"
              onChange={(value) => this.handleChangeType(value, record, index)}
              value={record.value}
              style={{ width: '100px' }}
              dropDownAbove
            >
              <Select.Option value="Array">Array</Select.Option>
              <Select.Option value="Object">Object</Select.Option>
              <Select.Option value="Boolean">Boolean</Select.Option>
              <Select.Option value="String">String</Select.Option>
            </Select>
          );
        },
      },
      {
        dataIndex: 'execStep',
        key: 'execStep',
        title: '执行阶段',
        width: '20%',
        render: (_, record, index) => {
          return <Input disabled value={record.execStep}></Input>;
        },
      },
      {
        dataIndex: 'description',
        key: 'description',
        title: '描述',
        width: '20%',
        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.description}
              onChange={(value) => this.handleChangeDec(value, record, index)}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'action',
        key: 'action',
        title: '操作',

        render: (_, record, index) => {
          return (
            <>
              <Popconfirm
                title="确定删除这条数据吗？"
                onConfirm={() => this.handleDelete(index)}
              >
                <a type="link">删除</a>
              </Popconfirm>
            </>
          );
        },
      },
    ],
    columns: [],
    count: 1,
    // 当前显示列表
    configurationKeyList: [],
    // 存服务插件
    configurationServe: [],
    // 存业务插件
    configurationBusiness: [],
    // 存服务和业务插件
    saveServeAndBusiness: [],
    // 当前选择的tab
    currentTab: '1',
    // 当前选中的列数据
    currentRowData: {},
    businessVisble: false,
    paramater: {},
  };

  componentDidMount() {
    const plugMapping = this.props.configurationKeys;
    const servicePlugIn = this.props.servicePlugIn;
    // console.log(plugMapping);
    // console.log(servicePlugIn);
    this.setState({ businessVisble: true });
    if (plugMapping) {
      this.setState(
        {
          saveServeAndBusiness: plugMapping,
        },
        () => {
          this.serveAndBusinessClassify('2');
          this.serveAndBusinessClassify('1');
        },
      );
    }
  }

  /**
   * 将数组重的服务插件和业务插件区分开
   * @param value
   * @returns
   */
  serveAndBusinessClassify = (value) => {
    // console.log(value);
    // console.log(this.state.saveServeAndBusiness);
    const plugMapping = this.state.saveServeAndBusiness;
    const servicePlugIn = Array.isArray(this.props.servicePlugIn)
      ? this.props.servicePlugIn
      : [];
    const servicePlugInNames = servicePlugIn.map((item) => {
      return item.name;
    });
    let plugTemp: any = [];
    if (value == '2') {
      if (plugMapping) {
        // 获取服务插件，服务插件是从后台获取的，servicePlugInNames是所有服务插件的bea名字
        plugMapping.map((item) => {
          if (servicePlugInNames.includes(item.keyV)) {
            plugTemp.push(item);
          }
        });
        // 处理数据加上状态显示，bea的名字
        plugTemp.map((item) => {
          servicePlugIn.map((_item) => {
            if (item.keyV == _item.name) {
              item.name = _item.name;
              item.execStep = _item.execStep;
            }
          });
        });
        // console.log(plugTemp, 'servicePlugIn');
      }
      this.setState({
        // configurationKeyList: plugTemp,
        configurationServe: plugTemp,
        currentTab: value,
      });
    }
    if (value == '1') {
      if (plugMapping) {
        plugMapping.map((item) => {
          if (!servicePlugInNames.includes(item.keyV) && item.keyV != null) {
            plugTemp.push(item);
          }
        });
      }
      // console.log(plugTemp, 'businessPlugIn');
      this.setState({
        configurationBusiness: plugTemp,
        currentTab: value,
      });
    }
  };

  /**
   *
   * @returns 处理切换后的表格数据
   */
  onChangeTab = (e) => {
    // console.log(e);
    this.setState({ currentTab: e });
    // this.serveAndBusinessClassify(e);
  };

  /**
   * 校验名称的唯一
   * @param {Object} record
   * @param {String} value
   */
  checkData(value) {
    const { saveServeAndBusiness } = this.state;
    const index = saveServeAndBusiness.findIndex((item) => {
      return item.keyV === value;
    });
    if (index !== -1) {
      message.error('key不能重复');
      return false;
    }
    return true;
  }

  /**
   * 处理key的改变 业务
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeKey(value, record, index) {
    //校验是否重复
    // if (!this.checkData(value.target.value)) return;
    if (this.state.currentTab == '1') {
      const newData = [...this.state.configurationBusiness];
      //在列表中找到这条记录
      const item = newData[index];
      const cpRecord = record;
      cpRecord.keyV = value.target.value;
      newData.splice(index, 1, { ...item, ...cpRecord });
      // console.log('newData', newData);
      // console.log(this.state.configurationBusiness);
      // console.log(this.state.configurationServe);
      this.setState({
        saveServeAndBusiness: [...newData, ...this.state.configurationServe],
      });
      this.setState({
        configurationBusiness: [...newData],
      });
    }
  }

  /**
   * 处理字段的改变描述 业务和服务插件，判断 1:业务 2：服务
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeDec(value, record, index) {
    //校验是否重复
    // if (!this.checkData(value.target.value)) return;
    if (this.state.currentTab == '1') {
      const newData = [...this.state.configurationBusiness];
      //在列表中找到这条记录
      const item = newData[index];
      const cpRecord = record;
      cpRecord.description = value.target.value;
      //获取id
      // cpRecord.key = this.getLimitObjectType(value).key;
      newData.splice(index, 1, { ...item, ...cpRecord });
      this.setState({
        saveServeAndBusiness: [...newData, ...this.state.configurationServe],
      });
      this.setState({
        configurationBusiness: [...newData],
      });
    } else {
      const newData = [...this.state.configurationServe];
      const item = newData[index];
      const cpRecord = record;
      cpRecord.description = value.target.value;
      newData.splice(index, 1, { ...item, ...cpRecord });
      this.setState({
        saveServeAndBusiness: [...newData, ...this.state.configurationBusiness],
      });
      this.setState({
        configurationServe: [...newData],
      });
    }
  }

  /**
   * 处理字段的改变类型 业务和服务插件，判断 1:业务 2：服务
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeType(value, record, index) {
    //校验是否重复
    console.log('value');

    if (!this.checkData(value)) return;
    if (this.state.currentTab == '1') {
      const newData = [...this.state.configurationBusiness];
      //在列表中找到这条记录
      const item = newData[index];
      const cpRecord = record;
      cpRecord.value = value;
      // 判断类型是否为Array，如果不是则清除掉参数
      if (value != 'Array') {
        delete cpRecord.paramaterData;
      }
      newData.splice(index, 1, { ...item, ...cpRecord });
      this.setState({
        saveServeAndBusiness: [...newData, ...this.state.configurationServe],
        configurationBusiness: [...newData],
      });
    } else {
      const newData = [...this.state.configurationServe];
      const item = newData[index];
      const cpRecord = record;
      cpRecord.value = value;
      newData.splice(index, 1, { ...item, ...cpRecord });
      this.setState({
        saveServeAndBusiness: [...newData, ...this.state.configurationBusiness],
        configurationServe: [...newData],
      });
    }
  }

  handleChangeServeKey(value, record, index) {
    //校验是否重复
    // console.log(value);
    // if (!this.checkData(JSON.parse(value).name)) return;
    const newData = [...this.state.configurationServe];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.keyV = JSON.parse(value).name;
    cpRecord.execStep = JSON.parse(value).execStep;
    // cpRecord.type = this.getLimitObjectType(value).type;
    // cpRecord.dec = value.target.value;
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      saveServeAndBusiness: [...newData, ...this.state.configurationBusiness],
    });
  }

  /**
   * 删除一条表格
   * @param {String} index
   */
  handleDelete = (index) => {
    // console.log('key', index);
    const { count, currentTab } = this.state;
    // console.log(currentTab);

    if (this.state.currentTab == '1') {
      const newData = [...this.state.configurationBusiness];
      newData.splice(index, 1);
      this.setState({
        configurationBusiness: newData,
        count: count - 1,
      });
    } else {
      const newData = [...this.state.configurationServe];
      newData.splice(index, 1);
      this.setState({
        configurationServe: newData,
        count: count - 1,
      });
    }
  };

  /**
   * 新增一条表格
   */
  handleAdd = (e) => {
    const { count, configurationServe, configurationBusiness } = this.state;
    let newData = {};
    if (e == 'server') {
      newData = {
        description: null,
        value: '',
        keyV: null,
      };
      this.setState({
        configurationServe: [...configurationServe, newData],
      });
    } else {
      newData = {
        description: null,
        value: null,
      };
      this.setState({
        configurationBusiness: [...configurationBusiness, newData],
      });
    }
  };

  /**
   *
   * @returns 参数配置
   */
  paramater = (value, record, index) => {
    // console.log(record);
    this.setState({
      paramaterVisable: true,
      currentRowData: record,
      paramater: JSON.parse(JSON.stringify(record)),
    });
  };

  confirmParamater = () => {
    this.setState({ paramaterVisable: false });
  };
  closeParamater = () => {
    this.setState({ paramaterVisable: false });
  };

  /**
   * 子组件调用
   * @returns 参数配置函数调用
   */
  confirmParamaterTer = (e) => {
    if (e == 'text') {
      this.setState({ paramaterVisable: false });
      return false;
    }
    const { currentRowData, configurationBusiness } = this.state;
    currentRowData.paramaterData = e;
    this.setState(
      {
        paramaterVisable: false,
        currentRowData: currentRowData,
        configurationBusiness: [],
      },
      () => {
        this.setState({ configurationBusiness: configurationBusiness });
      },
    );
  };
  /**
   *
   * @returns 确认model框
   */

  confirmBusiness = () => {
    const { configurationBusiness, configurationServe } = this.state;

    const newArray = configurationBusiness.concat(configurationServe);
    // console.log(newArray, '最终数据');
    let flag = false;
    newArray?.map((item, index) => {
      if (!item.keyV) {
        // console.log(item, index);
        message.error('业务插件的key值必填，服务插件的Bea必选');
        flag = true;
        return false;
        //  newArray.splice(index, 1);
      }
      if (!item.value) {
        // console.log(item, index);
        message.error('插件的类型必选');
        flag = true;
        return false;
        // newArray.splice(index, 1);
      }
    });
    if (flag) {
      return false;
    }
    // console.log(newArray);

    this.props.tranferConfigurationKeyList(newArray);
    this.setState({ businessVisble: false });
  };
  /**
   *
   * @returns 取消
   */
  cancelBusiness = () => {
    this.setState({ businessVisble: false });
    this.props.tranferConfigurationKeyList();
  };
  render() {
    return (
      <>
        <Modal
          title="插件添加"
          visible={this.state.businessVisble}
          okText="确认"
          cancelText="取消"
          maskClosable={false}
          width="50%"
          onOk={this.confirmBusiness}
          onCancel={this.cancelBusiness}
          bodyStyle={{ paddingTop: 0 }}
        >
          <div className={StyleSheet.hiddleTabNavLeft}>
            <Tabs
              defaultActiveKey="1"
              onChange={this.onChangeTab}
              style={{ marginBottom: 32 }}
              tabBarStyle={{ paddingLeft: 0 }}
            >
              <TabPane tab="业务插件" key="1">
                <Button
                  onClick={() => this.handleAdd('false')}
                  type="primary"
                  style={{ marginBottom: 16 }}
                >
                  {' '}
                  + 添加{' '}
                </Button>
                {/* <Scrollbars autoHeightMin="50vh" autoHide autoHeight> */}
                <Table
                  key={(record) => {
                    record.keyV;
                  }}
                  bordered
                  dataSource={this.state.configurationBusiness}
                  columns={this.state.columnsBusiness}
                  pagination={false}
                />
                {/* </Scrollbars> */}
              </TabPane>
              <TabPane tab="服务插件" key="2">
                <Button
                  onClick={() => this.handleAdd('server')}
                  type="primary"
                  style={{ marginBottom: 16 }}
                >
                  {' '}
                  + 添加{' '}
                </Button>
                {/* <Scrollbars autoHeightMin="50vh" autoHide autoHeight> */}
                <Table
                  key={(record) => {
                    record.keyV;
                  }}
                  scroll={{ x: 800, y: 500 }}
                  bordered
                  dataSource={this.state.configurationServe}
                  columns={this.state.columnsServe}
                  pagination={false}
                />
                {/* </Scrollbars> */}
              </TabPane>
            </Tabs>
            {this.state.paramaterVisable && (
              <Paramater
                paramaterData={this.state.paramater}
                confirmParamaterTer={this.confirmParamaterTer}
              ></Paramater>
            )}
          </div>
        </Modal>
      </>
    );
  }
}
export default BusinessConfig;
