// @ts-nocheck
// 权限设置组件

import {
  FcButton as Button,
  FcCard as Card,
  FcMessage as message,
  FcPopconfirm as Popconfirm,
  FcModal as Modal,
  FcInput as Input,
  FcTable as Table,
  FcConfigProvider as ConfigProvider,
} from '@ngfed/fc-components';
import zhCN from 'antd/lib/locale/zh_CN';
import React from 'react';

class paramater extends React.Component<any, any> {
  state = {
    paramaterVisable: false,
    paramaterData: [],
    // 配置列表
    columns: [
      {
        dataIndex: 'value',
        key: 'value',
        title: '权限标识',
        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.value}
              onChange={(value) => this.handleChangeKey(value, record, index)}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'description',
        key: 'description',
        title: '描述',
        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.description}
              onChange={(value) => this.handleChangeDec(value, record, index)}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'action',
        key: 'action',
        title: '操作',
        width: 80,
        render: (_, record, index) => {
          return (
            <>
              <Popconfirm
                title="确定删除这条数据吗？"
                onConfirm={() => this.handleDelete(index)}
              >
                <a type="link">删除</a>
              </Popconfirm>
            </>
          );
        },
      },
    ],
  };

  componentDidMount() {
    const { paramaterData } = this.props;
    console.log(paramaterData, '权限列表');

    if (paramaterData) {
      this.setState({ paramaterVisable: true, paramaterData: paramaterData });
      return false;
    }
    this.setState({ paramaterVisable: true });
  }

  /**
   * 校验交易代码和维度名称的唯一
   * @param {Object} record
   * @param {String} value
   */
  checkData(value) {
    const { paramaterData } = this.state;
    const index = paramaterData.findIndex((item) => {
      return item.value === value;
    });
    if (index !== -1) {
      message.error('key不能重复');
      return false;
    }
    return true;
  }

  /**
   *  处理value输入
   */
  handleChangeKey(value, record, index) {
    console.log('111');

    //校验是否重复
    if (!this.checkData(value.target.value)) return;
    const newData = [...this.state.paramaterData];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.value = value.target.value;
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      saveServeAndBusiness: [...newData, ...this.state.paramaterData],
      paramaterData: [...newData],
    });
  }

  /**
   * 处理字段的改变描述 业务和服务插件，判断 1:业务 2：服务
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeDec(value, record, index) {
    const newData = [...this.state.paramaterData];
    const item = newData[index];
    const cpRecord = record;
    cpRecord.description = value.target.value;
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      saveServeAndBusiness: [...newData, ...this.state.paramaterData],
      paramaterData: [...newData],
    });
  }

  confirmParamater = () => {
    const { paramaterData } = this.state;
    const newArray = paramaterData;
    let flag = false;
    newArray?.map((item, index) => {
      if (!item.value) {
        message.error('value值必填');
        flag = true;
        return false;
      }
      if (!item.description) {
        message.error('描述必填');
        flag = true;
        return false;
      }
    });
    if (flag) {
      return false;
    }

    this.setState({ paramaterVisable: false });
    this.props.confirmParamaterTer(this.state.paramaterData);
  };
  closeParamater = () => {
    this.setState({ paramaterVisable: false });
    this.props.confirmParamaterTer('text');
  };

  /**
   * 新增一条表格
   */
  handleAdd = () => {
    console.log('111111');

    const { paramaterData } = this.state;
    let newData = {};
    newData = {
      value: null,
      description: null,
    };
    this.setState({
      paramaterData: [...paramaterData, newData],
    });
  };

  /**
   * 删除一条表格
   * @param {String} index
   */
  handleDelete = (index) => {
    const newData = [...this.state.paramaterData];
    newData.splice(index, 1);
    this.setState({
      paramaterData: [...newData],
    });
  };
  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Card>
          {this.state.paramaterVisable && (
            <Modal
              title="权限设置"
              visible={this.state.paramaterVisable}
              okText="确认"
              cancelText="取消"
              maskClosable={false}
              onOk={this.confirmParamater}
              onCancel={this.closeParamater}
            >
              <Button
                onClick={() => this.handleAdd()}
                type="primary"
                style={{ marginBottom: 16 }}
              >
                {' '}
                + 添加{' '}
              </Button>
              <Table
                key={(record) => {
                  record.value;
                }}
                bordered
                dataSource={this.state.paramaterData}
                columns={this.state.columns}
                pagination={false}
              />
            </Modal>
          )}
        </Card>
      </ConfigProvider>
    );
  }
}

export default paramater;
