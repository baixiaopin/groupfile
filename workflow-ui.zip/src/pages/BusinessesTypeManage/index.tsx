// @ts-nocheck
import {
  FcButton as Button,
  FcCard as Card,
  FcMessage as message,
  FcForm as Form,
  FcPopconfirm as Popconfirm,
  FcModal as Modal,
  FcInput as Input,
  FcTable as Table,
  FcConfigProvider as ConfigProvider,
  FcDivider as Divider,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import { FormInstance } from 'antd/lib/form';
import zhCN from 'antd/lib/locale/zh_CN';
import React from 'react';
import {
  listBusinessModelType,
  saveBusinessModelType,
  listTypeByNameAndCode,
  removeBusinessModelType,
  updateBusinessModelTypeById,
  getServicePlugIn,
} from './service.js';
import BusinessConfig from './components/BusinessProConfig';
import Moment from 'moment';

class ModelType extends React.Component<any, any> {
  state = {
    loading: false,
    newBuildVisible: false,
    editVisble: false,
    businessVisble: false,
    elementValueList: [],
    cacheList: { kiu: 12 },
    businessModelTypeList: [],
    currentEditRowData: null,
    // 业务属性配置
    configurationKey: [],
    // 子组件传值配置列表
    configurationKeyList: [],
    // 服务插件
    servicePlugIn: [],
  };

  searchFormRef = React.createRef<FormInstance>();
  newBuildFormRef = React.createRef<FormInstance>();
  editFormRef = React.createRef<FormInstance>();

  componentDidMount() {
    this.refesh();
  }

  // 请求业务类型数据
  refesh = () => {
    this.setState({ loading: true });
    listBusinessModelType({}).then((res) => {
      if (res?.sysHead?.retCd == '000000') {
        this.setState({
          businessModelTypeList: Array.isArray(res.body) ? res.body : [],
          loading: false,
        });
      }
    });
  };

  /**
   * 搜索按钮
   */
  clickSearchBtn = () => {
    const searchForm = this.searchFormRef.current?.getFieldsValue();
    this.setState({ loading: true });
    listTypeByNameAndCode({
      ...searchForm,
    }).then((res) => {
      this.setState({
        businessModelTypeList: Array.isArray(res.body) ? res.body : [],
      });
    });
    this.setState({ loading: false });
  };

  /**
   * 重置按钮
   */
  reset = () => {
    this.searchFormRef.current.resetFields();
    this.refesh();
  };

  /**
   *  新建
   */
  openNewBuild = () => {
    this.setState({
      newBuildVisible: true,
    });
  };

  closeNewBuild = () => {
    this.setState({
      newBuildVisible: false,
    });
  };

  /**
   * 确认新建
   */
  confirmNewBuild = async () => {
    try {
      const newBuildForm = await this.newBuildFormRef.current?.validateFields();
      this.setState({ loading: true });
      saveBusinessModelType({
        ...newBuildForm,
      }).then((res) => {
        if (res?.sysHead?.retCd == '000000') {
          this.setState({ loading: false });
          this.refesh();
          this.closeNewBuild();
        }
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  /**
   * 打开编辑并回显信息
   * @param record 当前编辑的信息
   */
  openEdit = (record) => {
    // console.log(record);

    this.setState({
      editVisble: true,
      currentEditRowData: record,
    });
    setTimeout(() => {
      this.editFormRef.current?.setFieldsValue(record);
    }, 0);
  };

  closeEdit = () => {
    this.setState({
      editVisble: false,
    });
  };

  /**
   * 确认编辑界面
   */
  confirmEdit = async () => {
    try {
      const value = this.editFormRef.current.validateFields();
      const newBuildForm = this.editFormRef.current?.getFieldsValue();

      // console.log(newBuildForm);
      updateBusinessModelTypeById({
        ...newBuildForm,
        id: this.state.currentEditRowData.id,
        configurationKeys: this.state.currentEditRowData.configurationKeys,
      }).then((res) => {
        // console.log(res);
        if (res.sysHead.retCd == '000000') {
          message.success('更新成功');
          this.refesh();
          this.closeEdit();
        }
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 删除
  delete = (record: any) => {
    // console.log(record);
    removeBusinessModelType({
      id: record.id,
    }).then((res) => {
      if (res.sysHead.retCd == '000000') {
        message.success('删除成功');
        this.refesh();
      }
    });
  };

  /**
   * 点击业务配置按钮
   * @param record 当前行信息
   */
  bussinessConfig = (record) => {
    // console.log(record);
    this.setState({ loading: true });
    getServicePlugIn().then((res) => {
      if (res.body) {
        this.setState({
          businessVisble: true,
          currentEditRowData: record,
          configurationKeys: record.configurationKeys,
          servicePlugIn: res.body,
          loading: false,
        });
      }
    });
  };
  confirmBusiness = () => {};
  cancelBusiness = () => {
    this.setState({ businessVisble: false });
  };
  // 业务配置传值
  configurationKeyList = (value) => {
    // this.setState({ configurationKeyList: value });
    this.setState({ businessVisble: false });
    if (value) {
      updateBusinessModelTypeById({
        ...this.state.currentEditRowData,
        configurationKeys: value,
      }).then((res) => {
        // console.log(res);
        message.success('保存成功');
        this.refesh();
      });
    } else {
      this.refesh();
    }
  };

  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Spin spinning={this.state.loading}>
          <Card style={{ marginBottom: 8 }}>
            <Form
              ref={this.searchFormRef}
              layout="inline"
              initialValues={{
                typeCode: '',
                typeName: '',
              }}
              style={{ marginLeft: 16 }}
              onFinish={this.clickSearchBtn}
            >
              <Form.Item label="编码" name="code" style={{ marginBottom: 0 }}>
                <Input />
              </Form.Item>
              <Form.Item
                label="业务类型名称"
                name="typeName"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item style={{ margin: 'auto 0' }}>
                <Button
                  type="primary"
                  htmlType="submit"
                  onClick={this.clickSearchBtn}
                >
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.reset}>
                  重置
                </Button>
              </Form.Item>
            </Form>
          </Card>
          <Card
            title="模型类型"
            extra={
              <Button type="primary" onClick={this.openNewBuild}>
                新建
              </Button>
            }
          >
            <Table
              dataSource={this.state.businessModelTypeList}
              rowKey={(record) => record.id}
              pagination={{
                showTotal: (total) => `共 ${total} 条数据`,
                showSizeChanger: true,
              }}
              bordered
            >
              <Table.Column
                title="编码"
                dataIndex="code"
                key="code"
              ></Table.Column>
              <Table.Column
                title="类型名称"
                dataIndex="typeName"
                key="typeName"
              ></Table.Column>

              <Table.Column
                title="描述"
                dataIndex="description"
                key="description"
              ></Table.Column>
              <Table.Column
                title="创建时间"
                dataIndex="createTime"
                key="createTime"
                render={(text, record, index) => {
                  return <>{Moment(text).format('yyyy-MM-DD HH:mm:ss')}</>;
                }}
              ></Table.Column>
              <Table.Column
                title="修改时间"
                dataIndex="updateTime"
                key="updateTime"
                render={(text, record, index) => {
                  return (
                    <>
                      {' '}
                      {text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
                    </>
                  );
                }}
              ></Table.Column>
              <Table.Column
                title="操作"
                dataIndex="operation"
                key="operation"
                width="239px"
                render={(text, record, index) => {
                  return (
                    <>
                      <a
                        onClick={(e) => {
                          e.preventDefault();
                          this.openEdit(record);
                        }}
                      >
                        编辑
                      </a>
                      <Divider type="vertical" />

                      <a
                        onClick={(e) => {
                          e.preventDefault();
                          this.bussinessConfig(record);
                        }}
                      >
                        节点插件配置
                      </a>

                      <Divider type="vertical" />
                      <Popconfirm
                        title="是否删除？"
                        onConfirm={() => this.delete(record)}
                        okText="是"
                        cancelText="否"
                      >
                        <a>删除</a>
                      </Popconfirm>
                    </>
                  );
                }}
              ></Table.Column>
            </Table>
          </Card>

          {this.state.newBuildVisible && (
            <Modal
              title="新建"
              visible={this.state.newBuildVisible}
              okText="确认"
              cancelText="取消"
              maskClosable={false}
              onOk={this.confirmNewBuild}
              onCancel={this.closeNewBuild}
            >
              <Form ref={this.newBuildFormRef} layout="horizontal">
                <Form.Item
                  label="编码"
                  name="code"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[
                    { required: true, message: '请输入' },
                    {
                      pattern: /^[^ ]{1,15}$/,
                      message: '不能超过最大长度',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  label="类型名称"
                  name="typeName"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[
                    { required: true, message: '请输入' },
                    {
                      pattern: /^[^ ]{1,15}$/,
                      message: '不能超过最大长度',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>

                <Form.Item
                  label="描述"
                  name="description"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                >
                  <Input.TextArea />
                </Form.Item>
              </Form>
            </Modal>
          )}

          {this.state.editVisble && (
            <Modal
              title="编辑"
              visible={this.state.editVisble}
              okText="确认"
              cancelText="取消"
              maskClosable={false}
              onOk={this.confirmEdit}
              onCancel={this.closeEdit}
            >
              <Form
                ref={this.editFormRef}
                layout="horizontal"
                initialValues={{
                  typeCode: '',
                  typeName: '',
                  parentId: '',
                  sort: '',
                  description: '',
                }}
              >
                <Form.Item
                  label="编码"
                  name="code"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[
                    { required: true, message: '请输入' },
                    {
                      pattern: /^[^]{1,15}$/,
                      message: '不能超过最大长度',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  label="类型名称"
                  name="typeName"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[
                    { required: true, message: '请输入' },
                    {
                      pattern: /^[^]{1,15}$/,
                      message: '不能超过最大长度',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>

                <Form.Item
                  label="描述"
                  name="description"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                >
                  <Input.TextArea />
                </Form.Item>
              </Form>
            </Modal>
          )}

          {/* 业务属性 */}
          {this.state.businessVisble && (
            <BusinessConfig
              tranferConfigurationKeyList={this.configurationKeyList}
              configurationKeys={this.state.configurationKeys}
              servicePlugIn={this.state.servicePlugIn}
            ></BusinessConfig>
          )}
        </Spin>
      </ConfigProvider>
    );
  }
}

export default ModelType;
