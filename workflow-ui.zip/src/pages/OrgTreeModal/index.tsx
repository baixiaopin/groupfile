// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcTag as Tag,
  FcCard as Card,
  FcTabs as Tabs,
  FcTree as Tree,
  FcModal as Modal,
  FcForm as Form,
  FcInput as Input,
  FcTable,
  FcSelect as Select,
  FcRow as Row,
  FcCol as Col,
  FcRadio as Radio,
  FcMessage as message,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import {
  getListOrgTrees,
  listPosition,
  getOrgAndChildOrg,
  listUserByOrg,
  getRoleByOrgId,
} from './service';
const { Column } = FcTable;
const { DirectoryTree } = Tree;
const { Search } = Input;
import StyleSheet from './index.less';
class OrgTree extends React.Component {
  avgRefSettings = React.createRef();
  state = {
    loading: false,
    selectType: 'user',
    selectTree: '',
    delegateList: [],
    selectedRowKeys: [],
    orgTreeData: [],
    pageNum: 1,
    pageSize: '',
    total: '',
    search: '',
    treeData: null,
    // 控制变量是否自动生成
    onChangeActivity: 1,
    activityIdUserVar: '',
    selectUserVisible: true,
    selectType: 'user',
    //
    tabPosition: 'fixedValue',
    disabled: false,
  };

  /**
   * 刚加载 就判断是否是传值回显的，有类型就调用selectType方法
   * 否则就默认
   */
  componentDidMount() {
    console.log(this.props);

    const radio = this.props.tranferType;
    if (radio) {
      this.setState({ disabled: true });
    }
    if (this.props.selectType) {
      this.selectType(this.props.selectType);
    } else {
      this.selectType('user');
    }
    if (
      this.props.selectType == 'userVar' ||
      this.props.selectType == 'candidateUserVar' ||
      this.props.selectType == 'assignee'
    ) {
      if (this.props.delegateList?.length > 0) {
        this.setState({
          activityIdUserVar: this.props.delegateList[0].name
            ?.split(':')[1]
            .replaceAll('${', '')
            .replaceAll('}', '')
            .replaceAll(' ', ''),
          tabPosition: 'var',
        });
      }
    } else {
      const selectedRowKeys = this.props.delegateList?.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      const delegateList = this.props.delegateList
        ? this.props.delegateList
        : [];
      const userOvg = this.props.userOvg;
      if (userOvg) {
        const arrayOvg = userOvg.split(',');
        let objOvg = {};
        arrayOvg.map((item) => {
          objOvg[item.split(':')[0]] = item.split(':')[1];
        });
        this.avgRefSettings.current.setFieldsValue({ ...objOvg });
      }
      this.setState({
        delegateList: delegateList,
        selectedRowKeys: selectedRowKeys,
      });
    }
    this.start();
  }

  /**
   * 左侧树结构
   */
  start = () => {
    this.setState({ loading: true });
    getListOrgTrees().then((res) => {
      if (res.sysHead.retCd == '000000') {
        const result = res?.body?.listOrgTrees
          ? res?.body?.listOrgTrees
          : res.body;
        this.setState({ treeData: result });
      }
      this.setState({ loading: false });
    });
  };
  onExpand = (expandedKeys) => {};

  /**
   * 选中组织架构树
   * @param keys 组织树的key值
   * @param event
   */
  onSelect = (keys, event) => {
    this.setState({ selectTree: keys[0], search: '' });
    // 选用户类型树
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: 10,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          res.body.list?.map((item) => {
            item.id = item.empNo;
          });
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选角色树
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: 10,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选岗位树
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: 10,
        pageNum: 1,
        orgId: event.node.orgGroup == false ? keys[0] : null,
        orgGroupId: event.node.orgGroup == true ? keys[0] : null,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选择机构树
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: 10,
        pageNum: 1,
        key: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
          });
        }
      });
    }
  };
  // 选择处理人用户类型
  selectType = (e) => {
    // 清除旧值
    this.setState({
      delegateList: [],
      selectedRowKeys: [],
      search: '',
      loading: true,
    });
    // 用户
    if (e == 'user') {
      listUserByOrg({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          res.body.list?.map((item) => {
            item.id = item.empNo;
          });
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'user',
          });
        }
        this.setState({ loading: false });
      });
    }
    // 候选人
    if (e == 'candidateUsers') {
      listUserByOrg({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          res.body.list?.map((item) => {
            item.id = item.empNo;
          });
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'candidateUsers',
          });
        }
        this.setState({ loading: false });
      });
    }
    // 角色
    if (e == 'role') {
      getRoleByOrgId({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'role',
          });
        }
        this.setState({ loading: false });
      });
    }
    // 机构
    if (e == 'org') {
      getOrgAndChildOrg({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
            selectType: 'org',
          });
        }
        this.setState({ loading: false });
      });
    }
    // 岗位
    if (e == 'post') {
      listPosition({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'post',
          });
        }
        this.setState({ loading: false });
      });
    }
    if (e == 'userVar') {
      this.setState({
        selectType: 'userVar',
        activityIdUserVar: '',
        onChangeActivity: '1',
      });
    }
    // 候选用户变量
    if (e == 'candidateUserVar') {
      this.setState({
        selectType: 'candidateUserVar',
        activityIdUserVar: '',
        onChangeActivity: '1',
        loading: false,
      });
    }
    if (e == 'assignee') {
      this.setState({
        selectType: 'userVar',
        activityIdUserVar: '',
        onChangeActivity: '1',
        loading: false,
      });
    }
    // 传值给父组件选中的类型
    this.props.transferSelectType(e);
  };

  /**
   * 分页设置
   * @param page
   * @param pageSize
   */
  paginationChange = (page, pageSize) => {
    let reg = /^[0-9]+.?[0-9]*$/;
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: pageSize,
        pageNum: page,
        empName: this.state.search,
        orgId: this.state.selectTree,
      }).then((res) => {
        res.body.list.map((item) => {
          item.id = item.empNo;
        });
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        positionId:
          reg.test(this.state.search) == true ? this.state.search : '',
        positionName:
          reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        roleId: reg.test(this.state.search) == true ? this.state.search : '',
        roleName: reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: pageSize,
        pageNum: page,
        key: this.state.selectTree,
        orgNo: reg.test(this.state.search) == true ? this.state.search : '',
        orgName: reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        const result = res?.body?.orgAndChildOrgByOrgId
          ? res?.body?.orgAndChildOrgByOrgId
          : res.body;
        this.setState({
          orgTreeData: result,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
  };

  /**
   * 根据id删除选中的审核人
   * @param value
   */
  deletById = (value) => {
    const arrDelegateLis = this.state.delegateList.filter(
      (item) => item.id !== value,
    );
    const arrSelectedRowKeys = this.state.selectedRowKeys.filter(
      (item) => item !== value,
    );
    this.setState({
      delegateList: arrDelegateLis,
      selectedRowKeys: arrSelectedRowKeys,
    });
  };

  /**
   * 删除所有的
   */
  deletAll = () => {
    this.setState({ delegateList: [], selectedRowKeys: [] });
  };

  /**
   * 查询组织架构树 搜索
   * @param value
   */
  onSearch = (value) => {
    this.setState({ search: value.target.value });
    // 根据selectType选择用户种类的不同，调用不同的方法
    // 判断value值是否是纯数字
    let reg = /^[0-9]+.?[0-9]*$/;
    //  如果选中的是用户和候选人
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: 10,
        pageNum: 1,
        // orgId: this.state.selectTree,
        empNo: reg.test(value.target.value) == true ? value.target.value : '',
        empName: reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          res.body.list?.map((item) => {
            item.id = item.empNo;
          });
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    //如果选中的岗位
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: 10,
        pageNum: 1,
        // orgId: this.state.selectTree,
        positionId:
          reg.test(value.target.value) == true ? value.target.value : '',
        positionName:
          reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    // 选择机构树
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: 10,
        pageNum: 1,
        // key: this.state.selectTree,
        orgNo: reg.test(value.target.value) == true ? value.target.value : '',
        orgName: reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
          });
        }
      });
    }
    // 选角色树
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: 10,
        pageNum: 1,
        roleId: reg.test(value.target.value) == true ? value.target.value : '',
        roleName:
          reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
  };

  /**
   * 单选按钮函数
   * @param value 单选按钮值
   */
  onChangeActivity = (value) => {
    this.setState({ onChangeActivity: value.target.value });
    // 2 代表默认变量 用户变量和候选用户变量公用这个方法。
    if (value.target.value == '2') {
      if (this.state.selectType == 'userVar') {
        this.setState({ activityIdUserVar: this.props.activityId + 'User' });
      } else {
        this.setState({
          activityIdUserVar: this.props.activityId + 'CandidateUser',
        });
      }
    } else {
      this.setState({ activityIdUserVar: '' });
    }
  };

  /**
   * 输入框值改变，将值赋给Input框同时传值出去
   */
  onChangeActivityId = (value) => {
    this.setState({ activityIdUserVar: value.target.value });
  };

  /**
   * 处理变量输入,只能输入数字或英文字母
   * @param e
   */
  onkeyUpUserVar = (e) => {
    this.setState({ activityIdUserVar: e.replace(/[^a-zA-z0-9]/g, '') });
  };

  /*
   * 选择权重的时候的变化
   */
  selectServiceType = () => {
    const avgRefSetting = this.avgRefSettings.current?.getFieldsValue();
  };

  /**
   * 确定modal框的时候，判断如果是按权重，则校验权重比例达到100%
   * @param e
   * @returns
   */
  selectUserHandleOk = async (e) => {
    const avgRefSetting = this.avgRefSettings.current?.getFieldsValue();
    console.log(avgRefSetting);
    let num = 0;
    for (let key in avgRefSetting) {
      num += parseFloat(avgRefSetting[key]);
    }
    console.log(num);

    if (
      num != 1 &&
      this.props.throughStrategy == 'avg' &&
      this.state.delegateList.length != 0
    ) {
      message.warn('所有人的权重加起来请等于100%');
      return false;
    }
    if (
      this.state.selectType == 'userVar' ||
      this.state.selectType == 'candidateUserVar'
    ) {
      if (this.state.activityIdUserVar == '') {
        this.setState({ delegateList: [], selectUserVisible: false }, () => {
          this.props.transfer('');
        });
      } else {
        this.setState(
          { activityIdUserVar: '${' + this.state.activityIdUserVar + '}' },
          () => {
            this.props.transfer(
              this.state.activityIdUserVar,
              this.state.selectType,
            );
          },
        );
      }
    } else {
      this.setState({ selectUserVisible: false }, () => {
        this.props.transfer(this.state.delegateList, this.state.selectType);
        this.props.transferUserOvg
          ? this.props.transferUserOvg(
              JSON.stringify(avgRefSetting)
                .replaceAll('"', '')
                .replaceAll('{', '')
                .replaceAll('}', ''),
            )
          : '';

        this.props.transferSelectType(this.state.selectType);
      });
    }
  };

  /**
   * 选择审核人的modal框取消
   */
  selectUserHandleCancel = () => {
    this.setState({ selectUserVisible: false, delegateList: [] });
    this.props.selectUserHandleCancel();
  };

  /**
   * 判断选择固定值还是变量
   * @param e
   */
  changeTabPosition = (e) => {
    if (e.target.value == 'fixedValue') {
      this.setState({ selectType: 'user', tabPosition: e.target.value });
      this.selectType('user');
    } else {
      this.setState({
        selectType: 'userVar',
        tabPosition: e.target.value,
        delegateList: [],
      });
    }
  };

  /**
   * 选择类型
   * @param e
   */
  changeSelectType = (e) => {
    this.setState({ selectType: e.target.value });
    this.selectType(e.target.value);
  };
  render() {
    const {
      selectedRowKeys,
      delegateList,
      selectType,
      orgTreeData,
    } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        console.log(delegateList, selectedRows);

        let delegateListTemp = delegateList.concat(selectedRows);
        // 数组去重 选中的角色
        let obj = {};
        let peon = delegateListTemp.reduce((cur, next) => {
          obj[selectType == 'role' ? next.roleId : next.id]
            ? ''
            : (obj[selectType == 'role' ? next.roleId : next.id] =
                true && cur.push(next));
          return cur;
        }, []);
        let selectedRowKeyss = selectedRowKeys.concat(
          this.state.selectedRowKeys,
        );
        const unique = [...new Set(selectedRowKeyss)];

        orgTreeData.map((item) => {
          if (selectedRowKeys.indexOf(item.id) == -1) {
            unique.map((_item, index) => {
              if (_item == item.id) {
                unique.splice(index, 1);
              }
            });
            peon.map((_item, index) => {
              if (_item.id == item.id) {
                peon.splice(index, 1);
              }
            });
          }
        });
        if (selectType == 'user') {
          this.setState({
            selectedRowKeys: unique,
            delegateList: [peon[peon.length - 1]],
          });
        } else {
          this.setState({
            selectedRowKeys: unique,
            delegateList: peon,
          });
        }
      },
    };

    return (
      <Spin spinning={this.state.loading}>
        <Modal
          visible={this.state.selectUserVisible}
          title="节点审核人员选择"
          width={this.state.tabPosition == 'var' ? '50%' : '62%'}
          maskClosable={false}
          centered
          onOk={this.selectUserHandleOk}
          onCancel={this.selectUserHandleCancel}
          bodyStyle={{ paddingTop: 12 }}
          footer={[
            <Button key="back" onClick={this.selectUserHandleCancel}>
              取消
            </Button>,
            <Button
              key="submit"
              type="primary"
              onClick={this.selectUserHandleOk}
            >
              确认
            </Button>,
          ]}
        >
          <Row>
            <Col span={24} style={{ marginBottom: 8 }}>
              <div>
                <Radio.Group
                  value={this.state.tabPosition}
                  onChange={this.changeTabPosition}
                  buttonStyle="solid"
                  size="large"
                >
                  <Radio.Button value="fixedValue" style={{ fontSize: 12 }}>
                    固定值
                  </Radio.Button>
                  <Radio.Button
                    value="var"
                    style={{ fontSize: 12 }}
                    disabled={this.state.disabled}
                  >
                    变量
                  </Radio.Button>
                </Radio.Group>
                <Search
                  placeholder="请输入查询"
                  allowClear
                  // enterButton="查询"
                  disabled={
                    this.state.tabPosition == 'fixedValue' ? false : true
                  }
                  onChange={this.onSearch}
                  value={this.state.search}
                  style={{ width: '40%', marginLeft: '8px' }}
                ></Search>
              </div>
            </Col>
          </Row>
          {this.state.tabPosition == 'fixedValue' && (
            <Row>
              <Col span={24}>
                <Card bordered bodyStyle={{ padding: '12px 24px' }}>
                  <Radio.Group
                    value={this.state.selectType}
                    onChange={this.changeSelectType}
                  >
                    <Radio value="user">用户</Radio>
                    <Radio
                      value="candidateUsers"
                      disabled={this.state.disabled}
                    >
                      候选用户
                    </Radio>
                    <Radio value="org" disabled={this.state.disabled}>
                      机构
                    </Radio>
                    <Radio value="post" disabled={this.state.disabled}>
                      岗位
                    </Radio>
                    <Radio value="role" disabled={this.state.disabled}>
                      角色
                    </Radio>
                  </Radio.Group>
                </Card>
              </Col>
            </Row>
          )}
          {this.state.tabPosition == 'var' && (
            <Row>
              <Col span={24}>
                <Card bordered bodyStyle={{ padding: '12px 24px' }}>
                  <Radio.Group
                    value={this.state.selectType}
                    onChange={this.changeSelectType}
                  >
                    <Radio value="userVar">用户变量</Radio>
                    <Radio value="candidateUserVar">候选用户变量</Radio>
                  </Radio.Group>
                </Card>
              </Col>
            </Row>
          )}
          <Row>
            {this.state.selectType != 'userVar' &&
              this.state.selectType != 'candidateUserVar' && (
                <Col span={6}>
                  <Card bordered bodyStyle={{ paddingTop: 16 }}>
                    {this.state.treeData ? (
                      <DirectoryTree
                        // multiple
                        // defaultExpandAll={'true'}
                        pageSizeOptions={[5, 10]}
                        onSelect={this.onSelect}
                        onExpand={this.onExpand}
                        defaultExpandedKeys={['99999']}
                        height={462}
                        treeData={this.state.treeData}
                      />
                    ) : (
                      '加载中...'
                    )}
                  </Card>
                </Col>
              )}

            <Col span={this.state.tabPosition == 'var' ? '24' : '12'}>
              <Card bordered bodyStyle={{ paddingBottom: 0, paddingTop: 16 }}>
                {/* 用户变量 */}
                {this.state.selectType == 'userVar' && (
                  <div>
                    <div>
                      <Form.Item label="请选择：" style={{ width: '50%' }}>
                        <Radio.Group
                          onChange={this.onChangeActivity}
                          defaultValue={1}
                        >
                          <Radio value={1}>手动输入</Radio>
                          <Radio value={2}>默认生成变量</Radio>
                        </Radio.Group>
                      </Form.Item>
                    </div>

                    <Form.Item label="变量值" style={{ width: '50%' }}>
                      <Input
                        value={this.state.activityIdUserVar}
                        onChange={this.onChangeActivityId}
                        disabled={
                          this.state.onChangeActivity == '1' ? false : true
                        }
                        onKeyUp={() =>
                          this.onkeyUpUserVar(this.state.activityIdUserVar)
                        }
                        allowClear
                      ></Input>
                      {this.state.activityIdUserVar != '' && (
                        <div style={{ fontSize: 12, color: 'gray' }}>
                          变量以英文字母、下划线和数字组合
                        </div>
                      )}
                    </Form.Item>
                  </div>
                )}
                {/* 候选人变量 */}
                {this.state.selectType == 'candidateUserVar' && (
                  <div>
                    <div>
                      <Form.Item label="请选择：" style={{ width: '50%' }}>
                        <Radio.Group
                          onChange={this.onChangeActivity}
                          defaultValue={1}
                        >
                          <Radio value={1}>手动输入</Radio>
                          <Radio value={2}>默认生成变量</Radio>
                        </Radio.Group>
                      </Form.Item>
                    </div>

                    <Form.Item label="变量值" style={{ width: '50%' }}>
                      <Input
                        value={this.state.activityIdUserVar}
                        onChange={this.onChangeActivityId}
                        disabled={
                          this.state.onChangeActivity == '1' ? false : true
                        }
                        onKeyUp={() =>
                          this.onkeyUpUserVar(this.state.activityIdUserVar)
                        }
                        allowClear
                      ></Input>
                      {this.state.activityIdUserVar != '' && (
                        <div style={{ fontSize: 12, color: 'gray' }}>
                          变量以英文字母、下划线和数字组合
                        </div>
                      )}
                    </Form.Item>
                  </div>
                )}
                {/* 类型不等于机构和变量 */}
                {this.state.selectType != 'userVar' &&
                  this.state.selectType != 'candidateUserVar' &&
                  this.state.selectType != 'org' && (
                    <>
                      <FcTable
                        rowSelection={{
                          ...rowSelection,
                          type:
                            this.state.selectType == 'user'
                              ? 'radio'
                              : 'checkbox',
                        }}
                        dataSource={this.state.orgTreeData}
                        bordered={false}
                        size="small"
                        className="ngfed-table"
                        tableLayout="fixed"
                        pagination={{
                          showSizeChanger: true,
                          current: this.state.pageNum,
                          pageSize: this.state.pageSize,
                          total: this.state.total,
                          onChange: (page, pageSize) => {
                            this.paginationChange(page, pageSize);
                          },
                        }}
                        rowKey={(record) => record.id}
                      >
                        <Column
                          title={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? '用户名'
                              : this.state.selectType == 'post'
                              ? '岗位名称'
                              : '角色名'
                          }
                          dataIndex={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? 'empName'
                              : this.state.selectType == 'post'
                              ? 'positionName'
                              : 'roleName'
                          }
                          key="name"
                        ></Column>
                        <Column
                          title={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? '工号'
                              : this.state.selectType == 'post'
                              ? '岗位Id'
                              : '角色Id'
                          }
                          dataIndex={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? 'code'
                              : this.state.selectType == 'post'
                              ? 'id'
                              : 'roleId'
                          }
                          key="code"
                        ></Column>
                      </FcTable>
                    </>
                  )}
                {/* 机构没有分页 */}
                {this.state.selectType != 'userVar' &&
                  this.state.selectType != 'candidateUserVar' &&
                  this.state.selectType == 'org' && (
                    <>
                      <FcTable
                        rowSelection={{
                          ...rowSelection,
                        }}
                        pagination={false}
                        pagination={{
                          showSizeChanger: true,
                          pageSize: 10,
                        }}
                        size="small"
                        dataSource={this.state.orgTreeData}
                        bordered={false}
                        rowKey={(record) => record.id}
                      >
                        <Column
                          title="机构名称"
                          dataIndex="name"
                          key="name"
                        ></Column>
                        <Column title="机构Id" dataIndex="id" key="id"></Column>
                      </FcTable>
                    </>
                  )}
              </Card>
            </Col>

            {this.state.selectType != 'userVar' &&
              this.state.selectType != 'candidateUserVar' && (
                <Col span={6}>
                  <Card bordered bodyStyle={{ paddingTop: 16 }}>
                    {this.state.delegateList &&
                      this.props.throughStrategy !== 'avg' &&
                      this.state.delegateList.map((item, index) => {
                        return (
                          <Tag
                            style={{
                              lineHeight: '29px',
                              marginBottom: '8px',
                              height: '34px',
                            }}
                            color="blue"
                            closable
                            onClose={(e) => {
                              e.preventDefault();
                              this.deletById(item.id);
                            }}
                            key={index}
                          >
                            {item.name ? item.name : item}
                          </Tag>
                        );
                      })}
                    <br />
                    {this.state.delegateList?.length != 0 &&
                      this.props.throughStrategy !== 'avg' && (
                        <Button
                          style={{ marginTop: 8 }}
                          onClick={this.deletAll}
                          type="primary"
                        >
                          清空
                        </Button>
                      )}
                    <Form ref={this.avgRefSettings}>
                      {/* 权重 */}
                      {this.state.delegateList &&
                        this.props.throughStrategy == 'avg' &&
                        this.state.delegateList.map((item, index) => {
                          return (
                            <div
                              style={{
                                display: 'flex',
                                justifyContent: 'start',
                              }}
                            >
                              <div>
                                <Tag
                                  style={{
                                    lineHeight: '35px',
                                    marginBottom: '8px',
                                    height: '40px',
                                    // display:'inline-block'
                                  }}
                                  closable
                                  color="blue"
                                  onClose={(e) => {
                                    e.preventDefault();
                                    this.deletById(item.id);
                                  }}
                                  key={index}
                                >
                                  {item.name ? item.name : item}
                                </Tag>
                              </div>
                              <div>
                                <Form.Item
                                  name={item.empNo ? item.empNo : item.id}
                                  noStyle
                                >
                                  <Select
                                    placeholder="请选择权重"
                                    onChange={this.selectServiceType}
                                    style={{
                                      // width: '50%',
                                      margin: -1,
                                      float: 'right',
                                    }}
                                  >
                                    <Select.Option value="0.1">
                                      10%
                                    </Select.Option>
                                    <Select.Option value="0.2">
                                      20%
                                    </Select.Option>
                                    <Select.Option value="0.3">
                                      30%
                                    </Select.Option>
                                    <Select.Option value="0.4">
                                      40%
                                    </Select.Option>
                                    <Select.Option value="0.5">
                                      50%
                                    </Select.Option>
                                    <Select.Option value="0.6">
                                      60%
                                    </Select.Option>
                                    <Select.Option value="0.7">
                                      70%
                                    </Select.Option>
                                    <Select.Option value="0.8">
                                      80%
                                    </Select.Option>
                                    <Select.Option value="0.9">
                                      90%
                                    </Select.Option>
                                    <Select.Option value="1">
                                      100%
                                    </Select.Option>
                                  </Select>
                                </Form.Item>
                              </div>
                            </div>
                          );
                        })}
                    </Form>
                    <br />
                    {this.state.delegateList?.length != 0 &&
                      this.props.throughStrategy == 'avg' && (
                        <Button
                          style={{ marginTop: 8 }}
                          onClick={this.deletAll}
                          type="primary"
                        >
                          清空
                        </Button>
                      )}
                  </Card>
                </Col>
              )}
          </Row>
        </Modal>
      </Spin>
    );
  }
}
export default OrgTree;
