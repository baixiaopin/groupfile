import request from '../../utils/request';

// 获取续跑流程
export function getBusinessProInstances(data) {
  console.log(data);
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceContinueSVC',
        stdIntfcInd: 'getBusinessProInstances',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
export function processInstancePreview(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceContinueSVC',
        stdIntfcInd: 'processInstancePreview',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
export function getBusinessProInstanceTasksByProInstanceId(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceContinueSVC',
        stdIntfcInd: 'getBusinessProInstanceTasksByProInstanceId',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

//续跑
export function processInstanceContinueRunning(data, procInstIdTemp) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: data.stdSvcInd,
        stdIntfcInd: data.stdIntfcInd,
        srcConsmSysInd: data.srcConsmSysInd,
        stdIntfcVerNo: data.stdIntfcVerNo,
        flag: true,
      },
      localHead: {},
      body: { [procInstIdTemp]: data[procInstIdTemp] },
    },
    customErrorMessageFn: () => {},
  });
}

//修改
export function proInstAddRemarksAndAlterPeople(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceContinueSVC',
        stdIntfcInd: 'proInstAddRemarksAndAlterPeople',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
