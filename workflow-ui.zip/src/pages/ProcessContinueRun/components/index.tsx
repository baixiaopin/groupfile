// @ts-nocheck
import React, { Component } from 'react';
import {
  FcDrawer,
  FcTree,
  FcRow,
  FcCol,
  FcDivider,
  FcEmpty,
  FcButton,
  FcInput,
  FcForm,
} from '@ngfed/fc-components';
import styles from './index.module.less';
import {
  processInstancePreview,
  getBusinessProInstanceTasksByProInstanceId,
} from '../service';
import ProcessViewerModel from '../../ProcessViewerModel/index';
const { TextArea } = FcInput;
class FullModal extends Component {
  fromRef = React.createRef();
  state = {
    visible: true,
    bpmnModelXml: '',
    taskData: [],
    activityAssignee: {},
    activityIdList: [],
    currentActivityIdInfo: {},
  };
  componentDidMount() {
    console.log(this.props.selectedRows);

    this.refest();
  }
  /**
   * 取消model框，并调用父组件取消事件
   */
  onCancel = () => {
    this.setState({ visible: false });
    this.props.onCancel();
  };
  /**
   *
   * @param value 右侧树选中，并判断如果是父级，就不显示运行图
   * @returns
   */
  refest = (value) => {
    // 根据流程id请求运行图
    processInstancePreview({
      processInstanceId: this.props.selectedRows.procInstId,
    }).then((res) => {
      if (res.body?.bpmnModelXml) {
        this.setState({
          taskData: res.body.taskData,
          bpmnModelXml: res.body.bpmnModelXml,
          activityAssignee: res.body.activityAssignee,
          selectedKeys: this.state.value,
        });
      }
    });
    // 节点运行信息
    getBusinessProInstanceTasksByProInstanceId({
      procInstId: this.props.selectedRows.procInstId,
    }).then((res) => {
      console.log(res);
      if (res?.body) {
        this.setState({ activityIdList: res.body });
      }
    });
  };
  /**
   *
   * @param value 工作流流程图点击节点回调返回的函数
   */
  activityNodeInfo = (value) => {
    // console.log(value,'工作流传值');
    this.setState({ childrenDrawer: true });
    const { activityIdList } = this.state;
    this.fromRef.current.resetFields();
    this.fromRef.current.setFieldsValue({
      actId: value.activityId,
      procTaskName: value.activityIdType,
    });

    if (activityIdList) {
      activityIdList.map((item) => {
        if (item.actId == value.activityId) {
          this.fromRef.current.setFieldsValue(item);
        }
      });
    }
  };

  /**
   * 关闭节点信息右侧Drawer
   */
  onChildrenDrawerClose = () => {
    console.log('****************************');

    this.setState({ childrenDrawer: false });
  };

  // 处理任务状态
  taskStatus = (value) => {
    switch (value) {
      case '01':
        return '结束';
      case '02':
        return '准备';
      case '03':
        return '暂停';
      case '05':
        return '异常';
      case '06':
        return '终止';
      default:
        return '运行中';
    }
  };
  render() {
    return (
      <>
        <FcDrawer
          title={'流程跟踪'}
          visible={this.state.visible}
          onClose={this.onCancel}
          width={'100%'}
          height={'100%'}
          footer={null}
          className={styles.fullModal}
          bodyStyle={{ paddingTop: '12px' }}
          extra={<FcButton onClick={this.onCancel}>关闭</FcButton>}
        >
          <FcRow>
            <FcCol span={24}>
              <FcDivider orientation="left">点击节点查看任务运行信息</FcDivider>
              <div style={{ height: 550 }}>
                {this.state.bpmnModelXml ? (
                  <ProcessViewerModel
                    isUseNodeHistoricRecord // 是否隐藏运行态用户节点信息
                    isEffectNode
                    isShowGradientEffect
                    processInstanceId={this.props.selectedRows.procInstId} // 当前流程id
                    taskData={this.state.taskData} // 流程任务数据
                    xmlData={this.state.bpmnModelXml} //流程xml
                    activityAssignee={this.state.activityAssignee} //节点处理人
                    activityNodeInfo={this.activityNodeInfo} //回调函数
                  ></ProcessViewerModel>
                ) : (
                  <FcEmpty></FcEmpty>
                )}
              </div>
            </FcCol>
          </FcRow>
        </FcDrawer>

        {/* 点击节点显示左侧抽屉 */}
        <FcDrawer
          title="任务运行列表信息"
          width={450}
          closable={true}
          mask={false}
          onClose={this.onChildrenDrawerClose}
          visible={this.state.childrenDrawer}
        >
          <FcForm
            labelCol={{ span: 5 }}
            wrapperCol={{ span: 19 }}
            ref={this.fromRef}
            labelAlign="right"
          >
            <FcForm.Item label="节点id" name="actId">
              <FcInput readOnly placeholder="暂无" />
            </FcForm.Item>

            <FcForm.Item label="任务类名" name="listenerClassName">
              <FcInput readOnly placeholder="暂无" />
            </FcForm.Item>
            <FcForm.Item label="任务方法" name="listenerClassMethod">
              <FcInput readOnly placeholder="暂无" />
            </FcForm.Item>
            <FcForm.Item label="业务名称" name="procTaskName">
              <FcInput readOnly placeholder="暂无" />
            </FcForm.Item>
            <FcForm.Item label="开始时间" name="createTime">
              <FcInput readOnly placeholder="暂无" />
            </FcForm.Item>
            <FcForm.Item label="结束时间" name="updateTime">
              <FcInput readOnly placeholder="暂无" />
            </FcForm.Item>
            <FcForm.Item label="插件类型" name="busType">
              <FcInput readOnly placeholder="暂无" />
            </FcForm.Item>

            <FcForm.Item label="错误信息" name="errorMessage">
              <TextArea
                readOnly
                style={{ height: '150px' }}
                placeholder="暂无"
              />
            </FcForm.Item>
          </FcForm>
        </FcDrawer>
      </>
    );
  }
}

export default FullModal;
