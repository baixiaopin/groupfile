// @ts-nocheck
import React, { Component } from 'react';
import {
  FcConfigProvider,
  FcCol,
  FcRow,
  FcForm,
  FcSelect,
  FcInput,
  FcCard,
  FcSpace,
  FcButton,
  FcTable,
  FcMessage,
  FcModal,
  FcDivider,
  FcPopconfirm,
  FcTooltip as Tooltip,
  FcSpin,
  FcNotification,
} from '@ngfed/fc-components';
const { TextArea } = FcInput;
import ProcessTrace from './components/index';
import {
  getBusinessProInstances,
  processInstanceContinueRunning,
  proInstAddRemarksAndAlterPeople,
} from './service';
import zhCN from 'antd/lib/locale/zh_CN';
import StyleSheet from './index.less';
import './index.less';
export default class index extends Component {
  searchForm = React.createRef();
  editFormRef = React.createRef();
  state = {
    columns: [
      {
        title: '业务流转实例标识',
        dataIndex: 'businessKey',
        ellipsis: {
          showTitle: true,
        },
        sorter: (a, b) => {
          let stringA = a.businessKey?.toUpperCase();
          let stringB = b.businessKey?.toUpperCase();
          if (stringA < stringB) {
            return -1;
          }
          if (stringA > stringB) {
            return 1;
          }
          return 0;
        },
      },
      {
        title: '业务事件名称',
        dataIndex: 'modelName',
        ellipsis: {
          showTitle: true,
        },
        sorter: (a, b) => {
          let stringA = a.modelName?.toUpperCase();
          let stringB = b.modelName?.toUpperCase();
          if (stringA < stringB) {
            return -1;
          }
          if (stringA > stringB) {
            return 1;
          }
          return 0;
        },
      },
      {
        title: '业务流转事件状态',
        dataIndex: 'taskStatus',
        ellipsis: {
          showTitle: true,
        },
        filters: [
          {
            text: '准备',
            value: '02',
          },
          {
            text: '运行中',
            value: '00',
          },
          {
            text: '暂停',
            value: '03',
          },
          {
            text: '异常',
            value: '05',
          },
          {
            text: '结束',
            value: '01',
          },
          {
            text: '终止',
            value: '06',
          },
        ],
        // filterMultiple: false,
        onFilter: (value, record) => record.taskStatus.indexOf(value) === 0,
        render: (taskStatus) => this.taskStatus(taskStatus),
      },
      {
        title: '业务流水号',
        dataIndex: 'businessId',
        ellipsis: {
          showTitle: true,
        },
        // sorter: (a, b) => {
        //   let stringA = a.businessId?.toUpperCase();
        //   let stringB = b.businessId?.toUpperCase();
        //   if (stringA < stringB) {
        //     return -1;
        //   }
        //   if (stringA > stringB) {
        //     return 1;
        //   }
        //   return 0;
        // },
        render: (text, record) => (
          <a
            onClick={(e) => {
              e.preventDefault();
              this.handleModeChange('viewer');
            }}
          >
            {text}
          </a>
        ),
      },

      {
        title: '当前环节',
        dataIndex: 'actName',
        ellipsis: {
          showTitle: true,
        },
      },
      {
        title: '备注',
        dataIndex: 'remarks',
        ellipsis: {
          showTitle: true,
        },
        sorter: (a, b) => {
          let stringA = a.remarks?.toUpperCase();
          let stringB = b.remarks?.toUpperCase();
          if (stringA < stringB) {
            return -1;
          }
          if (stringA > stringB) {
            return 1;
          }
          return 0;
        },
      },
      {
        title: '修改时间',
        dataIndex: 'updateTime',
        ellipsis: {
          showTitle: true,
        },
        sorter: (a, b) => {
          let stringA = a.updateTime?.toUpperCase();
          let stringB = b.updateTime?.toUpperCase();
          if (stringA < stringB) {
            return -1;
          }
          if (stringA > stringB) {
            return 1;
          }
          return 0;
        },
      },
      {
        title: '修改人',
        dataIndex: 'alterPeople',
        ellipsis: {
          showTitle: true,
        },
        sorter: (a, b) => {
          let stringA = a.handel?.toUpperCase();
          let stringB = b.handel?.toUpperCase();
          if (stringA < stringB) {
            return -1;
          }
          if (stringA > stringB) {
            return 1;
          }
          return 0;
        },
      },

      {
        title: '事件开始时间',
        dataIndex: 'createTime',
        ellipsis: {
          showTitle: true,
        },
        sorter: (a, b) => {
          let stringA = a.createTime?.toUpperCase();
          let stringB = b.createTime?.toUpperCase();
          if (stringA < stringB) {
            return -1;
          }
          if (stringA > stringB) {
            return 1;
          }
          return 0;
        },
      },
      {
        title: '事件结束时间',
        dataIndex: 'endTime',
        ellipsis: {
          showTitle: true,
        },
        sorter: (a, b) => {
          let stringA = a.createTime?.toUpperCase();
          let stringB = b.createTime?.toUpperCase();
          if (stringA < stringB) {
            return -1;
          }
          if (stringA > stringB) {
            return 1;
          }
          return 0;
        },
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',

        width: 180,
        fixed: 'right',
        render: (text, record, index) => (
          <>
            <a
              onClick={(e) => {
                e.preventDefault();
                this.handleModeChange('viewer');
              }}
            >
              查看
            </a>
            <FcDivider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />
            <FcPopconfirm
              title="确认续跑？"
              onConfirm={() => this.handleModeChange('continueRun')}
              okText="是"
              cancelText="否"
            >
              <a>续跑</a>
            </FcPopconfirm>
            <FcDivider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />
            <a
              onClick={(e) => {
                e.preventDefault();
                this.handleModeChange('edit', record);
              }}
            >
              修改
            </a>
          </>
        ),
      },
    ],
    record: {},
    tableData: [],
    selectedRowKeys: [],
    selectedRows: {},
    processTraceVisable: false,
    editModal: false,
    total: 10,
    pagination: {
      current: 1,
      pageSize: 10,
      total: 0,
    },
    isSpend: true,
    loading: false,
  };
  // 处理任务状态
  taskStatus = (value) => {
    switch (value) {
      case '01':
        return '结束';
      case '02':
        return '准备';
      case '03':
        return '暂停';
      case '05':
        return '异常';
      case '06':
        return '终止';
      default:
        return '运行中';
    }
  };
  // 搜索
  search = () => {
    const value = this.searchForm.current.getFieldsValue();
    this.setState({ selectedRowKeys: [], selectedRows: {} });
    this.setState(
      {
        pagination: {
          current: 1,
          pageSize: 10,
          total: 0,
        },
      },
      () => {
        this.getBusinessProInstances(value);
      },
    );
  };
  searchTemp = () => {
    const { pagination } = this.state;
    const value = this.searchForm.current.getFieldsValue();
    getBusinessProInstances({
      ...value,
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    }).then((res) => {
      // console.log(res.body,"123123");
      // console.log("123123");

      if (res?.body) {
        pagination.current = res.body.curNum;
        pagination.total = res.body.total;
        res.body.baseBusinessTasks.map((item) => {
          item.taskStatus = item.taskStatus || '00';
        });
        this.setState({ tableData: res.body.baseBusinessTasks, pagination });
      }
    });
  };
  // 查询无结果警告
  warning = () => {
    FcMessage.warn('满足查询条件的结果不存在');
  };
  componentDidMount() {
    this.getBusinessProInstances();
  }

  /**
   * 获取数据类型
   * @param {*} obj
   */
  getTypeByObj = (obj) => {
    return Object.prototype.toString
      .call(obj)
      .match(/^\[object ([a-zA-Z]*)\]$/)[1];
  };
  //  非空判断
  isEmptyObject = (obj) => {
    for (var key in obj) {
      return false;
    }
    return true;
  };

  // 重置
  reset = () => {
    this.searchForm.current.resetFields();
    this.setState(
      {
        pagination: {
          current: 1,
          pageSize: 10,
          total: 0,
        },
      },
      () => {
        this.search();
      },
    );
  };

  getBusinessProInstances = (value) => {
    const { pagination } = this.state;
    getBusinessProInstances({
      ...value,
      // findAllStatus:'00',
      pageNum: pagination.current,
      pageSize: pagination.pageSize,
    }).then((res) => {
      if (res?.body) {
        pagination.current = res.body.curNum;
        pagination.total = res.body.total;
        res.body.baseBusinessTasks.map((item) => {
          item.taskStatus = item.taskStatus || '00';
        });
        this.setState(
          { tableData: res.body.baseBusinessTasks, pagination },
          () => {
            if (this.state.tableData.length == 0) {
              this.warning();
            }
          },
        );
      }
    });
  };

  //查询历史记录
  handleModeChange = (value, record) => {
    switch (value) {
      case 'viewer':
        this.setState({ processTraceVisable: true });
        break;
      case 'continueRun':
        this.setState({ loading: true });
        let procInstIdTemp = this.props.procInstId
          ? this.props.procInstId
          : 'procInstId';
        processInstanceContinueRunning(
          {
            [procInstIdTemp]: this.state.selectedRows.procInstId,
            stdSvcInd: this.props.stdSvcInd,
            stdIntfcInd: this.props.stdIntfcInd,
            srcConsmSysInd: this.props.srcConsmSysInd,
            stdIntfcVerNo: this.props.stdIntfcVerNo,
          },
          procInstIdTemp,
        ).then((res) => {
          if (res.sysHead.retCd == '000000') {
            FcMessage.warn('续跑成功');
            setTimeout(() => {
              this.searchTemp();
              this.setState({ loading: false });
            }, 100);
          } else {
            FcNotification.error({
              message: `系统错误`,
              description:
                res?.sysHead?.retInf != ''
                  ? res?.sysHead?.retInf
                  : res?.sysHead?.retCd,
            });
            this.setState({ loading: false });
          }
        });
        break;
      default:
        this.setState({ editModal: true, record }, () => {
          console.log(record);

          setTimeout(() => {
            this.editFormRef?.current.setFieldsValue(record);
          }, 200);
        });
        break;
    }
  };
  editUserOK = () => {
    let alterPeople = window.localStorage.getItem('empNo');
    let remarks = this.editFormRef.current.getFieldsValue();
    proInstAddRemarksAndAlterPeople({
      ...remarks,
      alterPeople,
      procInstId: this.state.selectedRows.procInstId,
    }).then((res) => {
      // console.log(res);
      this.search();
    });

    this.setState({ editModal: false });
  };
  // 取消流程查看
  onCancel = () => {
    this.setState({ processTraceVisable: false });
  };
  render() {
    const { columns, tableData, selectedRowKeys, selectedRows } = this.state;
    const layout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 18 },
    };
    const formLayout = {
      labelCol: {
        span: 8,
      },
      wrapperCol: {
        span: 16,
      },
    };
    return (
      <FcConfigProvider locale={zhCN}>
        <FcSpin spinning={this.state.loading}>
          <FcCard>
            <FcForm ref={this.searchForm} {...layout}>
              <FcRow justify="space-between">
                <FcCol span={10}>
                  <FcForm.Item
                    label="业务流转实例标识"
                    name="businessKey"
                    style={{ marginLeft: 16, marginBottom: 0 }}
                  >
                    <FcInput placeholder="请输入业务流转实例标识"></FcInput>
                  </FcForm.Item>
                </FcCol>
                <FcCol span={10}>
                  <FcForm.Item
                    label="业务事件名称"
                    name="modelName"
                    style={{ marginLeft: 16 }}
                  >
                    <FcInput placeholder="请输入业务事件名称"></FcInput>
                  </FcForm.Item>
                </FcCol>
              </FcRow>
              {this.state.isSpend && (
                <FcRow justify="space-between">
                  <FcCol span={10}>
                    <FcForm.Item
                      label="业务流转事件状态"
                      name="findAllStatus"
                      style={{ marginLeft: 16 }}
                    >
                      <FcSelect placeholder="业务流转事件状态">
                        <FcSelect.Option>全部</FcSelect.Option>
                        <FcSelect.Option value="02">准备</FcSelect.Option>
                        <FcSelect.Option value="00">运行中</FcSelect.Option>
                        <FcSelect.Option value="03">暂停</FcSelect.Option>
                        <FcSelect.Option value="05">异常</FcSelect.Option>
                        <FcSelect.Option value="01">结束</FcSelect.Option>
                        <FcSelect.Option value="06">终止</FcSelect.Option>
                      </FcSelect>
                    </FcForm.Item>
                  </FcCol>
                  <FcCol span={10}>
                    <FcForm.Item
                      label="业务流水号"
                      name="businessId"
                      style={{ marginLeft: 16 }}
                    >
                      <FcInput placeholder="请输入业务流水号"></FcInput>
                    </FcForm.Item>
                  </FcCol>
                </FcRow>
              )}

              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <a
                  onClick={() => {
                    this.setState({ isSpend: !this.state.isSpend });
                  }}
                >
                  {this.state.isSpend ? '收起' : '展开'}{' '}
                </a>
              </div>
              <FcRow justify="center">
                <FcCol>
                  <FcSpace style={{ marginBottom: 12 }}>
                    <FcButton
                      onClick={this.search}
                      style={{ marginRight: 5 }}
                      type="primary"
                    >
                      搜索
                    </FcButton>
                    <FcButton onClick={this.reset}>重置</FcButton>
                  </FcSpace>
                </FcCol>
              </FcRow>
            </FcForm>
            {/* <FcRow>
            <FcCol>
              <div className={StyleSheet.imgMarginPadding}>
                <FcSpace>
                  <FcButton
                    onClick={() => this.handleModeChange('viewer')}
                    type="primary"
                  >
                    <img src={View} /> 查看
                  </FcButton>
                  <FcButton
                    onClick={() => this.handleModeChange('continueRun')}
                    type="default"
                  >
                    <img src={Continue} /> 续跑
                  </FcButton>
                  <FcButton
                    onClick={() => this.handleModeChange('edit')}
                    type="default"
                  >
                    <img src={Modify} /> 修改
                  </FcButton>
                </FcSpace>
              </div>
            </FcCol>
          </FcRow> */}
            <div className={StyleSheet.blueTable}>
              <FcTable
                columns={columns}
                dataSource={tableData}
                bordered
                rowKey={(record) => record.id}
                scroll={{
                  x: '150%',
                  y: '550px',
                }}
                onRow={(record) => {
                  return {
                    onClick: (event) => {
                      this.setState({
                        selectedRowKeys: [record.id],
                        selectedRows: record,
                      });
                    }, // 点击行
                  };
                }}
                pagination={{
                  showTotal: (total) => `共 ${total} 条数据`,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  current: this.state.pagination.current,
                  pageSize: this.state.pagination.pageSize,
                  total: this.state.pagination.total,
                  onChange: (page, pageSize) => {
                    this.setState(
                      {
                        pagination: {
                          ...this.state.pagination,
                          current: page,
                          pageSize,
                        },
                      },
                      () => {
                        this.searchTemp();
                      },
                    );
                  },
                }}
              ></FcTable>
            </div>
            {this.state.processTraceVisable && (
              <ProcessTrace
                onCancel={this.onCancel}
                selectedRows={selectedRows}
              ></ProcessTrace>
            )}
          </FcCard>
        </FcSpin>
        {/* 修改出现模态框 */}
        <FcModal
          destroyOnClose
          cancelText="取消"
          okText="确定"
          title="修改"
          width="44%"
          visible={this.state.editModal}
          onOk={this.editUserOK}
          onCancel={() => {
            this.setState({ editModal: false });
          }}
        >
          <FcForm ref={this.editFormRef} {...formLayout}>
            <FcRow>
              <FcCol span={12}>
                <FcForm.Item label="业务流水号" name="businessId" disabled>
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>
              <FcCol span={12}>
                <FcForm.Item label="业务事件名称" name="modelName">
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>
              <FcCol span={12}>
                <FcForm.Item label="业务流转实体标识" name="businessKey">
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>{' '}
              <FcCol span={12}>
                <FcForm.Item label="当前环节" name="actName">
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>{' '}
              <FcCol span={12}>
                <FcForm.Item label="业务流转事件状态" name="taskStatus">
                  <FcSelect disabled placeholder="暂无信息">
                    <FcSelect.Option>全部</FcSelect.Option>
                    <FcSelect.Option value="02">准备</FcSelect.Option>
                    <FcSelect.Option value="00">运行中</FcSelect.Option>
                    <FcSelect.Option value="03">暂停</FcSelect.Option>
                    <FcSelect.Option value="05">异常</FcSelect.Option>
                    <FcSelect.Option value="01">结束</FcSelect.Option>
                    <FcSelect.Option value="06">终止</FcSelect.Option>
                  </FcSelect>
                </FcForm.Item>
              </FcCol>
              <FcCol span={12}>
                <FcForm.Item label="事件开始时间" name="createTime">
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>
              <FcCol span={12}>
                <FcForm.Item label="事件结束时间" name="endTime">
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>
              <FcCol span={12}>
                <FcForm.Item label="修改人" name="alterPeople">
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>
              <FcCol span={12}>
                <FcForm.Item label="修改时间" name="updateTime">
                  <FcInput disabled placeholder="暂无信息"></FcInput>
                </FcForm.Item>
              </FcCol>
            </FcRow>
            <FcRow>
              <FcCol span={12}>
                <FcForm.Item
                  label="备注"
                  name="remarks"
                  rules={[{ max: 30, message: '长度不能大于30！' }]}
                >
                  <TextArea
                    maxLength={30}
                    showCount
                    style={{ height: '80px' }}
                    placeholder="请输入"
                  />
                </FcForm.Item>
              </FcCol>
            </FcRow>
            <FcRow></FcRow>
          </FcForm>
        </FcModal>
      </FcConfigProvider>
    );
  }
}
