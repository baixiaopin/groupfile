// @ts-nocheck
import React from 'react';
import {
  FcButton as Button,
  FcCard as Card,
  FcDivider as Divider,
  FcForm as Form,
  FcInput as Input,
  FcModal as Modal,
  FcPopconfirm as Popconfirm,
  FcTable as Table,
  FcTreeSelect as TreeSelect,
  FcMessage as message,
  FcTooltip as Tooltip,
  FcInputNumber as InputNumber,
  FcSpin as Spin,
  FcSelect as Select,
  FcRow,
  FcCol
} from '@ngfed/fc-components';
import { FormInstance } from 'antd/lib/form';
import {
  deleteModelType,
  editModelType,
  getModelTypeByCondition,
  getModelTypeList,
  newBuildModelType,
  getModelTypeOptions,
  toDoTypeList,
  outPutModel
} from './service.js';
import Moment, { locale } from 'moment';
interface searchForm {
  typeCode: string;
  typeName: string;
}
import PlugConfig from './components/PlugConfig';
import './index.less'
class ModelType extends React.Component<any, any> {
  state = {
    loading: false,
    newBuildVisible: false,
    editVisble: false,
    modelTypeList: [],
    modelTypeOptions: [],
    currentEditRowData: null,
    toDoTypeList: [],
    columns: [
      {
        title: '类型编号',
        dataIndex: 'typeCode',
        ellipsis: {
          showTitle: false,
        },
        render: (typeCode) => (
          <Tooltip placement="topLeft" title={typeCode}>
            {typeCode}
          </Tooltip>
        ),
      },
      {
        title: '类型名称',
        dataIndex: 'typeName',
        ellipsis: {
          showTitle: false,
        },
        render: (typeName) => (
          <Tooltip placement="topLeft" title={typeName}>
            {typeName}
          </Tooltip>
        ),
      },
      {
        title: '排序号',
        dataIndex: 'sort',
        ellipsis: {
          showTitle: false,
        },
        render: (sort) => (
          <Tooltip placement="topLeft" title={sort}>
            {sort}
          </Tooltip>
        ),
      },
      {
        title: '待办类型',
        dataIndex: 'toDoTypeName',
        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => (
          <Tooltip
            placement="topLeft"
            title={record.toDoTypeResp?.toDoTypeName}
          >
            {record.toDoTypeResp?.toDoTypeName}
          </Tooltip>
        ),
      },
      {
        title: '描述',
        dataIndex: 'description',
        showTitle: false,
        ellipsis: {
          showTitle: false,
        },
        render: (description) => (
          <Tooltip placement="topLeft" title={description}>
            {description}
          </Tooltip>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return (
            <Tooltip
              placement="topLeft"
              title={text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
            >
              {text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
            </Tooltip>
          );
        },
      },

      {
        title: '修改时间',
        dataIndex: 'updateTime',
        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return (
            <Tooltip
              placement="topLeft"
              title={text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
            >
              {text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
            </Tooltip>
          );
        },
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: '300px',
        render: (text, record, index) => {
          return (
            <>
              <a
                onClick={(e) => {
                  e.preventDefault();
                  this.openEdit(record);
                }}
              >
                编辑
              </a>

              <Divider type="vertical" />
              <a
                onClick={(e) => {
                  e.preventDefault();
                  this.openNewBuild(record);
                }}
              >
                新增
              </a>
              <Divider type="vertical" />
              <Popconfirm
                title="是否删除？"
                onConfirm={() => this.delete(record)}
                okText="是"
                cancelText="否"
              >
                <a>删除</a>
              </Popconfirm>
              <Divider type="vertical" />
                <a    
                  onClick={(e) => {
                  e.preventDefault();
                  this.exportTwo(record);
                }}>导出</a>
              <Divider type="vertical" />
              <a
                onClick={(e) => {
                  e.preventDefault();
                  this.plugConfig(record);
                }}
              >
                节点插件配置
              </a>
            </>
          );
        },
      },
    ],
    plugConfigVisable: false,
    configurationKeys: null,
    exportTwoVisable:false,
  };

  searchFormRef = React.createRef<FormInstance>();
  newBuildFormRef = React.createRef<FormInstance>();
  editFormRef = React.createRef<FormInstance>();

  componentDidMount() {
    this.searchAll();
  }
  // 导出
  exportTwo=(record)=>{
    console.log(record);
    this.setState({ exportTwoVisable: true, currentEditRowData: record });
  }
// 下载 
handleDwnloadJSON=(type)=>{
  let json = this.state.currentEditRowData
  outPutModel({
    modelId: json.id,
    modelTypeId:"00",
    outputType: "01",
  }).then((res) => {
    console.log(res);
    return false
    let filename = res.body.modelInfo.name;
    let contentType = 'application/json;charset=utf-8';
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      let blob = new Blob(
        [decodeURIComponent(encodeURI(JSON.stringify(res.body)))],
        { type: contentType },
      );
      navigator.msSaveOrOpenBlob(blob, filename);
    } else {
      let a = document.createElement('a');
      a.download = filename;
      a.href =
        'data:' +
        contentType +
        ',' +
        encodeURIComponent(JSON.stringify(res.body));
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  });
}
  // 插件配置
  plugConfig = (record) => {
    // console.log(record);
    this.setState({ plugConfigVisable: true, currentEditRowData: record });
  };
  // 点击搜索按钮
  clickSearchBtn = () => {
    const { typeCode, typeName } = this.searchFormRef.current?.getFieldsValue();
    if (typeCode.length === 0 && typeName.length === 0) {
      this.searchAll();
    } else {
      this.conditionSearch();
    }
  };

  searchAll = async () => {
    this.setState({ loading: true });
    const response = await getModelTypeList();
    // console.log(response);

    this.setState({
      modelTypeList: response?.body.length && response?.body,
      loading: false,
    });
  };

  // 条件查询
  conditionSearch = async () => {
    this.setState({ loading: true });
    const searchForm = this.searchFormRef.current?.getFieldsValue();
    const response = await getModelTypeByCondition(searchForm);
    this.setState({
      modelTypeList: response?.body,
      loading: false,
    });
  };

  // 重置
  reset = () => {
    this.searchFormRef.current?.resetFields();
    this.searchAll();
  };

  // 新建
  openNewBuild = (record) => {
    console.log(record);

    this.setState(
      {
        newBuildVisible: true,
        loading: true,
      },
      () => {
        this.newBuildFormRef.current?.setFieldsValue({
          parentId: record?.id ? record?.id : '0',
        });
      },
    );
    getModelTypeOptions().then((res) => {
      this.setState({
        modelTypeOptions: res.body,
        loading: false,
      });
    });
    toDoTypeList().then((res) => {
      console.log(res);
      if (res.sysHead.retCd == '000000') {
        this.setState({ toDoTypeList: res.body, loading: false });
      }
    });
  };

  closeNewBuild = () => {
    this.setState({
      newBuildVisible: false,
    });
  };

  confirmNewBuild = async () => {
    try {
      const newBuildForm = await this.newBuildFormRef.current?.validateFields();
      this.setState({ loading: true });
      newBuildModelType(newBuildForm).then((res) => {
        if (res.sysHead.retCd === '000000') {
          this.closeNewBuild();
          message.success('新增成功！');
          this.clickSearchBtn();
        }
        this.setState({ loading: false });
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 编辑
  openEdit = (record) => {
    this.setState({
      editVisble: true,
      currentEditRowData: record,
    });
    getModelTypeOptions().then((res) => {
      this.setState({
        modelTypeOptions: res.body,
      });
    });
    toDoTypeList().then((res) => {
      console.log(res);
      if (res.sysHead.retCd == '000000') {
        this.setState({ toDoTypeList: res.body });
      }
    });
    setTimeout(() => {
      this.editFormRef.current?.setFieldsValue(record);
      this.editFormRef.current?.setFieldsValue({
        toDoTypeId: record?.toDoTypeResp?.id,
      });
    }, 100);
  };

  closeEdit = () => {
    this.setState({
      editVisble: false,
    });
  };

  confirmEdit = async () => {
    this.setState({ loading: true });
    const editForm = await this.editFormRef.current?.validateFields();
    editForm.sort = Number(editForm.sort);
    editModelType({
      ...editForm,
      id: this.state.currentEditRowData.id,
    }).then((res) => {
      if (res.sysHead.retCd == '000000') {
        message.success('修改成功');
        this.closeEdit();
        this.clickSearchBtn();
      }
      this.setState({ loading: false });
    });
  };

  // 删除
  delete = (record: any) => {
    this.setState({ loading: true });
    deleteModelType(record.id).then((res) => {
      this.setState({ loading: false });
      if (res.sysHead.retCd == '000000') {
        message.success('删除成功');
        this.clickSearchBtn();
      }
    });
  };

  onChange = (checkedValues) => {
    // console.log('checked = ', checkedValues);
  };

  /**
   *
   * @returns 插件传值
   */
  configurationKeyList = (e) => {
    // console.log(e);
    this.setState({ plugConfigVisable: false }, () => {
      this.clickSearchBtn();
    });
  };
  render() {
    const isCheck = true;
    return (
      <Spin spinning={this.state.loading}>
        <Card style={{ marginBottom: 8 }}>
          <Form
            ref={this.searchFormRef}
            layout="inline"
            initialValues={{
              typeCode: '',
              typeName: '',
            }}
            style={{ marginLeft: 16 }}
            onFinish={this.clickSearchBtn}
          >
            <Form.Item
              label="类型编号"
              name="typeCode"
              style={{ marginBottom: 0 }}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="类型名称"
              name="typeName"
              style={{ marginBottom: 0 }}
            >
              <Input />
            </Form.Item>
            <Form.Item style={{ margin: 'auto 0' }}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.reset}>
                重置
              </Button>
            </Form.Item>
          </Form>
        </Card>
        <Card
          title="模型类型"
          extra={
          <div>
            <Button style={{marginRight:'12px'}} type="primary" onClick={this.openNewBuild}>
              导入
            </Button>
              <Button type="primary" onClick={this.openNewBuild}>
              新建
            </Button>
          </div>
          }
        >
          <Table
            dataSource={this.state.modelTypeList}
            rowKey={(record) => record.id}
            pagination={false}
            bordered
            columns={this.state.columns}
          ></Table>
        </Card>

        {this.state.newBuildVisible && (
          <Modal
            title="新建"
            visible={this.state.newBuildVisible}
            okText="确认"
            cancelText="取消"
            maskClosable={false}
            onOk={this.confirmNewBuild}
            onCancel={this.closeNewBuild}
          >
            <Form ref={this.newBuildFormRef} layout="horizontal">
              <Form.Item
                label="类型编号"
                name="typeCode"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  { required: isCheck, message: '请输入' },
                  {
                    pattern: /^[^ ]{1,32}$/,
                    message: '不能以空格开头，编号不能太长',
                  },
                ]}
              >
                <Input placeholder="请输入" />
              </Form.Item>
              <Form.Item
                label="类型名称"
                name="typeName"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  { required: true, message: '请输入' },
                  {
                    pattern: /^[^ ]{1,32}$/,
                    message: '不能以空格开头，名称不能太长',
                  },
                ]}
              >
                <Input placeholder="请输入" />
              </Form.Item>
              <Form.Item
                label="父类ID"
                name="parentId"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                style={{ display: 'none' }}
                // rules={[
                //   {
                //     required: true,
                //     message: '必填',
                //   },
                // ]}
              >
                <TreeSelect
                  treeData={this.state.modelTypeOptions}
                  treeDefaultExpandAll
                  placeholder="请选择"
                />
              </Form.Item>
              <Form.Item
                label="待办类型"
                name="toDoTypeId"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  {
                    required: true,
                    message: '必选',
                  },
                ]}
              >
                <Select showSearch placeholder="请选择">
                  {this.state.toDoTypeList &&
                    this.state.toDoTypeList.map((item, index) => {
                      return (
                        <Option key={item.id} value={item.id}>
                          {item.toDoTypeName}
                        </Option>
                      );
                    })}
                </Select>
              </Form.Item>
              <Form.Item
                label="排序号"
                name="sort"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
              >
                <InputNumber
                  min={0}
                  style={{ width: '100%' }}
                  placeholder="请输入"
                />
              </Form.Item>
              <Form.Item
                label="描述"
                name="description"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
              >
                <Input.TextArea placeholder="请输入" />
              </Form.Item>
            </Form>
          </Modal>
        )}

        {this.state.editVisble && (
          <Modal
            title="编辑"
            visible={this.state.editVisble}
            okText="确认"
            cancelText="取消"
            maskClosable={false}
            onOk={this.confirmEdit}
            onCancel={this.closeEdit}
          >
            <Form ref={this.editFormRef} layout="horizontal">
              <Form.Item
                label="类型编号"
                name="typeCode"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  { required: true },
                  {
                    pattern: /^[^ ]{1,32}$/,
                    message: '不能以空格开头，编号不能太长',
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="类型名称"
                name="typeName"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  { required: true },
                  {
                    pattern: /^[^ ]{1,32}$/,
                    message: '不能以空格开头，名称不能太长',
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="父类ID"
                name="parentId"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  {
                    required: true,
                    message: '必填',
                  },
                ]}
              >
                <TreeSelect
                  treeData={this.state.modelTypeOptions}
                  treeDefaultExpandAll
                />
              </Form.Item>
              <Form.Item
                label="待办类型"
                name="toDoTypeId"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
              >
                <Select showSearch placeholder="请选择">
                  {this.state.toDoTypeList &&
                    this.state.toDoTypeList.map((item, index) => {
                      return (
                        <Option key={item.id} value={item.id}>
                          {item.toDoTypeName}
                        </Option>
                      );
                    })}
                </Select>
              </Form.Item>
              <Form.Item
                label="排序号"
                name="sort"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
              >
                <InputNumber min={0} style={{ width: '100%' }} />
              </Form.Item>
              <Form.Item
                label="描述"
                name="description"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
              >
                <Input.TextArea />
              </Form.Item>
            </Form>
          </Modal>
        )}
        {this.state.plugConfigVisable && (
          <PlugConfig
            tranferConfigurationKeyList={this.configurationKeyList}
            currentEditRowData={this.state.currentEditRowData}
          ></PlugConfig>
        )}
        {
          this.state.exportTwoVisable&&(
            <Modal title="请选择下载格式" visible={this.state.exportTwoVisable}
             footer={null}  onCancel={()=>this.setState({exportTwoVisable:false})}>
              <FcRow>
                模型类型名称：{this.state.currentEditRowData?.typeName}
              </FcRow>
           <FcRow>
           <Button style={{ borderRadius: '16px !important' }} 
           className={'uploadBoxButton'} 
           onClick={()=>this.handleDwnloadJSON('01')}>JSON下载</Button>
             <Button className={'uploadBoxButton'} onClick={this.handleDwnloadSvg}>SQL下载</Button>
           </FcRow>
          </Modal>
          )
        }
      </Spin>
    );
  }
}

export default ModelType;
