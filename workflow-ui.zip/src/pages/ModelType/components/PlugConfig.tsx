// @ts-nocheck
// 业务配置组件
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcInput as Input,
  FcModal as Modal,
  FcPopconfirm as Popconfirm,
  FcTable as Table,
  FcMessage as message,
  FcConfigProvider as ConfigProvider,
  FcBadge as Badge,
  FcSelect as Select,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import zhCN from 'antd/lib/locale/zh_CN';
import { getConfigurationKey, saveConfigurationKey } from '../service';
import StyleSheet from '../index.less';
import Paramater from './Paramater';
class PlugConfig extends Component {
  formRef = React.createRef();
  state = {
    loading: true,
    // 配置列表
    columns: [
      {
        dataIndex: 'keyVkeyV',
        key: 'keyVkeyV',
        title: 'key',
        width: '25%',
        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.keyVkeyV}
              style={{ width: '150px' }}
              onChange={(value) => this.handleChangeKey(value, record, index)}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'value',
        key: 'value',
        title: '插件类型',
        render: (_, record, index) => {
          return (
            <Select
              placeholder="请选择"
              onChange={(value) => this.handleChangeType(value, record, index)}
              value={record.value}
              style={{ width: '100px' }}
            >
              <Select.Option value="Object">Object</Select.Option>
              <Select.Option value="Boolean">Boolean</Select.Option>
              <Select.Option value="String">String</Select.Option>
              <Select.Option value="Array">Array</Select.Option>
              <Select.Option value="Arrays">Arrays</Select.Option>
            </Select>
          );
        },
      },
      {
        dataIndex: 'description',
        key: 'description',
        title: '描述',

        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.description}
              onChange={(value) => this.handleChangeDec(value, record, index)}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'description',
        key: 'description',
        title: '参数',

        render: (_, record, index) => {
          if (record.value == 'Array' || record.value == 'Arrays') {
            return (
              <Badge
                count={record.paramaterData?.length}
                style={{ backgroundColor: '#52c41a' }}
              >
                <Button
                  type="primary"
                  onClick={(value) => {
                    this.paramater(value, record, index);
                  }}
                >
                  配置
                </Button>
              </Badge>
            );
          } else {
            return <Button disabled>配置</Button>;
          }
        },
      },
      {
        dataIndex: 'action',
        key: 'action',
        title: '操作',

        render: (_, record, index) => {
          return (
            <>
              <Popconfirm
                title="确定删除这条数据吗？"
                onConfirm={() => this.handleDelete(index)}
              >
                <a type="link">删除</a>
              </Popconfirm>
            </>
          );
        },
      },
    ],
    // 存服务插件配置
    configurationPlug: [],
    // 当前选中的列数据
    currentRowData: {},
    paramater: {},
    paramaterVisable: false,
    businessVisble: false,
  };

  componentDidMount() {
    const currentEditRowData = this.props.currentEditRowData;
    if (currentEditRowData) {
      getConfigurationKey({
        id: currentEditRowData.id,
      }).then((res) => {
        if (res.body?.configurationKeys) {
          res.body?.configurationKeys.map((item) => {
            item.keyVkeyV = item.keyV;
            delete item.keyV;
          });
        }
        this.setState({
          loading: false,
          configurationPlug: res.body?.configurationKeys
            ? res.body.configurationKeys
            : [],
        });
      });
    }
    this.setState({ businessVisble: true });
  }

  /**
   * 将数组重的服务插件和业务插件区分开
   * @param value
   * @returns
   */

  /**
   * 校验名称的唯一
   * @param {Object} record
   * @param {String} value
   */
  checkData(value) {
    const { configurationPlug } = this.state;
    const index = configurationPlug.findIndex((item) => {
      return item.keyV === value;
    });
    if (index !== -1) {
      message.error('key不能重复');
      return false;
    }
    return true;
  }

  /**
   * 处理key的改变 业务
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeKey(value, record, index) {
    //校验是否重复
    // if (!this.checkData(value.target.value)) return;
    const newData = [...this.state.configurationPlug];
    const item = newData[index];
    const cpRecord = record;
    // cpRecord.keyV = value.target.value;
    cpRecord.keyVkeyV = value.target.value;
    newData.splice(index, 1, { ...item, ...cpRecord });
    // console.log(newData);

    this.setState({
      configurationPlug: [...newData],
    });
  }

  /**
   * 处理描述字段的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeDec(value, record, index) {
    //校验是否重复
    // if (!this.checkData(value.target.value)) return;
    const newData = [...this.state.configurationPlug];
    const item = newData[index];
    const cpRecord = record;
    cpRecord.description = value.target.value;
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      configurationPlug: [...newData],
    });
  }

  /**
   * 处理字段的改变类型 业务和服务插件，判断 1:业务 2：服务
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeType(value, record, index) {
    //校验是否重复
    if (!this.checkData(value)) return;
    const newData = [...this.state.configurationPlug];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.value = value;
    // 判断类型是否为Array，如果不是则清除掉参数
    if (value != 'Array') {
      delete cpRecord.paramaterData;
    }
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      configurationPlug: [...newData],
    });
  }
  /**
   * 删除一条表格
   * @param {String} index
   */
  handleDelete = (index) => {
    // console.log('key', index);
    const newData = [...this.state.configurationPlug];
    newData.splice(index, 1);
    this.setState({
      configurationPlug: newData,
    });
  };

  /**
   * 新增一条表格
   */
  handleAdd = (e) => {
    const { configurationPlug } = this.state;
    let newData = {};
    newData = {
      description: null,
      value: null,
    };
    this.setState({
      configurationPlug: [...configurationPlug, newData],
    });
  };

  /**
   *
   * @returns 参数配置
   */
  paramater = (value, record, index) => {
    this.setState({
      paramaterVisable: true,
      currentRowData: record,
      paramater: JSON.parse(JSON.stringify(record)),
    });
  };

  confirmParamater = () => {
    this.setState({ paramaterVisable: false });
  };
  closeParamater = () => {
    this.setState({ paramaterVisable: false });
  };

  /**
   *
   * @returns 参数配置函数调用
   */
  confirmParamaterTer = (e) => {
    if (e == 'text') {
      this.setState({ paramaterVisable: false });
      return false;
    }
    const { currentRowData, configurationPlug } = this.state;
    currentRowData.paramaterData = e;
    this.setState(
      {
        paramaterVisable: false,
        currentRowData: currentRowData,
        configurationPlug: [],
      },
      () => {
        this.setState({ configurationPlug });
      },
    );
  };

  /**
   *
   * @returns 确认model框
   */

  confirmBusiness = () => {
    const { configurationPlug } = this.state;
    const newArray = configurationPlug;
    let flag = false;
    newArray?.map((item, index) => {
      item.keyV = item.keyVkeyV;
      delete item.keyVkeyV;
      if (!item.keyV) {
        // console.log(item, index);
        message.error('业务插件的key值必填，服务插件的Bea必选');
        flag = true;
        return false;
      }
      if (!item.value) {
        // console.log(item, index);
        message.error('插件的类型必选');
        flag = true;
        return false;
      }
    });
    if (flag) {
      return false;
    }
    this.setState({ loading: true });
    saveConfigurationKey({
      id: this.props.currentEditRowData.id,
      configurationKeys: newArray,
    }).then((res) => {
      // console.log(res);
      if (res.sysHead.retCd == '000000') {
        message.success('保存成功');
      }
      this.props.tranferConfigurationKeyList(newArray);
      this.setState({ businessVisble: false, loading: false });
    });
  };
  /**
   *
   * @returns 取消
   */
  cancelBusiness = () => {
    this.setState({ businessVisble: false });
    this.props.tranferConfigurationKeyList();
  };
  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Modal
          title="插件添加"
          visible={this.state.businessVisble}
          okText="确认"
          cancelText="取消"
          maskClosable={false}
          width="50%"
          onOk={this.confirmBusiness}
          onCancel={this.cancelBusiness}
          bodyStyle={{ paddingTop: 0 }}
        >
          <Spin spinning={this.state.loading}>
            <div className={StyleSheet.hiddleTabNavLeft}>
              <Button
                onClick={() => this.handleAdd('false')}
                type="primary"
                style={{ margin: '16px 0' }}
              >
                {' '}
                + 添加{' '}
              </Button>
              {/* <Scrollbars> */}
              <Table
                rowKey={(record) => record.keyV}
                // scroll={{ x: 700, y: 500 }}
                bordered
                dataSource={this.state.configurationPlug}
                columns={this.state.columns}
                pagination={false}
              />
            </div>
          </Spin>
          {this.state.paramaterVisable && (
            <Paramater
              paramaterData={this.state.paramater}
              confirmParamaterTer={this.confirmParamaterTer}
            ></Paramater>
          )}
        </Modal>
      </ConfigProvider>
    );
  }
}
export default PlugConfig;
