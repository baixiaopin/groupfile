import request from '../../utils/request';

const stdSvcInd = 'ModelTypeSVC';

/**
 * 查询模型列表
 */
export function getModelTypeList() {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelTypeSVC',
        stdIntfcInd: 'modelTypeList',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {},
    },
  });
}

/**
 * 条件查询模型列表
 * @param {*} searchForm
 */
export function getModelTypeByCondition(searchForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd,
        stdIntfcInd: 'getTypeByNameAndCode',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: searchForm,
    },
  });
}

export function getModelTypeOptions(searchForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelTypeSVC',
        stdIntfcInd: 'modelTypeOptions',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: searchForm,
    },
  });
}

export function newBuildModelType(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd,
        stdIntfcInd: 'insertType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}

export function editModelType(editForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd,
        stdIntfcInd: 'updateType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: editForm,
    },
  });
}

export function deleteModelType(id) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd,
        stdIntfcInd: 'removeType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
      },
    },
  });
}

// 获取节点插件配置
export function getConfigurationKey(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelTypeSVC',
        stdIntfcInd: 'getConfigurationKey',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}

// 保存节点插件配置
export function saveConfigurationKey(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelTypeSVC',
        stdIntfcInd: 'saveConfigurationKey',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}

// 查询代办类型
export function toDoTypeList(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ToDoTypeSVC',
        stdIntfcInd: 'toDoTypeList',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}
// 导出
export function outPutModel(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'outPutModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}
