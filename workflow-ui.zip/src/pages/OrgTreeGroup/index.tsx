// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcTag as Tag,
  FcCard as Card,
  FcTree as Tree,
  FcModal as Modal,
  FcForm as Form,
  FcInput as Input,
  FcTable as Table,
  FcRow as Row,
  FcCol as Col,
  FcRadio as Radio,
} from '@ngfed/fc-components';
import {
  getListOrgTrees,
  listPosition,
  getOrgAndChildOrg,
  listUserByOrg,
  getRoleByOrgId,
} from './service';
const { Column } = Table;
const { DirectoryTree } = Tree;
const { Search } = Input;
import StyleSheet from '../OrgTreeModal/index.less';
class OrgTreeGroup extends React.Component {
  state = {
    selectType: 'org',
    selectTree: '',
    delegateList: [],
    selectedRowKeys: [],
    orgTreeData: [],
    pageNum: 1,
    pageSize: '',
    total: '',
    search: '',
    treeData: null,
    // 控制变量是否自动生成
    onChangeActivity: 1,
    activityIdUserVar: '',
    selectUserVisible: true,
    selectType: 'user',
    //
    tabPosition: 'fixedValue',
  };
  componentDidMount() {
    if (this.props.selectType) {
      this.selectType(this.props.selectType);
    } else {
      this.selectType('org');
    }
    // console.log(this.props.throughStrategy);
    console.log(this.props.delegateList);
    console.log(this.props.selectType, '类型');
    if (
      this.props.selectType == 'userVar' ||
      this.props.selectType == 'candidateGroupVar' ||
      this.props.selectType == 'assignee'
    ) {
      if (this.props.delegateList.length > 0) {
        console.log(this.props.delegateList);

        this.setState({
          activityIdUserVar: this.props.delegateList[0].name
            ? this.props.delegateList[0]?.name
                ?.replaceAll('${', '')
                .replaceAll('}', '')
            : this.props.delegateList[0]
                .replaceAll('${', '')
                .replaceAll('}', ''),
          tabPosition: 'var',
        });
      }
    } else {
      const selectedRowKeys = this.props.delegateList.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      const delegateList = this.props.delegateList;
      console.log(selectedRowKeys);

      this.setState({
        delegateList: delegateList,
        selectedRowKeys: selectedRowKeys,
      });
    }

    this.start();
  }

  // 左侧树结构
  start = () => {
    getListOrgTrees().then((res) => {
      if (res.sysHead.retCd == '000000') {
        this.setState({ treeData: res.body });
      }
    });
  };
  onExpand = (expandedKeys) => {
    // console.log(expandedKeys)
  };
  onSelect = (keys, event) => {
    this.setState({ selectTree: keys[0], search: '' });
    // 选角色树
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: 10,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选岗位树
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: 10,
        pageNum: 1,
        orgId: event.node.orgGroup == false ? keys[0] : null,
        orgGroupId: event.node.orgGroup == true ? keys[0] : null,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选择机构树
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: 10,
        pageNum: 1,
        key: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
          });
        }
      });
    }
  };
  // 选择处理人用户类型
  selectType = (e) => {
    // 清除旧值
    this.setState({
      search: '',
    });
    // 用户
    if (e == 'user') {
      listUserByOrg({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          res.body.list?.map((item) => {
            item.id = item.empNo;
          });
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'user',
          });
        }
      });
    }
    // 候选人
    if (e == 'candidateUsers') {
      listUserByOrg({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          res.body.list?.map((item) => {
            item.id = item.empNo;
          });
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'candidateUsers',
          });
        }
      });
    }
    // 角色
    if (e == 'role') {
      getRoleByOrgId({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'role',
          });
        }
      });
    }
    // 机构
    if (e == 'org') {
      getOrgAndChildOrg({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
            selectType: 'org',
          });
        }
      });
    }
    // 岗位
    if (e == 'post') {
      listPosition({
        pageSize: 10,
        pageNum: 1,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
            selectType: 'post',
          });
        }
      });
    }
    if (e == 'userVar') {
      this.setState({
        selectType: 'userVar',
        activityIdUserVar: '',
        onChangeActivity: '1',
      });
    }
    // 候选用户组变量
    if (e == 'candidateGroupVar') {
      this.setState({
        selectType: 'candidateGroupVar',
        activityIdUserVar: '',
        onChangeActivity: '1',
      });
    }
    if (e == 'assignee') {
      this.setState({
        selectType: 'userVar',
        activityIdUserVar: '',
        onChangeActivity: '1',
      });
    }
    // 传值给父组件选中的类型
    this.props.transferSelectType(e);
  };
  // 分页设置
  paginationChange = (page, pageSize) => {
    // console.log('分页');
    let reg = /^[0-9]+.?[0-9]*$/;
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: pageSize,
        pageNum: page,
        empName: this.state.search,
        orgId: this.state.selectTree,
      }).then((res) => {
        res.body.list.map((item) => {
          item.id = item.empNo;
        });
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        positionId:
          reg.test(this.state.search) == true ? this.state.search : '',
        positionName:
          reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        roleId: reg.test(this.state.search) == true ? this.state.search : '',
        roleName: reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: pageSize,
        pageNum: page,
        key: this.state.selectTree,
        orgNo: reg.test(this.state.search) == true ? this.state.search : '',
        orgName: reg.test(this.state.search) == true ? '' : this.state.search,
      }).then((res) => {
        const result = res?.body?.orgAndChildOrgByOrgId
          ? res?.body?.orgAndChildOrgByOrgId
          : res.body;
        this.setState({
          orgTreeData: result,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
  };
  deletById = (value) => {
    const arrDelegateLis = this.state.delegateList.filter(
      (item) => item.id !== value,
    );
    const arrSelectedRowKeys = this.state.selectedRowKeys.filter(
      (item) => item !== value,
    );
    this.setState({
      delegateList: arrDelegateLis,
      selectedRowKeys: arrSelectedRowKeys,
    });
  };
  deletAll = () => {
    this.setState({ delegateList: [], selectedRowKeys: [] });
  };
  // 查询组织架构树 搜索
  onSearch = (value) => {
    this.setState({ search: value.target.value });

    // 根据selectType选择用户种类的不同，调用不同的方法
    // 判断value值是否是纯数字
    let reg = /^[0-9]+.?[0-9]*$/;
    //  如果选中的是用户和候选人
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      listUserByOrg({
        pageSize: 10,
        pageNum: 1,
        // orgId: this.state.selectTree,
        empNo: reg.test(value.target.value) == true ? value.target.value : '',
        empName: reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          res.body.list?.map((item) => {
            item.id = item.empNo;
          });
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    //如果选中的岗位
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: 10,
        pageNum: 1,
        // orgId: this.state.selectTree,
        positionId:
          reg.test(value.target.value) == true ? value.target.value : '',
        positionName:
          reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    // 选择机构树
    if (this.state.selectType == 'org') {
      getOrgAndChildOrg({
        pageSize: 10,
        pageNum: 1,
        // key: this.state.selectTree,
        orgNo: reg.test(value.target.value) == true ? value.target.value : '',
        orgName: reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.orgAndChildOrgByOrgId
            ? res?.body?.orgAndChildOrgByOrgId
            : res.body;
          this.setState({
            orgTreeData: result,
          });
        }
      });
    }
    // 选角色树
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: 10,
        pageNum: 1,
        roleId: reg.test(value.target.value) == true ? value.target.value : '',
        roleName:
          reg.test(value.target.value) == true ? '' : value.target.value,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
  };

  /**
   * 单选按钮函数
   * @param value 单选按钮值
   */
  onChangeActivity = (value) => {
    this.setState({ onChangeActivity: value.target.value });
    // 2 代表默认变量 用户变量和候选用户组变量公用这个方法。
    if (value.target.value == '2') {
      if (this.state.selectType == 'userVar') {
        this.setState({ activityIdUserVar: this.props.activityId + 'User' });
      } else {
        this.setState({
          activityIdUserVar: this.props.activityId + 'CandidateUser',
        });
      }
    } else {
      this.setState({ activityIdUserVar: '' });
    }
  };

  /**
   * 输入框值改变，将值赋给Input框同时传值出去
   */
  onChangeActivityId = (value) => {
    this.setState({ activityIdUserVar: value.target.value }, () => {
      // this.props.transfer(this.state.activityIdUserVar);
      // this.props.transferSelectType(this.state.selectType);
    });
  };

  /**
   *
   * @param e
   */
  onkeyUpUserVar = (e) => {
    // (this.state.activityIdUserVar)=></Form.Item>this.state.activityIdUserVar.replace(/[^a-zA-z]/g,'').toString()}
    this.setState({ activityIdUserVar: e.replace(/[^a-zA-z0-9]/g, '') });
  };

  selectUserHandleOk = async (e) => {
    if (
      this.state.selectType == 'userVar' ||
      this.state.selectType == 'candidateGroupVar'
    ) {
      console.log('变量');

      if (this.state.activityIdUserVar == '') {
        this.setState({ delegateList: [], selectUserVisible: false }, () => {
          this.props.transfer('');
        });
      } else {
        this.setState(
          { activityIdUserVar: '${' + this.state.activityIdUserVar + '}' },
          () => {
            this.props.transfer(
              this.state.activityIdUserVar,
              this.state.selectType,
            );
          },
        );
      }
    } else {
      this.setState({ selectUserVisible: false }, () => {
        this.props.transfer(this.state.delegateList, this.state.selectType);
      });
    }
  };
  selectUserHandleCancel = () => {
    this.setState({ selectUserVisible: false, delegateList: [] });
    this.props.selectUserHandleCancel();
  };
  // 选择固定值还是变量
  changeTabPosition = (e) => {
    if (e.target.value == 'fixedValue') {
      this.setState({
        selectType: 'org',
        tabPosition: e.target.value,
        delegateList: [],
      });
      this.selectType('org');
    } else {
      this.setState({
        selectType: 'candidateGroupVar',
        tabPosition: e.target.value,
        delegateList: [],
      });
    }
  };
  // 选择类型
  changeSelectType = (e) => {
    this.setState({ selectType: e.target.value });
    this.selectType(e.target.value);
  };
  render() {
    const {
      selectedRowKeys,
      delegateList,
      selectType,
      orgTreeData,
    } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        let delegateListTemp = delegateList.concat(selectedRows);
        // 数组去重 选中的角色
        let obj = {};
        let peon = delegateListTemp.reduce((cur, next) => {
          obj[selectType == 'role1' ? next.roleId : next.id]
            ? ''
            : (obj[selectType == 'rol1e' ? next.roleId : next.id] =
                true && cur.push(next));
          return cur;
        }, []);
        let selectedRowKeyss = selectedRowKeys.concat(
          this.state.selectedRowKeys,
        );
        const unique = [...new Set(selectedRowKeyss)];

        orgTreeData.map((item) => {
          if (selectedRowKeys.indexOf(item.id) == -1) {
            unique.map((_item, index) => {
              if (_item == item.id) {
                unique.splice(index, 1);
              }
            });
            peon.map((_item, index) => {
              if (_item.id == item.id) {
                peon.splice(index, 1);
              }
            });
          }
        });
        if (selectType == 'user') {
          this.setState({
            selectedRowKeys: unique,
            delegateList: [peon[peon.length - 1]],
          });
        } else {
          this.setState({
            selectedRowKeys: unique,
            delegateList: peon,
          });
        }
      },
    };

    return (
      <div>
        <Modal
          visible={this.state.selectUserVisible}
          title="节点审核人员选择"
          width={this.state.tabPosition == 'var' ? '50%' : '73%'}
          maskClosable={false}
          centered
          onOk={this.selectUserHandleOk}
          onCancel={this.selectUserHandleCancel}
          footer={[
            <Button key="back" onClick={this.selectUserHandleCancel}>
              取消
            </Button>,
            <Button
              key="submit"
              type="primary"
              onClick={this.selectUserHandleOk}
            >
              确认
            </Button>,
          ]}
        >
          <Row>
            <Col span={24} style={{ marginBottom: 8 }}>
              <div className={StyleSheet.heightandlinehe40}>
                <Radio.Group
                  value={this.state.tabPosition}
                  onChange={this.changeTabPosition}
                  buttonStyle="solid"
                  size="large"
                >
                  <Radio.Button value="fixedValue">固定值</Radio.Button>
                  <Radio.Button value="var">变量</Radio.Button>
                </Radio.Group>
                <Search
                  placeholder="请输入查询"
                  allowClear
                  // enterButton="查询"
                  disabled={
                    this.state.tabPosition == 'fixedValue' ? false : true
                  }
                  onChange={this.onSearch}
                  value={this.state.search}
                  style={{ width: '40%', marginLeft: '8px' }}
                ></Search>
              </div>
            </Col>
          </Row>
          {this.state.tabPosition == 'fixedValue' && (
            <Row>
              <Col span={24}>
                <Card bordered bodyStyle={{ padding: '12px 24px' }}>
                  <Radio.Group
                    value={this.state.selectType}
                    onChange={this.changeSelectType}
                  >
                    <Radio value="org">机构</Radio>
                    <Radio value="post">岗位</Radio>
                    <Radio value="role">角色</Radio>
                  </Radio.Group>
                </Card>
              </Col>
            </Row>
          )}
          {this.state.tabPosition == 'var' && (
            <Row>
              <Col span={24}>
                <Card bordered bodyStyle={{ padding: '12px 24px' }}>
                  <Radio.Group
                    value={this.state.selectType}
                    onChange={this.changeSelectType}
                  >
                    <Radio value="candidateGroupVar">候选用户组变量</Radio>
                  </Radio.Group>
                </Card>
              </Col>
            </Row>
          )}
          <Row>
            {this.state.selectType != 'userVar' &&
              this.state.selectType != 'candidateGroupVar' && (
                <Col span={6}>
                  <Card bordered bodyStyle={{ paddingTop: 16 }}>
                    {this.state.treeData ? (
                      <DirectoryTree
                        onSelect={this.onSelect}
                        onExpand={this.onExpand}
                        defaultExpandedKeys={['99999']}
                        height={462}
                        treeData={this.state.treeData}
                      />
                    ) : (
                      '加载中...'
                    )}
                  </Card>
                </Col>
              )}

            <Col span={this.state.tabPosition == 'var' ? '24' : '12'}>
              <Card bordered bodyStyle={{ paddingBottom: 0, paddingTop: 16 }}>
                {/* 用户变量 */}
                {this.state.selectType == 'userVar' && (
                  <div>
                    <div>
                      <Form.Item label="请选择：" style={{ width: '50%' }}>
                        <Radio.Group
                          onChange={this.onChangeActivity}
                          defaultValue={1}
                        >
                          <Radio value={1}>手动输入</Radio>
                          <Radio value={2}>默认生成变量</Radio>
                        </Radio.Group>
                      </Form.Item>
                    </div>

                    <Form.Item label="变量值" style={{ width: '50%' }}>
                      <Input
                        value={this.state.activityIdUserVar}
                        onChange={this.onChangeActivityId}
                        disabled={
                          this.state.onChangeActivity == '1' ? false : true
                        }
                        onKeyUp={() =>
                          this.onkeyUpUserVar(this.state.activityIdUserVar)
                        }
                        allowClear
                      ></Input>
                      {this.state.activityIdUserVar != '' && (
                        <div style={{ fontSize: 12, color: 'gray' }}>
                          变量以英文字母、下划线和数字组合
                        </div>
                      )}
                    </Form.Item>
                  </div>
                )}
                {/* 候选用户组变量 */}
                {this.state.selectType == 'candidateGroupVar' && (
                  <div>
                    <div>
                      <Form.Item label="请选择：" style={{ width: '50%' }}>
                        <Radio.Group
                          onChange={this.onChangeActivity}
                          defaultValue={1}
                        >
                          <Radio value={1}>手动输入</Radio>
                          <Radio value={2}>默认生成变量</Radio>
                        </Radio.Group>
                      </Form.Item>
                    </div>

                    <Form.Item label="变量值" style={{ width: '50%' }}>
                      <Input
                        value={this.state.activityIdUserVar}
                        onChange={this.onChangeActivityId}
                        disabled={
                          this.state.onChangeActivity == '1' ? false : true
                        }
                        onKeyUp={() =>
                          this.onkeyUpUserVar(this.state.activityIdUserVar)
                        }
                        allowClear
                      ></Input>
                      {this.state.activityIdUserVar != '' && (
                        <div style={{ fontSize: 12, color: 'gray' }}>
                          变量以英文字母、下划线和数字组合
                        </div>
                      )}
                    </Form.Item>
                  </div>
                )}
                {/* 类型不等于机构和变量 */}
                {this.state.selectType != 'userVar' &&
                  this.state.selectType != 'candidateGroupVar' &&
                  this.state.selectType != 'org' && (
                    <>
                      <Table
                        rowSelection={{
                          ...rowSelection,
                          type:
                            this.state.selectType == 'user'
                              ? 'radio'
                              : 'checkbox',
                        }}
                        dataSource={this.state.orgTreeData}
                        bordered
                        size="small"
                        tableLayout="fixed"
                        pagination={{
                          showSizeChanger: true,
                          current: this.state.pageNum,
                          pageSize: this.state.pageSize,
                          total: this.state.total,
                          onChange: (page, pageSize) => {
                            this.paginationChange(page, pageSize);
                          },
                        }}
                        rowKey={(record) => record.id}
                      >
                        <Column
                          title={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? '用户名'
                              : this.state.selectType == 'post'
                              ? '岗位名称'
                              : '角色名'
                          }
                          dataIndex={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? 'empName'
                              : this.state.selectType == 'post'
                              ? 'positionName'
                              : 'roleName'
                          }
                          key="name"
                        ></Column>
                        <Column
                          title={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? '工号'
                              : this.state.selectType == 'post'
                              ? '岗位Id'
                              : '角色Id'
                          }
                          dataIndex={
                            this.state.selectType == 'user' ||
                            this.state.selectType == 'candidateUsers'
                              ? 'code'
                              : this.state.selectType == 'post'
                              ? 'id'
                              : 'roleId'
                          }
                          key="code"
                        ></Column>
                      </Table>
                    </>
                  )}
                {/* 机构没有分页 */}
                {this.state.selectType != 'userVar' &&
                  this.state.selectType != 'candidateGroupVar' &&
                  this.state.selectType == 'org' && (
                    <>
                      <Table
                        rowSelection={{
                          ...rowSelection,
                        }}
                        pagination={false}
                        pagination={{
                          showSizeChanger: true,
                          pageSize: 10,
                        }}
                        size="small"
                        dataSource={this.state.orgTreeData}
                        bordered
                        rowKey={(record) => record.id}
                      >
                        <Column
                          title="机构名称"
                          dataIndex="name"
                          key="name"
                        ></Column>
                        <Column title="机构Id" dataIndex="id" key="id"></Column>
                      </Table>
                    </>
                  )}
              </Card>
            </Col>

            {this.state.selectType != 'userVar' &&
              this.state.selectType != 'candidateGroupVar' && (
                <Col span={6}>
                  <Card bordered>
                    {this.state.delegateList &&
                      this.props.throughStrategy !== 'avg' &&
                      this.state.delegateList.map((item, index) => {
                        return (
                          <Tag
                            style={{
                              lineHeight: '35px',
                              marginBottom: '8px',
                              height: '40px',
                            }}
                            color="blue"
                            closable
                            onClose={(e) => {
                              e.preventDefault();
                              this.deletById(item.id);
                            }}
                            key={index}
                          >
                            {item.name ? item.name : item}
                          </Tag>
                        );
                      })}
                    <br />
                    {this.state.delegateList.length != 0 &&
                      this.props.throughStrategy !== 'avg' && (
                        <Button
                          style={{ marginTop: 8 }}
                          onClick={this.deletAll}
                          type="primary"
                        >
                          清空
                        </Button>
                      )}
                    <br />
                    {this.state.delegateList.length != 0 &&
                      this.props.throughStrategy == 'avg' && (
                        <Button
                          style={{ marginTop: 8 }}
                          onClick={this.deletAll}
                          type="primary"
                        >
                          清空
                        </Button>
                      )}
                  </Card>
                </Col>
              )}
          </Row>
        </Modal>
      </div>
    );
  }
}
export default OrgTreeGroup;
