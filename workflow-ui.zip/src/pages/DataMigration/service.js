import request from '../../utils/request';

export function queryNum(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'MigrationSVC',
        stdIntfcInd: 'queryNum',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 查询流程图
export function migrateData(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'MigrationSVC',
        stdIntfcInd: 'migrateData ',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
