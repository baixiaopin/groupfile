// @ts-nocheck

import {
  FcButton as Button,
  FcConfigProvider as ConfigProvider,
  FcResult as Result,
} from '@ngfed/fc-components';
import React from 'react';
import { migrateData, queryNum } from './service.js';
import zhCN from 'antd/lib/locale/zh_CN';
class HistoryTask extends React.Component {
  state = {
    data: [],
  };

  searchFormRef = React.createRef();
  componentDidMount() {}
  queryData = () => {
    queryNum({}).then((res) => {
      console.log(res);
    });
  };

  start = () => {
    migrateData({}).then((res) => {
      console.log(res);
    });
  };

  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Result
          title="数据迁移"
          subTitle="Data number: 2017182818828182881 Cloud server configuration takes 1-5 minutes, please wait."
          extra={[
            <Button type="primary" key="query" onClick={this.queryData}>
              查询数据量
            </Button>,
            <Button key="buy" onClick={this.start}>
              开始迁移
            </Button>,
          ]}
        />
        ,
      </ConfigProvider>
    );
  }
}

// 导出一个流程设计组件
export default HistoryTask;
