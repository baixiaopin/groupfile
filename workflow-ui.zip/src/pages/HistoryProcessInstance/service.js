import request from '../../utils/request';

export function getHistoryProcInst(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelVersionResSVC',
        stdIntfcInd: 'getHistoryProcInst',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

export function processInstancePreview(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'processInstancePreview',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
