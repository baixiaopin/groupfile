// @ts-nocheck

import {
  FcButton as Button,
  FcCard as Card,
  FcForm as Form,
  FcModal as Modal,
  FcInput as Input,
  FcTable as Table,
  FcConfigProvider as ConfigProvider,
  FcTooltip as Tooltip,
} from '@ngfed/fc-components';
import React from 'react';
import ProcessViewerModel from '../ProcessViewerModel/index';
import { getHistoryProcInst, processInstancePreview } from './service.js';
import zhCN from 'antd/lib/locale/zh_CN';
import Moment from 'moment';
class HistoryProcessInstance extends React.Component {
  state = {
    visible: false,
    viewVisible: false,
    xmlData: [],
    taskData: [],
    processInstanceId: '',
    data: [],
    pageNum: '',
    pageSize: '',
    total: '',
    activityAssignee: '',
    columns: [
      {
        title: '发起人',
        dataIndex: 'startUserId',
        key: 'startUserId',

        ellipsis: {
          showTitle: false,
        },
        render: (startUserId) => (
          <Tooltip placement="topLeft" title={startUserId}>
            {startUserId}
          </Tooltip>
        ),
      },
      {
        title: '业务Key',
        dataIndex: 'businessKey',
        key: 'businessKey',

        ellipsis: {
          showTitle: false,
        },
        render: (businessKey) => (
          <Tooltip placement="topLeft" title={businessKey}>
            {businessKey}
          </Tooltip>
        ),
      },
      {
        title: '开始时间',
        dataIndex: 'startTime',
        key: 'startTime',

        ellipsis: {
          showTitle: false,
        },
        render: (startTime) => (
          <Tooltip
            placement="topLeft"
            title={Moment(startTime).format('yyyy-MM-DD HH:mm:ss')}
          >
            {Moment(startTime).format('yyyy-MM-DD HH:mm:ss')}
          </Tooltip>
        ),
      },
      {
        title: '结束时间',
        dataIndex: 'endTime',
        key: 'endTime',

        ellipsis: {
          showTitle: false,
        },
        render: (endTime) => (
          <Tooltip
            placement="topLeft"
            title={Moment(endTime).format('yyyy-MM-DD HH:mm:ss')}
          >
            {Moment(endTime).format('yyyy-MM-DD HH:mm:ss') == 'Invalid date'
              ? ''
              : Moment(endTime).format('yyyy-MM-DD HH:mm:ss')}
          </Tooltip>
        ),
      },
      {
        title: '操作',
        dataIndex: 'action',
        key: 'id',

        width: 260,
        render: (text, record, index) => {
          return (
            <>
              <a
                onClick={() => {
                  this.clickView(record);
                }}
              >
                流程查看
              </a>
            </>
          );
        },
      },
    ],
  };

  searchFormRef = React.createRef();
  componentDidMount() {
    this.search();
  }

  // 根据流程id，发起人搜索
  search = () => {
    const {
      businessKey,
      startUserId,
    } = this.searchFormRef.current.getFieldsValue();
    getHistoryProcInst({
      businessKey: businessKey,
      startUserId: startUserId,
      pageNum: 1,
      pageSize: 10,
    }).then((res) => {
      this.setState({
        data: res.body?.list,
        pageNum: res.body?.pageNum,
        pageSize: res.body?.pageSize,
        total: res.body?.total,
      });
    });
  };

  reset = () => {
    this.searchFormRef.current.resetFields();
    this.search();
  };
  clickView = (value) => {
    processInstancePreview({
      processInstanceId: value.processInstanceId,
    })
      .then((res) => {
        this.setState({
          xmlData: res.body?.bpmnModelXml,
          taskData: res.body?.taskData,
          activityAssignee: res.body?.activityAssignee,
          processInstanceId: value.processInstanceId,
        });
      })
      .then(() => {
        this.setState({ viewVisible: true });
      });
  };
  viewHandleOk = () => {
    this.setState({ viewVisible: false, xmlData: [], taskData: [] });
  };
  paginationChange = (page, pageSize) => {
    getHistoryProcInst({
      pageNum: page,
      pageSize: pageSize,
    }).then((res) => {
      this.setState({
        data: res.body.list,
        pageNum: res.body.pageNum,
        pageSize: res.body.pageSize,
        total: res.body.total,
      });
    });
  };
  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Card style={{ marginBottom: 8 }}>
          <Form
            ref={this.searchFormRef}
            layout="inline"
            onFinish={this.search}
            style={{ marginLeft: 16 }}
          >
            <Form.Item
              label="发起人"
              name="startUserId"
              style={{ marginBottom: 0 }}
            >
              <Input style={{ width: '100%' }} />
            </Form.Item>

            <Form.Item style={{ margin: 'auto 0' }}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.reset}>
                重置
              </Button>
            </Form.Item>
          </Form>
        </Card>
        <Card title="历史流程实例">
          <Table
            rowKey={(record) => record.id}
            dataSource={this.state.data}
            pagination={{
              showTotal: (total) => `共 ${total} 条数据`,
              showSizeChanger: true,
              // props
              current: this.state.pageNum,
              pageSize: this.state.pageSize,
              total: this.state.total,
              onChange: (page, pageSize) => {
                this.paginationChange(page, pageSize);
              },
            }}
            bordered
            columns={this.state.columns}
          ></Table>
          {this.state.viewVisible && (
            <Modal
              visible={this.state.viewVisible}
              title="流程查看"
              width="60%"
              onOk={this.viewHandleOk}
              onCancel={this.viewHandleOk}
              footer={null}
            >
              <ProcessViewerModel
                activityAssignee={this.state.activityAssignee}
                taskData={this.state.taskData}
                xmlData={this.state.xmlData}
                processInstanceId={this.state.processInstanceId}
              ></ProcessViewerModel>
            </Modal>
          )}
        </Card>
      </ConfigProvider>
    );
  }
}

// 导出一个流程设计组件
export default HistoryProcessInstance;
