import request from '../../utils/request';
export function queryTaskInstances(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'queryTaskInstances',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 任务追踪
export function processInstancePreview(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'processInstancePreview',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 是否是会签
export function taskCheck(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'taskCheck',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 任务办理
export function taskCompleted(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'taskCompleted',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 查询回显
export function getNamesByIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'getNamesByIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

//业务流程
export function baseBusinessProcInstPreview(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'baseBusinessProcInstPreview',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

//流程
export function getBusinessViewAndStatusByProcessInstanceId(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BaseBusinessTaskSVC',
        stdIntfcInd: 'getBusinessViewAndStatusByProcessInstanceId',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

//模型监控转办
export function transFer(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'transFer',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
//模型监控流程终止
export function processTermination(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'InstanceTaskSVC',
        stdIntfcInd: 'processTermination',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
