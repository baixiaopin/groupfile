// @ts-nocheck
import {
  FcButton as Button,
  FcCard as Card,
  FcForm as Form,
  FcSelect as Select,
  FcInput as Input,
  FcModal as Modal,
  FcPopconfirm as Popconfirm,
  FcConfigProvider as ConfigProvider,
  FcTable as Table,
  FcTooltip as Tooltip,
  FcMessage as message,
  FcDivider as Divider,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import ProcessVar from './components/ProcessVar';
import React from 'react';
import {
  queryTaskInstances,
  processInstancePreview,
  taskCompleted,
  taskCheck,
  processTermination,
} from './service';
import StyleSheet from '../BusinessesTypeManage/index.less';
import zhCN from 'antd/lib/locale/zh_CN';
const { TextArea } = Input;
import Moment, { locale } from 'moment';
import ProcessViewerModel from '../ProcessViewerModel/index';
import TransferModel from './components/TransFer';
import Tags from '@/components/Tags';
class ProcessTask extends React.Component {
  state = {
    loading: false,
    columns: [
      {
        title: '紧急程度',
        dataIndex: 'priority',
        key: 'priority',
        align: 'center',
        ellipsis: {
          showTitle: false,
        },
        render: (priority) => <Tags value={priority}></Tags>,
      },
      {
        title: '模型名称',
        dataIndex: 'modelName',
        key: 'modelName',
        ellipsis: {
          showTitle: false,
        },
        render: (modelName) => (
          <Tooltip placement="topLeft" title={modelName}>
            {modelName}
          </Tooltip>
        ),
      },
      {
        title: '任务名称',
        dataIndex: 'procInstName',
        key: 'procInstName',
        ellipsis: {
          showTitle: false,
        },
        render: (procInstName) => (
          <Tooltip placement="topLeft" title={procInstName}>
            {procInstName}
          </Tooltip>
        ),
      },
      {
        title: '任务类型',
        dataIndex: 'taskType',
        key: 'taskType',
        ellipsis: {
          showTitle: false,
        },
        render: (taskType) => <>{this.checkoutTasktype(taskType)}</>,
      },
      {
        title: '当前环节',
        dataIndex: 'procTaskName',
        key: 'procTaskName',
        ellipsis: {
          showTitle: false,
        },
        render: (procTaskName) => (
          <Tooltip placement="topLeft" title={procTaskName}>
            {procTaskName}
          </Tooltip>
        ),
      },
      {
        title: '处理人',
        dataIndex: 'assignee',
        key: 'assignee',
        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => (
          <Tooltip
            placement="topLeft"
            title={
              String(record.assigneeName ? record.assigneeName : text) +
              ' (' +
              String(text) +
              ')'
            }
          >
            {String(record.assigneeName ? record.assigneeName : text) +
              ' (' +
              String(text) +
              ')'}
          </Tooltip>
        ),
      },

      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',

        ellipsis: {
          showTitle: false,
        },
        render: (createTime) => {
          return createTime ? (
            <Tooltip
              placement="topLeft"
              title={Moment(createTime).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(createTime).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },

      {
        title: '操作',
        dataIndex: 'action',
        key: 'action',

        width: 200,
        render: (text, record, index) => {
          return (
            <>
              {/* <a
                onClick={() => {
                  this.taskHandle(record);
                }}
              >
                办理
              </a>
              <Divider type="vertical" /> */}
              <a
                onClick={() => {
                  this.transferModel(record);
                }}
              >
                转办
              </a>
              <Divider type="vertical" />
              <Popconfirm
                title="是否终止？"
                onConfirm={() => this.processTermination(record)}
                okText="是"
                cancelText="否"
              >
                <a>终止</a>
              </Popconfirm>
              <Divider type="vertical" />
              <a
                onClick={() => {
                  this.clickView(record);
                }}
              >
                流程查看
              </a>
            </>
          );
        },
      },
    ],
    dataSource: [],
    pageNum: '',
    pageSize: '',
    total: '',
    //
    viewVisible: false,
    xmlData: [],
    taskData: {},
    activityAssignee: [],
    taskHandleVisble: false,
    id: '',
    addTaskList: [],
    taskState: false,
    processInstanceId: '',
    variables: null,
    transferModelVisable: false,
  };
  checkoutTasktype = (taskType) => {
    switch (taskType) {
      case '01':
        return '普通任务';
      case '02':
        return '委派任务';
      case '03':
        return '已解决待审核任务';
      case '04':
        return '转办任务';
      case '05':
        return '会签任务';
      case '06':
        return '待认领任务';
      default:
        return '授权代办任务';
    }
  };
  searchFormRef = React.createRef();
  comment = React.createRef();
  componentDidMount() {
    const value = {
      lol: '改动的值需要标记1223',
      lpl: '不需要标记258',
      lck: '不需要标记88',
    };
    const oldValue = { lol: '1223', lpl: '258', lck: '88' };
    const lastAyy = ['lol', 'ppp'];
    let newObj = {};
    for (let key in value) {
      newObj[key] = {
        value: value[key],
        oldValue: oldValue[key],
        flag: lastAyy.indexOf(key) == 0 ? true : false,
      };
    }
    console.log(newObj);
    this.search();
  }
  /**
   * 点击查询按钮，查询流程任务
   */
  search = () => {
    this.setState({ loading: true });
    const value = this.searchFormRef.current.getFieldsValue();
    queryTaskInstances({
      ...value,
      pageNum: 1,
      pageSize: 10,
    }).then((res) => {
      if (res.body && res.sysHead.retCd === '000000') {
        this.setState({
          dataSource: res.body?.list,
          pageNum: res.body?.pageNum,
          pageSize: res.body?.pageSize,
          total: res.body?.total,
        });
      }
      this.setState({ loading: false });
    });
  };

  /**
   * 点击重置按钮，重置条件查询表单
   */
  reset = () => {
    this.searchFormRef.current.resetFields();
    this.search();
  };

  /**
   * 任务办理
   * @param value
   */
  taskHandle = (value) => {
    this.setState({ taskHandleVisble: true });
    taskCheck({
      taskId: value.procTaskId,
    }).then((res) => {
      if (res && res.body) {
        this.setState({ taskState: res.body.isMulti }, () => {
          this.setState({ id: value.procTaskId, record: value });
        });
      }
    });
  };

  /**
   * 任务办理确认
   * @param e
   */
  taskHandleOk = async (e) => {
    try {
      const values = await this.comment.current.validateFields();

      this.setState({ loading: true });
      const { comment, suggestion } = this.comment.current.getFieldsValue();
      const attribute = this.comment.current.getFieldsValue();
      // 删除表单项名叫瞬时的值，如果直接在表单项中将其 value 设置成 "" 的话，则通不过表单非空校验
      for (const key in attribute) {
        if (Object.prototype.hasOwnProperty.call(attribute, key)) {
          if (key.includes('status') && attribute[key] === 'shunshi') {
            attribute[key] = '';
          }
        }
      }
      delete attribute.comment;
      delete attribute.suggestion;
      //  处理对象转化为数组并分类
      if (this.state.taskState == true) {
        //  会签办理
        attribute.varOnlyVisibleInTask = true;
        attribute.vote = suggestion == undefined ? 'accept' : suggestion;
        taskCompleted({
          taskId: this.state.id,
          comment: comment,
          variables: { ...this.state.variables, ...attribute },
        }).then((res) => {
          if (res.sysHead.retCd != '000000') {
            this.setState({ loading: false });
            return false;
          }
          message.success('办理完成');
          this.reset();
          this.setState({
            taskHandleVisble: false,
            addTaskList: [],
            variables: null,
            loading: false,
          });
        });
      } else {
        // 不带会签的任务
        taskCompleted({
          taskId: this.state.id,
          comment: comment,
          variables: { ...this.state.variables },
        }).then((res) => {
          if (res.sysHead.retCd != '000000') {
            this.setState({ loading: false });
            return false;
          }
          message.success('办理完成');
          this.reset();
          this.setState({
            taskHandleVisble: false,
            addTaskList: [],
            variables: null,
            loading: false,
          });
        });
      }
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };
  taskHandleCancel = () => {
    this.setState({ taskHandleVisble: false, addTaskList: [] });
  };

  /**
   * 转办 事件
   */
  transferModel = (record) => {
    this.setState({ transferModelVisable: true, record: record });
  };
  cancleModel = (record) => {
    this.reset();
    this.setState({ transferModelVisable: false });
  };

  /**
   * 终止流程
   */
  processTermination = (record) => {
    processTermination({
      taskId: record.procTaskId,
    }).then((res) => {
      if (res.sysHead.retCd != '000000') {
        return false;
      }
      message.success('流程终止');
      this.reset();
    });
  };

  /**
   * 分页
   * @param page 页码
   * @param pageSize 页数
   */
  paginationChange = (page, pageSize) => {
    const value = this.searchFormRef.current.getFieldsValue();
    queryTaskInstances({
      ...value,
      pageNum: page,
      pageSize: pageSize,
    }).then((res) => {
      this.setState({
        dataSource: res.body.list,
        pageNum: res.body.pageNum,
        pageSize: res.body.pageSize,
        total: res.body.total,
      });
    });
  };
  viewHandleOk = () => {
    this.setState({ viewVisible: false, xmlData: [], taskData: [] });
  };

  /**
   *
   * @param value 查看流程 流程追踪
   */
  clickView = (value) => {
    this.setState({ loading: true });
    processInstancePreview({
      processInstanceId: value.procInstId,
    })
      .then((res) => {
        if (res.body && res.sysHead.retCd === '000000') {
          // console.log(res.body?.taskData);
          // res.body.taskData.Activity_0ijfqrr={numOfExecution:3,status:2}
          // res.body.taskData.Activity_0zyaecy={numOfExecution:2,status:2}
          // res.body.taskData.Activity_112a6t6={numOfExecution:4,status:2}
          this.setState({
            xmlData: res.body?.bpmnModelXml,
            taskData: res.body?.taskData,
            activityAssignee: res.body?.activityAssignee,
            processInstanceId: value.procInstId,
          });
        }
      })
      .then(() => {
        this.setState({ viewVisible: true, loading: false });
      });
  };

  activityNodeInfo = (e) => {
    console.log(e);
  };
  tabsCallback = () => {
    console.log(this.state.taskData);
  };
  transferData = (e) => {
    console.log(e);
    const obj = {};
    e.map((item) => {
      obj.varOnlyVisibleInTask = item.varOnlyVisibleInTask;
      obj[item.varName] =
        item.varValue == 'true'
          ? true
          : item.varValue == 'false'
          ? false
          : item.varValue;
    });
    this.setState({ variables: obj });
  };
  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Spin spinning={this.state.loading}>
          <Card style={{ marginBottom: 8 }}>
            <Form
              ref={this.searchFormRef}
              layout="inline"
              onFinish={this.search}
              style={{ marginLeft: 16 }}
            >
              <Form.Item
                label="任务名称"
                name="procInstName"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="当前环节"
                name="procTaskName"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="处理人"
                name="assignee"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item style={{ margin: 'auto 0' }}>
                <Button type="primary" htmlType="submit">
                  查询
                </Button>
                <Button style={{ marginLeft: 8 }} onClick={this.reset}>
                  重置
                </Button>
              </Form.Item>
            </Form>
          </Card>
          <Card title="流程任务">
            <Table
              columns={this.state.columns}
              dataSource={this.state.dataSource}
              pagination={{
                showTotal: (total) => `共 ${total} 条数据`,
                showSizeChanger: true,
                // props
                current: this.state.pageNum,
                pageSize: this.state.pageSize,
                total: this.state.total,
                onChange: (page, pageSize) => {
                  this.paginationChange(page, pageSize);
                },
              }}
              bordered
              rowKey={(record) => record.id}
            ></Table>

            {this.state.viewVisible && (
              <Modal
                visible={this.state.viewVisible}
                title="流程追踪"
                width="65%"
                centered
                onOk={this.viewHandleOk}
                onCancel={this.viewHandleOk}
                footer={null}
              >
                <div className={StyleSheet.hiddleTabNavLeft}>
                  <ProcessViewerModel
                    // isShowGradientEffect
                    // isUseNodeHistoricRecord
                    // isHiddenOverlayHtml={false}
                    taskData={this.state.taskData}
                    xmlData={this.state.xmlData}
                    processInstanceId={this.state.processInstanceId}
                    activityAssignee={this.state.activityAssignee}
                    activityNodeInfo={this.activityNodeInfo}
                  ></ProcessViewerModel>
                </div>
              </Modal>
            )}
            {/* 任务办理 */}
            {this.state.taskHandleVisble && (
              <Form ref={this.comment}>
                <Modal
                  visible={this.state.taskHandleVisble}
                  title="任务办理"
                  width="60%"
                  bodyStyle={{ marginLeft: 30, marginRight: 80 }}
                  onOk={this.taskHandleOk}
                  onCancel={this.taskHandleCancel}
                  footer={[
                    <Button key="back" onClick={this.taskHandleCancel}>
                      取消
                    </Button>,
                    <Button
                      key="submit"
                      type="primary"
                      onClick={this.taskHandleOk}
                    >
                      确认
                    </Button>,
                  ]}
                >
                  <Form.Item
                    label="	当前环节"
                    wrapperCol={{ span: 20 }}
                    labelCol={{ span: 4 }}
                    style={{ margin: '8px 0', textAlign: 'center' }}
                  >
                    <Input
                      value={this.state.record?.procTaskName}
                      readOnly
                    ></Input>
                  </Form.Item>
                  <Form.Item
                    label="业务关联"
                    wrapperCol={{ span: 20 }}
                    labelCol={{ span: 4 }}
                    style={{ margin: '8px 0', textAlign: 'center' }}
                  >
                    <Input defaultValue="无关联业务" readOnly></Input>
                  </Form.Item>

                  <Form.Item
                    label="流程变量"
                    wrapperCol={{ span: 20 }}
                    labelCol={{ span: 4 }}
                  >
                    {this.state.taskHandleVisble && (
                      <div style={{ marginBottom: 20 }}>
                        <ProcessVar
                          transferData={this.transferData}
                        ></ProcessVar>
                      </div>
                    )}
                  </Form.Item>
                  {this.state.taskState && (
                    <Form.Item
                      label="会签意见"
                      name="suggestion"
                      wrapperCol={{ span: 20 }}
                      labelCol={{ span: 4 }}
                    >
                      <Select defaultValue="accept">
                        <Select.Option value="accept">同意</Select.Option>
                        <Select.Option value="reject">拒绝</Select.Option>
                        <Select.Option value="abstain">弃权</Select.Option>
                      </Select>
                    </Form.Item>
                  )}

                  <Form.Item
                    label="办理意见"
                    name="comment"
                    wrapperCol={{ span: 20 }}
                    labelCol={{ span: 4 }}
                  >
                    <TextArea />
                  </Form.Item>
                </Modal>
              </Form>
            )}
          </Card>
          {this.state.transferModelVisable && (
            <TransferModel
              record={this.state.record}
              cancleModel={this.cancleModel}
            ></TransferModel>
          )}
        </Spin>
      </ConfigProvider>
    );
  }
}

export default ProcessTask;
