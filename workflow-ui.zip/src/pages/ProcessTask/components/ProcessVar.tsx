// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcSelect as Select,
  FcInput as Input,
  FcPopconfirm as Popconfirm,
  FcTable as Table,
} from '@ngfed/fc-components';
class ProcessVar extends Component {
  formRef = React.createRef();
  state = {
    limitMappingList: [],
    columns: [
      {
        dataIndex: 'varOnlyVisibleInTask',
        key: 'varOnlyVisibleInTask',
        title: '范围',
        width: '20%',
        align: 'center',
        render: (_, record, index) => {
          return (
            <Select
              placeholder="默认值：全局"
              onChange={(value) =>
                this.handleChangeVarOnlyVisibleInTask(value, record, index)
              }
              value={record.varOnlyVisibleInTask}
            >
              <Select.Option value="true">全局</Select.Option>
              <Select.Option value="false">任务</Select.Option>
            </Select>
          );
        },
      },
      {
        dataIndex: 'varName',
        key: 'varName',
        title: '变量名称',
        width: '20%',
        align: 'center',
        render: (_, record, index) => {
          return (
            <Input
              placeholder="默认值"
              onChange={(value) =>
                this.handleChangeVarName(value, record, index)
              }
              value={record.varName}
            ></Input>
          );
        },
      },
      {
        dataIndex: 'type',
        key: 'type',
        title: '类型',
        width: '20%',
        align: 'center',
        render: (_, record, index) => {
          return (
            <Select
              placeholder="默认值"
              onChange={(value) => this.handleChangeType(value, record, index)}
              value={record.type}
            >
              <Select.Option value="Boolean">Boolean</Select.Option>
              <Select.Option value="String">String</Select.Option>
            </Select>
          );
        },
      },

      {
        dataIndex: 'varValue',
        key: 'varValue',
        title: '变量值',
        width: '20%',
        align: 'center',
        render: (_, record, index) => {
          if (record.type == 'String') {
            return (
              <Input
                placeholder="默认值"
                onChange={(value) =>
                  this.handleChangeVarValue(value, record, index)
                }
                value={record.varValue}
              ></Input>
            );
          }
          if (record.type == 'Boolean') {
            return (
              <Select
                placeholder="默认值"
                onChange={(value) =>
                  this.handleChangeVarValueBoolean(value, record, index)
                }
                value={record.varValue}
              >
                <Select.Option value="true">true</Select.Option>
                <Select.Option value="false">false</Select.Option>
              </Select>
            );
          }
        },
      },

      {
        dataIndex: 'action',
        key: 'action',
        title: '操作',
        width: '20%',
        align: 'center',
        render: (_, record, index) => {
          return (
            <>
              {this.state.limitMappingList.length >= 1 ? (
                <Popconfirm
                  title="确定删除这条数据吗？"
                  onConfirm={() => this.handleDelete(index)}
                >
                  <Button type="link">删除</Button>
                </Popconfirm>
              ) : null}
            </>
          );
        },
      },
    ],
    count: 1,
  };

  componentDidMount() {
    console.log(333);
  }

  /**
   * 获取限额对象类型
   * @param {String} value
   */
  getLimitObjectType(value) {
    //测试数据
    let obj = {};
    if (value === '名称1') {
      obj = {
        quotaObjectId: 'ID名称1',
        quotaObjectName: '名称1',
      };
    } else {
      obj = {
        quotaObjectId: 'ID名称2',
        quotaObjectName: '其他',
      };
    }
    return obj;
  }

  /**
   * 校验交易代码和维度名称的唯一
   * @param {Object} record
   * @param {String} value
   */
  checkData(value) {
    const { limitMappingList } = this.state;
    const index = limitMappingList.findIndex((item) => {
      return item.varName === value;
    });
    // if (index !== -1) {
    //   message.error('变量名不能重复');
    //   return false;
    // }
    return true;
  }

  /**
   * 处理字段的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeVarOnlyVisibleInTask(value, record, index) {
    //校验是否重复
    if (!this.checkData(value)) return;

    const newData = [...this.state.limitMappingList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.varOnlyVisibleInTask = value;
    console.log(cpRecord);
    //获取id
    console.log(cpRecord);
    newData.splice(index, 1, { ...item, ...cpRecord });
    console.log('newData', newData);

    this.setState({
      limitMappingList: newData,
    });
    this.props.transferData(newData);
  }

  /**
   * 处理类型的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeType(value, record, index) {
    //校验是否重复
    if (!this.checkData(value)) return;

    const newData = [...this.state.limitMappingList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.type = value;
    cpRecord.varValue = '';
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      limitMappingList: newData,
    });
    this.props.transferData(newData);
  }

  /**
   * 名字的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeVarName(value, record, index) {
    //校验是否重复
    if (!this.checkData(value.target.value)) return;

    const newData = [...this.state.limitMappingList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.varName = value.target.value;
    console.log(cpRecord);
    newData.splice(index, 1, { ...item, ...cpRecord });
    console.log('newData', newData);

    this.setState({
      limitMappingList: newData,
    });
    this.props.transferData(newData);
  }

  /**
   * 变量值boolean的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeVarValueBoolean(value, record, index) {
    //校验是否重复
    if (!this.checkData(value)) return;

    const newData = [...this.state.limitMappingList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.varValue = value;
    console.log(cpRecord);
    newData.splice(index, 1, { ...item, ...cpRecord });
    console.log('newData', newData);

    this.setState({
      limitMappingList: newData,
    });
    this.props.transferData(newData);
  }
  /**
   * 值的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeVarValue(value, record, index) {
    //校验是否重复
    if (!this.checkData(value)) return;

    const newData = [...this.state.limitMappingList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.varValue = value.target.value;
    console.log(cpRecord);
    newData.splice(index, 1, { ...item, ...cpRecord });
    console.log('newData', newData);

    this.setState({
      limitMappingList: newData,
    });
    this.props.transferData(newData);
  }
  /**
   * 删除一条表格
   * @param {String} index
   */
  handleDelete = (index) => {
    console.log('key', index);
    const { count } = this.state;
    const newData = [...this.state.limitMappingList];
    newData.splice(index, 1);
    this.setState({
      limitMappingList: newData,
      count: count - 1,
    });
    this.props.transferData(newData);
  };

  /**
   * 新增一条表格
   */
  handleAdd = () => {
    const { count, limitMappingList } = this.state;
    const newData = { type: 'String' };
    this.setState({
      limitMappingList: [...limitMappingList, newData],
      count: count + 1,
    });
  };

  render() {
    return (
      <>
        <Button
          onClick={this.handleAdd}
          type="primary"
          style={{ marginBottom: 16 }}
        >
          {' '}
          + 添加{' '}
        </Button>

        <Table
          key={(record) => {
            record.type;
          }}
          bordered
          dataSource={this.state.limitMappingList}
          columns={this.state.columns}
          pagination={false}
        />
      </>
    );
  }
}
export default ProcessVar;
