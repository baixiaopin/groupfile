// @ts-nocheck
import {
  FcButton as Button,
  FcForm as Form,
  FcInput as Input,
  FcModal as Modal,
  FcConfigProvider as ConfigProvider,
  FcMessage as message,
} from '@ngfed/fc-components';
import React from 'react';
import { transFer } from '../service';
import OrgTreeModal from '../../OrgTreeModal';
import zhCN from 'antd/lib/locale/zh_CN';
const { TextArea } = Input;
class TransFer extends React.Component {
  state = {
    delegateVisible: false,
    searchDelegateVisible: false,
    delegatePeople: [],
  };

  settings = React.createRef();
  componentDidMount() {
    this.setState({ delegateVisible: true }, () => {
      this.settings.current.setFieldsValue({
        procTaskName: this.props.record.procTaskName,
      });
    });
  }

  /**
   * 转办完成
   * @returns
   */
  delegateHandleOk = async (e) => {
    try {
      const values = await this.settings.current.validateFields();
      console.log('转办完成', values);

      transFer({
        taskId: this.props.record.procTaskId,
        userId: this.state.delegatePeople[0].id,
        comment: values.comment,
        empNo: this.props.record.assignee,
      }).then((res) => {
        if (res.sysHead.retCd != '000000') {
          return false;
        }
        message.success('转办成功!');
        this.props.cancleModel();
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  /**
   * 转办取消
   * @returns
   */
  delegateHandleCancel = () => {
    console.log('转办取消');
    this.setState({ delegateVisible: false });

    this.props.cancleModel();
  };

  /**
   * 搜索处理人
   * @param e
   */
  searchDelegatShowModal = () => {
    this.setState({ searchDelegateVisible: true });
  };

  /**
   * 组织架构树传值
   * @returns
   */
  getUserData = (e) => {
    console.log(e);
    this.setState({ searchDelegateVisible: false, delegatePeople: e });
    const userName = e[0].name + '  (' + e[0].id + ')';
    this.settings.current.setFieldsValue({ userName });
  };
  transferSelectType = (e) => {
    console.log(e);
  };
  selectUserHandleCancel = () => {
    this.setState({ searchDelegateVisible: false });
  };
  render() {
    return (
      <ConfigProvider locale={zhCN}>
        <Modal
          visible={this.state.delegateVisible}
          title={'转办'}
          width="40%"
          onOk={this.delegateHandleOk}
          onCancel={this.delegateHandleCancel}
          footer={[
            <Button key="back" onClick={this.delegateHandleCancel}>
              取消
            </Button>,
            <Button
              key="submit"
              type="primary"
              // loading={this.state.delegateLoading}
              onClick={this.delegateHandleOk}
            >
              确认
            </Button>,
          ]}
        >
          <Form ref={this.settings}>
            <Form.Item
              label="当前环节"
              name="procTaskName"
              labelCol={{ span: 6 }}
              wrapperCol={{ span: 18 }}
            >
              <Input
                // defaultValue="信贷审批"
                readOnly
                style={{ width: '80%' }}
              ></Input>
            </Form.Item>
            <Form.Item
              label="备注/意见"
              name="comment"
              labelCol={{ span: 6 }}
              wrapperCol={{ span: 18 }}
            >
              <TextArea style={{ width: '80%' }} />
            </Form.Item>
            <Form.Item
              label={'被转办的用户'}
              name="userName"
              labelCol={{ span: 6 }}
              wrapperCol={{ span: 18 }}
              rules={[{ required: true }]}
            >
              <Input
                style={{ width: '80%' }}
                onFocus={this.searchDelegatShowModal}
                autoComplete="off"
              ></Input>
            </Form.Item>
          </Form>
        </Modal>
        {/* 委派选择 处理人 */}
        {this.state.searchDelegateVisible && (
          <OrgTreeModal
            tranferType="true"
            transfer={this.getUserData}
            transferSelectType={this.transferSelectType}
            selectUserHandleCancel={this.selectUserHandleCancel}
            delegateList={this.state.delegatePeople}
            selectType="user"
          />
        )}
      </ConfigProvider>
    );
  }
}

export default TransFer;
