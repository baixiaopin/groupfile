import request from '../../utils/request';

// 根据机构、岗位、角色查人员
export function getUserByPersonnelLimit(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'getUserByPersonnelLimit',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
