// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcCard as Card,
  FcRow as Row,
  FcCol as Col,
  FcModal as Modal,
  FcTable as Table,
  FcTree as Tree,
  FcRadio as Radio,
  FcCheckbox as Checkbox,
  FcTag as Tag,
  FcInput,
} from '@ngfed/fc-components';
import { getUserByPersonnelLimit } from './interface';
const { Column } = Table;
const { Search } = FcInput;
class NextNode extends React.Component {
  newBuildExecutionListenersReff = React.createRef();
  monitor = React.createRef();
  state = {
    selectType: 'post',
    delegateList: [],
    selectedRowKeys: [],
    orgTreeData: [],
    pageNum: 1,
    pageSize: '',
    total: '',
    search: '',
    // 处理人弹框
    nextNodeVisable: false,
    // 选中的人
    selectedRows: [],
    listIndex: '',
  };
  componentDidMount() {}
  onSelect = (keys, event) => {
    // 选角色树
    if (this.state.selectType == 'role') {
      getRoleByOrgId({
        pageSize: 5,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    // 选岗位树
    if (this.state.selectType == 'post') {
    }
  };
  // 分页设置
  deletById = (value) => {
    const arrDelegateLis = this.state.delegateList.filter(
      (item) => item.id !== value,
    );
    const arrSelectedRowKeys = this.state.selectedRowKeys.filter(
      (item) => item !== value,
    );
    this.setState(
      {
        delegateList: arrDelegateLis,
        selectedRowKeys: arrSelectedRowKeys,
      },
      () => {
        this.props.transferPostOrRole(this.state.delegateList);
      },
    );
  };
  deletAll = () => {
    this.setState({ delegateList: [], selectedRowKeys: [] }, () => {
      this.props.transferPostOrRole(this.state.delegateList);
    });
  };
  onSearch = (value) => {
    this.setState({ search: value.target.value });
    let reg = /^[0-9]+.?[0-9]*$/;
    //  如果选中的是用户和候选人
    //如果选中的岗位
  };
  //   查询单选下一节点
  onChangeNextNode = (e) => {
    this.props.handelNext.userTaskDetailInfoDtoList.map((item) => {
      delete item.list;
      delete item.select;
    });
    this.setState({ radio: e.target.value }, () => {
      if (
        this.props.handelNext.userTaskDetailInfoDtoList[this.state.listIndex] !=
        undefined
      ) {
        // this.props.transferList(this.props.handelNext.userTaskDetailInfoDtoList)
        this.selectPeople(this.props.handelNext.userTaskDetailInfoDtoList);
      }
    });
  };
  //   查询多下一节点
  onChangeNextNodeCheckbox = (e) => {
    this.setState({ NodeCheckboxKey: e });
    this.props.handelNext.userTaskDetailInfoDtoList.map((item, index) => {
      if (e.toString().indexOf(index) == '-1') {
        delete this.props.handelNext.userTaskDetailInfoDtoList[index].list;
        delete this.props.handelNext.userTaskDetailInfoDtoList[index].select;
      }
      this.selectPeople(this.props.handelNext.userTaskDetailInfoDtoList);
    });
  };
  //   点击查看处理人
  onClickNextNode = (e) => {
    getUserByPersonnelLimit({
      limitOrg: this.props.handelNext.userTaskDetailInfoDtoList[e]
        .extDepartmentIds,
      limitPosition:
        this.props.handelNext.userTaskDetailInfoDtoList[e].extPostIds == null
          ? ''
          : this.props.handelNext.userTaskDetailInfoDtoList[e].extPostIds,
      limitRole:
        this.props.handelNext.userTaskDetailInfoDtoList[e].extRoleIds == null
          ? ''
          : this.props.handelNext.userTaskDetailInfoDtoList[e].extRoleIds,
    }).then((res) => {
      this.setState({
        orgTreeData: res.body,
        nextNodeVisable: true,
        listIndex: e,
        selectedRows: [],
      });
    });
  };
  // 确定弹框
  nextNodeModalOk = () => {
    if (this.props.handelNext.gateWayName == '互斥网关') {
      this.props.handelNext.userTaskDetailInfoDtoList[
        this.state.listIndex
      ].list = this.state.selectedRows;
      this.props.handelNext.userTaskDetailInfoDtoList[
        this.state.listIndex
      ].select = true;
      this.selectPeople(this.props.handelNext.userTaskDetailInfoDtoList);
      // this.props.transferList(this.props.handelNext.userTaskDetailInfoDtoList)
    }

    if (this.props.handelNext.gateWayName == '包容网关') {
      this.props.handelNext.userTaskDetailInfoDtoList[
        this.state.listIndex
      ].select = true;
      this.props.handelNext.userTaskDetailInfoDtoList[
        this.state.listIndex
      ].list = this.state.selectedRows;
      this.selectPeople(this.props.handelNext.userTaskDetailInfoDtoList);
    }
    this.props.handelNext.userTaskDetailInfoDtoList[
      this.state.listIndex
    ].select = true;
    this.props.handelNext.userTaskDetailInfoDtoList[
      this.state.listIndex
    ].list = this.state.selectedRows;
    this.selectPeople(this.props.handelNext.userTaskDetailInfoDtoList);
    this.setState({ nextNodeVisable: false });
  };
  // 取消
  nextNodeModalCancle = () => {
    this.setState({ nextNodeVisable: false });
  };
  // 处理办理人返回
  selectPeople = (e) => {
    const reg = /\{([^\}]+)\}/;
    let obje = {};
    if (e.length > 0) {
      e.map((item) => {
        if (item.list) {
          const newVar = item.handlers[0].match(reg)[1];
          const newCandidateUserVarName = item.list.map((obj) => {
            return obj.code;
          });
          obje[newVar] = newCandidateUserVarName.toString();
        } else {
          const newVar = item.handlers[0].match(reg)[1];
          if (Object.keys(obje).indexOf(newVar) == -1) {
            obje[newVar] = '';
          }
        }
        if (item.select == true && item.accessConditionExpression != null) {
          const conditionValue = item.accessConditionExpression
            .match(reg)[1]
            .split('==')[1]
            .replaceAll('"', '');
          const condition = item.accessConditionExpression
            .match(reg)[1]
            .split('==')[0];
          obje[condition] = conditionValue;
        } else {
          if (item.accessConditionExpression != null) {
            const condition = item.accessConditionExpression
              .match(reg)[1]
              .split('==')[0];
            if (Object.keys(obje).indexOf(condition) == -1) {
              obje[condition] = '';
            }
          }
        }
      });
      this.props.transferList(obje);
    }
  };
  render() {
    const { selectedRowKeys, delegateList, selectType } = this.state;
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        this.setState({ selectedRows: selectedRows });
      },
      getCheckboxProps: (record) => ({
        disabled: record.name === 'Disabled User',
        name: record.name,
      }),
    };
    return (
      <div>
        {this.props.handelNext.gateWayName == '互斥网关' && (
          <Radio.Group
            style={{ width: '100%' }}
            onChange={this.onChangeNextNode}
          >
            {this.props.handelNext.userTaskDetailInfoDtoList.map(
              (item, index) => {
                return (
                  <Row gutter={[16, 16]}>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      <Radio value={index} key={index}>
                        {item.name}
                      </Radio>
                    </Col>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      <Button
                        onClick={() => {
                          this.onClickNextNode(index);
                        }}
                        disabled={this.state.radio == index ? false : true}
                      >
                        选择处理人
                      </Button>
                    </Col>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      {item.list &&
                        item.list.map((item) => {
                          return (
                            <Tag
                              style={{
                                marginRight: 5,
                                marginBottom: 5,
                                padding: 5,
                              }}
                            >
                              {item.name}
                            </Tag>
                          );
                        })}
                    </Col>
                  </Row>
                );
              },
            )}
          </Radio.Group>
        )}
        {this.props.handelNext.gateWayName == '包容网关' && (
          <Checkbox.Group
            style={{ width: '100%' }}
            onChange={this.onChangeNextNodeCheckbox}
          >
            {this.props.handelNext.userTaskDetailInfoDtoList.map(
              (item, index) => {
                return (
                  <Row gutter={[16, 16]}>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      <Checkbox value={index}>{item.name}</Checkbox>
                    </Col>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      {this.state.NodeCheckboxKey &&
                        this.state.NodeCheckboxKey.map((items) => {
                          if (items == index) {
                            return (
                              <Button
                                onClick={() => {
                                  this.onClickNextNode(index);
                                }}
                              >
                                选择处理人
                              </Button>
                            );
                          }
                        })}
                    </Col>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      {item.list &&
                        item.list.map((item) => {
                          return <Tag style={{ margin: 5 }}>{item.name}</Tag>;
                        })}
                    </Col>
                  </Row>
                );
              },
            )}
          </Checkbox.Group>
        )}
        {this.props.handelNext.gateWayName == null && (
          <Checkbox.Group
            style={{ width: '100%' }}
            onChange={this.onChangeNextNodeCheckbox}
          >
            {this.props.handelNext.userTaskDetailInfoDtoList.map(
              (item, index) => {
                return (
                  <Row gutter={[16, 16]}>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      <Checkbox value={index}>{item.name}</Checkbox>
                    </Col>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      {this.state.NodeCheckboxKey &&
                        this.state.NodeCheckboxKey.map((items) => {
                          if (items == index) {
                            return (
                              <Button
                                onClick={() => {
                                  this.onClickNextNode(index);
                                }}
                              >
                                选择处理人
                              </Button>
                            );
                          }
                        })}
                    </Col>
                    <Col xs={2} sm={4} md={6} lg={8}>
                      {item.list &&
                        item.list.map((item) => {
                          return <Tag style={{ margin: 5 }}>{item.name}</Tag>;
                        })}
                    </Col>
                  </Row>
                );
              },
            )}
          </Checkbox.Group>
        )}
        {this.state.nextNodeVisable && (
          <Modal
            title="处理人选择"
            visible={this.state.nextNodeVisable}
            okText="确认"
            cancelText="取消"
            width="60%"
            forceRender
            onOk={this.nextNodeModalOk}
            onCancel={this.nextNodeModalCancle}
          >
            <Card bordered>
              <Search
                placeholder="请输入查询"
                allowClear
                // enterButton="查询"
                onChange={this.onSearch}
                value={this.state.search}
                onBlur={() => {
                  this.setState({ searchStruct: '' });
                }}
                style={{ marginBottom: 8 }}
              ></Search>
              <Table
                rowSelection={{
                  type:
                    this.props.handelNext.userTaskDetailInfoDtoList[
                      this.state.listIndex
                    ].taskType == '1'
                      ? 'radio'
                      : 'checkbox',
                  ...rowSelection,
                }}
                dataSource={this.state.orgTreeData}
                bordered
                tableLayout="fixed"
                pagination={{
                  showSizeChanger: true,
                  pageSize: 5,
                }}
                rowKey={(record) => record.id}
              >
                <Column
                  title="用户名"
                  align="center"
                  dataIndex="empName"
                  key="name"
                ></Column>
                <Column
                  title="工号"
                  align="center"
                  dataIndex="code"
                  key="code"
                ></Column>
                <Column
                  title="生日"
                  align="center"
                  dataIndex="birthDate"
                  key="birthDate"
                ></Column>
              </Table>
            </Card>
          </Modal>
        )}
      </div>
    );
  }
}
export default NextNode;
