// @ts-nocheck
import React from 'react';
import {
  FcCard as Card,
  FcDivider as Divider,
  FcDescriptions as Descriptions,
  FcRow as Row,
  FcCol as Col,
} from '@ngfed/fc-components';
import cytoscape from 'cytoscape';
import { authAgentInfo } from './service.js';
import Moment from 'moment';
let cy = cytoscape({});
const style = { background: '#0092ff', padding: '8px 0' };
class AuthorizedToDo extends React.Component {
  state = {
    nodeInfo: '',
    authInfo: '',
    nodes: [],
    edges: [],
  };
  constructor(props) {
    super(props);
    this.renderCytoscapeElement = this.renderCytoscapeElement.bind(this);
  }
  componentDidMount() {
    authAgentInfo().then((res) => {
      // if (res.body.nodes.length > 0) {
      //   setTimeout(() => {
      //     this.addAnimation();
      //   }, 1000);
      // }
      const nodesTemp = [];
      res.body?.nodes?.map((item) => {
        const obj = {};
        const data = {};
        data.id = item.data.uuid;
        obj.data = data;
        nodesTemp.push(obj);
      });
      if (!res.body) {
        return false;
      }
      const edgesTemp = JSON.parse(JSON.stringify(res.body?.edges));
      this.setState({ edges: edgesTemp, nodes: nodesTemp }, () => {
        this.renderCytoscapeElement();
      });
    });
  }

  renderCytoscapeElement() {
    var that = this;
    cy = cytoscape({
      container: document.getElementById('cy'),

      boxSelectionEnabled: false,
      autounselectify: true,

      style: cytoscape
        .stylesheet()
        .selector('node')
        .css({
          height: 80,
          width: 80,
          color: 'white',
          'text-outline-width': 0.3,
          lable: 'data(id)',
          'background-fit': 'cover',
          'background-color': '#436EEE',
          'border-color': '#436EEE',
          'border-width': 2,
          'border-opacity': 0.5,
          content: 'data(id)',
          'text-valign': 'center',
          cursor: 'pointer',
        })
        .selector('edge')
        .css({
          width: 2,
          content: 'data(style)',
          'target-arrow-shape': 'triangle',
          'line-color': '#ffaaaa',
          'target-arrow-color': '#ffaaaa',
          'curve-style': 'bezier',
        })
        .selector('.highlighted')
        .css({
          // 'content':'data(id)',
          'background-color': '#d0413e',
          'line-color-color': 'red',
          'target-arrow': 'red',
          'source-arrow': 'red',
          'transition-property': 'background-color,line-color,target-arrow',
          'transition-duration': '0.5s',
        })
        // 节点形状，大小设置 node所有
        .selector('node[id="01013601"]')
        .css({
          shape: 'square', // triangle square
          background: 'blue',
          height: 70,
          width: 90,
          'border-width': 2,
          transform: 'rotate(100deg)',
          'transition-property': 'background-color,line-color,target-arrow',

          'transition-duration': '0.5s',
        })
        // 根据节点设置颜色
        .selector('node[id="0101360"],node[id="1603712123274"],node[name="7"]')
        .css({
          'background-color': 'red',
          'text-outline-width': 1,
          'text-outline-color': '#d0413e',
        }),
      elements: {
        nodes: that.state.nodes,
        edges: that.state.edges,
      },

      layout: {
        name: 'breadthfirst', // breadthfirst circle preset grid cose random
        directed: true,
        padding: 50,
        equidistant: false,
        clockwise: true,
        sweep: undefined,
        zoom: 0.7, //图形缩放
        // minZoom:1
      },
    });

    // 图形居中
    cy.center();

    // 线条点击事件
    cy.on('tap', 'edge', function (e) {
      var edge = e.target;
      that.setState({ authInfo: edge[0]._private.data, nodeInfo: '' });
    });

    // 节点点击事件
    cy.on('tap', 'node', function (e) {
      var node = e.target;
      that.setState({ nodeInfo: node[0]._private.data.id, authInfo: '' });
    });
  }

  addAnimation = () => {
    this.state.addd = setInterval(() => {
      this.add();
    }, 3000);
    this.state.reduced = setInterval(() => {
      this.reduce();
    }, 1000);
  };
  add = (params: type) => {
    const user = localStorage.getItem('username');
    if (!user) {
      return false;
    }
    var jsr = cy.$('0102666').animation({
      style: {
        'background-color': 'red',
        width: 100,
        height: 100,
        'font-size': 18,
      },
      duration: 1000,
    });
    jsr.play();
  };
  reduce = (params: type) => {
    const user = localStorage.getItem('username');
    if (!user) {
      return false;
    }
    var jsr = cy.$('0102666').animation({
      style: {
        'background-color': '#436EEE',
        width: 80,
        height: 80,
        'font-size': 14,
      },
      duration: 1000,
    });
    jsr.play();
  };

  componentWillUnmount() {
    clearInterval(this.state.addd);
    clearInterval(this.state.reduced);
  }
  render() {
    let sytype = {
      height: 700,
      width: 760,
      // margin: '20px',
    };
    return (
      <Card style={{ marginBottom: 20 }} bordered={false}>
        <Row justify="space-between">
          <Col span={13}>
            <Divider orientation="left">授权待办有向图</Divider>
          </Col>
          <Col span={10}>
            <Divider orientation="left">详细信息</Divider>
          </Col>
        </Row>
        <Row justify="space-between">
          <Col span={13}>
            <div style={sytype} id="cy" />
          </Col>
          <Col span={10}>
            {this.state.nodeInfo && (
              <Descriptions title="节点信息" size="middle" bordered>
                <Descriptions.Item label="人员工号">
                  {this.state.nodeInfo}
                </Descriptions.Item>
              </Descriptions>
            )}
            {this.state.authInfo && (
              <Descriptions
                title="线条信息"
                size="middle"
                layout="horizontal"
                bordered
              >
                <Descriptions.Item label="授权id">
                  {this.state.authInfo.authId}
                </Descriptions.Item>
                <Descriptions.Item label="授权人工号">
                  {this.state.authInfo.source}
                </Descriptions.Item>
                <Descriptions.Item label="被授权人工号">
                  {this.state.authInfo.target}
                </Descriptions.Item>
                <Descriptions.Item label="授权时间">
                  {Moment(this.state.authInfo.authStartTime).format(
                    'yyyy-MM-DD HH:mm:ss',
                  )}
                </Descriptions.Item>
                <Descriptions.Item label="授权结束时间">
                  {Moment(this.state.authInfo.authEndTime).format(
                    'yyyy-MM-DD HH:mm:ss',
                  )}
                </Descriptions.Item>
              </Descriptions>
            )}
          </Col>
        </Row>
      </Card>
    );
  }
}

// 导出一个流程设计组件
export default AuthorizedToDo;
