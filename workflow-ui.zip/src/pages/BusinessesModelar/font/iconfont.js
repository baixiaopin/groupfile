!(function (e) {
  var t,
    n,
    o,
    i,
    c,
    s,
    d =
      '<svg><symbol id="icon-shenpi" viewBox="0 0 1024 1024"><path d="M856.522638 643.384329H709.077517c-45.954635 0-83.210144-37.254485-83.210143-83.210143v-15.299451c0-32.006971 14.872732-61.541635 38.641065-82.977853 52.369741-47.228651 82.736353-118.333082 73.617671-196.280362-12.121062-103.647615-96.310509-187.342806-200.028732-198.872397-137.458675-15.280008-253.832126 91.910293-253.832126 226.28063 0 68.447928 30.275537 129.72555 78.105892 171.427324 23.469528 20.463054 35.761482 50.931996 35.761482 82.069158v13.653974c0 45.955658-37.255509 83.210144-83.210143 83.210144H167.477362c-27.41028 0-49.633421 22.221094-49.63342 49.634444v143.064346h788.311093V693.018773c0-27.412326-22.222117-49.634444-49.632397-49.634444zM117.843942 907.61427c0 28.218692 22.877033 51.094702 51.095725 51.094701h686.119643c28.218692 0 51.095725-22.87601 51.095725-51.094701v-1.459235H117.843942v1.459235z"  ></path></symbol><symbol id="icon-fenzhi-4" viewBox="0 0 1126 1024"><path d="M409.609011 0v307.12791h102.390989v153.665332H204.804506a102.053065 102.053065 0 0 0-102.390989 102.390988v153.597747H0v307.218023h307.218023V716.781977H204.804506v-153.597747h307.195494v153.597747h-102.390989v307.218023h307.195495V716.781977h-102.390989v-153.597747h307.195494v153.597747h-102.323404v307.218023H1126.413517V716.781977h-102.390989v-153.597747a102.053065 102.053065 0 0 0-102.413517-102.390988H614.413517v-153.665332h102.390989V0z"  ></path></symbol><symbol id="icon-chaosongren" viewBox="0 0 1024 1024"><path d="M989.191255 0L25.411498 462.059546s-57.060183 49.690976 0 94.417971c57.213708 44.675821 175.018678 125.890628 175.018678 125.890629s35.720186 33.059084 71.389198 0l383.710541-334.633667s26.764552-6.550407 12.435538 13.305514l-410.475094 389.237447-3.582253 223.532628s0 34.799035 35.617836 33.110258h23.233474s26.764552 3.377553 49.946851-29.88623l75.073801-104.192406s14.226665-24.92225 44.522296 3.224028l187.403041 129.217007s33.92906 18.167144 53.529104 18.167143h16.068967s30.346806 1.688777 35.720186-14.840765l231.976511-922.48149 16.068967-57.981334s7.164507-28.146279-33.877885-28.146279z" fill="#0090FF" ></path></symbol></svg>',
    l = (l = document.getElementsByTagName('script'))[
      l.length - 1
    ].getAttribute('data-injectcss');
  if (l && !e.__iconfont__svg__cssinject__) {
    e.__iconfont__svg__cssinject__ = !0;
    try {
      document.write(
        '<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>',
      );
    } catch (e) {
      console && console.log(e);
    }
  }
  function a() {
    c || ((c = !0), o());
  }
  (t = function () {
    var e, t, n;
    ((n = document.createElement('div')).innerHTML = d),
      (d = null),
      (t = n.getElementsByTagName('svg')[0]) &&
        (t.setAttribute('aria-hidden', 'true'),
        (t.style.position = 'absolute'),
        (t.style.width = 0),
        (t.style.height = 0),
        (t.style.overflow = 'hidden'),
        (e = t),
        (n = document.body).firstChild
          ? (t = n.firstChild).parentNode.insertBefore(e, t)
          : n.appendChild(e));
  }),
    document.addEventListener
      ? ~['complete', 'loaded', 'interactive'].indexOf(document.readyState)
        ? setTimeout(t, 0)
        : ((n = function () {
            document.removeEventListener('DOMContentLoaded', n, !1), t();
          }),
          document.addEventListener('DOMContentLoaded', n, !1))
      : document.attachEvent &&
        ((o = t),
        (i = e.document),
        (c = !1),
        (s = function () {
          try {
            i.documentElement.doScroll('left');
          } catch (e) {
            return void setTimeout(s, 50);
          }
          a();
        })(),
        (i.onreadystatechange = function () {
          'complete' == i.readyState && ((i.onreadystatechange = null), a());
        }));
})(window);
