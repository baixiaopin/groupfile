// @ts-nocheck
import React from 'react';

import {
  FcButton as Button,
  FcPopover as Popover,
  FcMessage as message,
} from '@ngfed/fc-components';
import NewNode from './NodeWrap';
import RightSetting from './RightSetting';
import '../index.less'; // contains .diagram-component CSS
import '../font/iconfont.js';
// render function...
class NodeWrap extends React.Component {
  state = {
    nodeConfig: this.props.nodeConfigData,
    RightSttingvisible: false,
    visibleNodeType: '',
    currentNodeInfo: null,
  };
  componentDidMount() {}

  /**
   * 打开右侧弹窗，将节点信息回显与设置
   * @param e 流程节点信息
   */
  setPerson = (e) => {
    this.setState({
      RightSttingvisible: true,
      currentNodeInfo: e,
    });
  };

  /**
   * 关闭左侧弹窗
   */
  onClose = () => {
    this.setState({
      RightSttingvisible: false,
    });
  };

  /**
   * 网关添加条件
   * 节点id以 ActId+时间戳+条件数
   * 将添加的条件直接push到节点数据的数组里面
   * this.props.transfer 通过调用父节点 重新渲染流程图
   */
  addTerm = () => {
    const ActivityIdTime = 'ActId' + new Date().getTime();
    const len = this.state.nodeConfig.conditionNodes.length;
    this.state.nodeConfig.conditionNodes.push({
      nodeName: '请设置条件',
      type: '03',
      activityId: ActivityIdTime + 'condition' + (len + 1),
      priorityLevel: len,
      conditionList: [],
      nodeUserList: [],
      childNode: null,
    });
    this.props.transfer(this.state.nodeConfig);
  };

  /**
   * 添加节点
   * @param e 根据网关分支点击不同的添加按钮，显示对应的添加框
   */
  addNode = (e) => {
    this.setState({ visibleNodeType: e });
  };

  /**
   *
   * @param type 添加的类型 04网关，03 审核人，02 抄送人
   * @param childNode 当前节点对应的json数据，直接修改添加
   * 添加完成后 根据 this.props.transfer 调用父组件重新渲染
   */
  addType = (type, childNode) => {
    const ActivityIdTime = 'ActId' + new Date().getTime();
    let data;
    if (type != '04') {
      if (type === '01') {
        data = {
          nodeName: '审核人添加',
          error: true,
          type: '01',
          activityId: ActivityIdTime,
          childNode: childNode,
          nodeUserList: [],
        };
      } else if (type === '02') {
        data = {
          nodeName: '抄送人添加',
          type: '02',
          activityId: ActivityIdTime,
          childNode: childNode,
          nodeUserList: [],
        };
      }
      const nodeConfigTemp = this.state.nodeConfig;
      // type-!04是除上一节点是网关的类型
      if (this.state.visibleNodeType == 'type-!04') {
        nodeConfigTemp.childNode = data;
        this.props.transfer(nodeConfigTemp);
      } else {
        nodeConfigTemp.conditionNodes[
          this.state.visibleNodeType
        ].childNode = data;
        this.props.transfer(nodeConfigTemp);
      }
      this.setState({ visibleNodeType: '' });
    } else {
      data = {
        nodeName: '路由',
        type: '04',
        activityId: ActivityIdTime + 'gatWay',
        childNode: null,
        conditionNodes: [
          {
            nodeName: '请设置条件',
            type: '03',
            activityId: ActivityIdTime + 'condition1',
            conditionList: [],
            nodeUserList: [],
            childNode: childNode,
          },
          {
            nodeName: '请设置条件',
            type: '03',
            activityId: ActivityIdTime + 'condition2',
            conditionList: [],
            nodeUserList: [],
            childNode: null,
          },
        ],
      };
      // const nodeConfigTemp = this.state.nodeConfig;
      // console.log(nodeConfigTemp);
      if (this.state.nodeConfig.type == '04') {
        this.state.nodeConfig.conditionNodes[
          this.state.visibleNodeType
        ].childNode = data;
      } else {
        this.state.nodeConfig.childNode = data;
      }

      this.props.transfer(this.state.nodeConfig);
      this.setState({ visibleNodeType: '' });
    }
  };

  /**
   * 根据节点的序号 如果是网关条件的直接删除
   *  如果删除的是最后一个，就将数据的类型改为05，传值到父组件，进行数据的处理，将类型为05的数据删除掉
   * @param index 节点的序号
   */
  delTerm = (index) => {
    this.props.transfer(this.state.nodeConfig.conditionNodes.splice(index, 1));
    if (this.state.nodeConfig.conditionNodes.length == 0) {
      this.state.nodeConfig.conditionNodes = [];
      this.state.nodeConfig.type = '05';
      if (this.state.nodeConfig.childNode) {
        this.state.nodeConfig = null;
      }
      this.props.transfer(this.state.nodeConfig);
    }
  };

  /**
   * 右侧子组件调用，关闭右侧弹窗
   */
  rightSettingsTranferNode = () => {
    this.setState({ RightSttingvisible: false });
  };

  /**
   * 删除节点
   * @param nodeConfig 当前节点的数据
   * @param type 节点的类型，开始节点00 不可删除
   * 因为这里不可直接删除，将节点的类型改为06，在父组件index中进行数据的处理
   */
  delNode = (nodeConfig, type) => {
    if (type == '00') {
      message.warn('开始节点不可删除');
    } else {
      nodeConfig.type = '06';
      this.props.transfer(nodeConfig);
    }
  };

  transfer = () => {
    this.props.transfer();
  };
  render() {
    return (
      <div>
        {this.state.nodeConfig.type != '04' && (
          <div className="node-wrap">
            <div
              className={
                this.state.nodeConfig.type === '00'
                  ? 'start-node node-wrap-box'
                  : 'node-wrap-box'
              }
            >
              <div>
                <div
                  className="title"
                  style={{
                    background:
                      this.state.nodeConfig.type === '01'
                        ? 'rgb(255, 148, 62)'
                        : this.state.nodeConfig.type === '02'
                        ? 'rgb(50, 150, 250)'
                        : 'rgb(87, 106, 149)',
                  }}
                >
                  {this.state.nodeConfig.type === '01' && (
                    <>
                      <span
                        className="iconfontBusModelarReviewer"
                        style={{ width: 15, height: 15 }}
                      ></span>
                      <i style={{ paddingLeft: 12, fontStyle: 'normal' }}>
                        审核人
                      </i>
                    </>
                  )}
                  {this.state.nodeConfig.type === '02' && (
                    <>
                      <span
                        className="iconfontBusModelarSong"
                        style={{ width: 15, height: 15 }}
                      ></span>
                      <i style={{ paddingLeft: 12 }}>抄送人</i>
                    </>
                  )}
                  {this.state.nodeConfig.type === '00' && (
                    <span>
                      {this.state.nodeConfig.nodeName
                        ? this.state.nodeConfig.nodeName
                        : '开始'}
                    </span>
                  )}
                  <i
                    className="anticon anticon-close close"
                    onClick={() =>
                      this.delNode(
                        this.state.nodeConfig,
                        this.state.nodeConfig.type,
                      )
                    }
                  >
                    x
                  </i>
                </div>

                <div
                  className="content"
                  onClick={() => {
                    this.setPerson(this.state.nodeConfig);
                  }}
                >
                  {this.state.nodeConfig.type === '02' && (
                    <div className="text">{this.state.nodeConfig.nodeName}</div>
                  )}
                  {this.state.nodeConfig.type === '01' && (
                    <div className="text">{this.state.nodeConfig.nodeName}</div>
                  )}
                  {this.state.nodeConfig.type === '00' && (
                    <div className="text">{'所有人'}</div>
                  )}
                  <i className="anticon anticon-right-workflow arrow"></i>
                </div>
              </div>
            </div>
            {/* 连线 */}
            <div className="add-node-btn-box">
              <div className="add-node-btn">
                <Popover
                  placement="rightTop"
                  title={'添加节点'}
                  content={
                    this.state.visibleNodeType === 'type-!04' && (
                      <div className="add-node-popover-body">
                        <a
                          className="add-node-popover-item approver"
                          onClick={() =>
                            this.addType('01', this.state.nodeConfig.childNode)
                          }
                        >
                          <div className="item-wrapper">
                            <span className="iconfontBusModelar iconfontBusModelarApprover">
                              <svg className="icon" aria-hidden="true">
                                <use href="#icon-shenpi"></use>
                              </svg>
                            </span>
                          </div>
                          <p>审批人</p>
                        </a>
                        <a
                          className="add-node-popover-item notifier"
                          onClick={
                            () => message.warn('暂不支持')
                            // this.addType('02', this.state.nodeConfig.childNode)
                          }
                        >
                          <div className="item-wrapper">
                            <span className="iconfontBusModelar iconfontBusModelarCcPerson">
                              <svg className="icon" aria-hidden="true">
                                <use href="#icon-chaosongren"></use>
                              </svg>
                            </span>
                          </div>
                          <p>抄送人</p>
                        </a>
                        <a
                          className="add-node-popover-item condition"
                          onClick={() =>
                            this.addType('04', this.state.nodeConfig.childNode)
                          }
                        >
                          <div className="item-wrapper">
                            <span className="iconfontBusModelar iconfontBusModelarBranch">
                              <svg className="icon" aria-hidden="true">
                                <use href="#icon-fenzhi-4"></use>
                              </svg>
                            </span>
                          </div>
                          <p>条件分支</p>
                        </a>
                      </div>
                    )
                  }
                  trigger="click"
                >
                  <button
                    onClick={() => this.addNode('type-!04')}
                    className="btn"
                    type="button"
                  >
                    <span className="iconfontBusModelar">+</span>
                  </button>
                </Popover>
              </div>
            </div>
          </div>
        )}
        {/*  */}
        {this.state.nodeConfig.type === '04' && (
          <div className="branch-wrap">
            <div className="branch-box-wrap">
              <div className="branch-box">
                <Button className="add-branch" onClick={this.addTerm}>
                  添加条件
                </Button>

                {this.state.nodeConfig.conditionNodes.map((item, index) => {
                  return (
                    <div className="col-box" key={index}>
                      <div className="condition-node">
                        <div className="condition-node-box">
                          <div
                            className="auto-judge"
                            onClick={() => {
                              this.setPerson(item);
                            }}
                          >
                            <div className="title-wrapper">
                              <span> {'条件' + (index + 1)}</span>
                              <span className="priority-title">优先级</span>
                              <i
                                className="anticon anticon-close close"
                                onClick={() => this.delTerm(index)}
                              >
                                x
                              </i>
                            </div>
                            <div className="content">{item.nodeName}</div>
                            {/* <div className="error_tip"></div> */}
                          </div>

                          {/* 添加节点  */}
                          <div className="add-node-btn-box">
                            <div className="add-node-btn">
                              <Popover
                                placement="rightTop"
                                title={'添加节点'}
                                content={
                                  this.state.visibleNodeType === index && (
                                    <div className="add-node-popover-body">
                                      <a
                                        className="add-node-popover-item approver"
                                        onClick={() =>
                                          this.addType(
                                            '01',
                                            this.state.nodeConfig
                                              .conditionNodes[index].childNode,
                                          )
                                        }
                                      >
                                        <div className="item-wrapper">
                                          <span className="iconfontBusModelar iconfontBusModelarApprover">
                                            <svg
                                              className="icon"
                                              aria-hidden="true"
                                            >
                                              <use href="#icon-shenpi"></use>
                                            </svg>
                                          </span>
                                        </div>
                                        <p>审批人</p>
                                      </a>
                                      <a
                                        className="add-node-popover-item notifier"
                                        onClick={
                                          () => message.warn('暂不支持')
                                          // this.addType(
                                          //   '02',
                                          //   this.state.nodeConfig.conditionNodes[index].childNode,
                                          // )
                                        }
                                      >
                                        <div className="item-wrapper">
                                          <span className="iconfontBusModelar iconfontBusModelarCcPerson">
                                            <svg
                                              className="icon"
                                              aria-hidden="true"
                                            >
                                              <use href="#icon-chaosongren"></use>
                                            </svg>
                                          </span>
                                        </div>
                                        <p>抄送人</p>
                                      </a>
                                      <a
                                        className="add-node-popover-item condition"
                                        onClick={() =>
                                          this.addType(
                                            '04',
                                            this.state.nodeConfig
                                              .conditionNodes[index].childNode,
                                          )
                                        }
                                      >
                                        <div className="item-wrapper">
                                          <span className="iconfontBusModelar iconfontBusModelarBranch">
                                            <svg
                                              className="icon"
                                              aria-hidden="true"
                                            >
                                              <use href="#icon-fenzhi-4"></use>
                                            </svg>
                                          </span>
                                        </div>
                                        <p>条件分支</p>
                                      </a>
                                    </div>
                                  )
                                }
                                trigger="click"
                              >
                                <button
                                  onClick={() => this.addNode(index)}
                                  className="btn"
                                  type="button"
                                >
                                  <span className="iconfontBusModelar">+</span>
                                </button>
                              </Popover>
                            </div>
                          </div>
                        </div>

                        {item.childNode && (
                          <NewNode
                            key={index}
                            nodeConfigData={item.childNode}
                            transfer={this.transfer}
                          ></NewNode>
                        )}
                        {index === 0 && (
                          <>
                            <div className="top-left-cover-line "></div>
                            <div className="bottom-left-cover-line "></div>
                          </>
                        )}

                        {index ===
                          this.state.nodeConfig.conditionNodes.length - 1 && (
                          <>
                            <div className="top-right-cover-line "></div>
                            <div className="bottom-right-cover-line"></div>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              {/* 连线 */}
              <div className="add-node-btn-box">
                <div className="add-node-btn">
                  <Popover
                    placement="rightTop"
                    title={'添加节点'}
                    content={
                      this.state.visibleNodeType === 'type-!04' && (
                        <div className="add-node-popover-body">
                          <a
                            className="add-node-popover-item approver"
                            onClick={() =>
                              this.addType(
                                '01',
                                this.state.nodeConfig.childNode,
                              )
                            }
                          >
                            <div className="item-wrapper">
                              <span className="iconfontBusModelar iconfontBusModelarApprover">
                                <svg className="icon" aria-hidden="true">
                                  <use href="#icon-shenpi"></use>
                                </svg>
                              </span>
                            </div>
                            <p>审批人</p>
                          </a>
                          <a
                            className="add-node-popover-item notifier"
                            onClick={
                              () => message.warn('暂不支持')
                              // this.addType(
                              //   '02',
                              //   this.state.nodeConfig.childNode,
                              // )
                            }
                          >
                            <div className="item-wrapper">
                              <span className="iconfontBusModelar iconfontBusModelarCcPerson">
                                <svg className="icon" aria-hidden="true">
                                  <use href="#icon-chaosongren"></use>
                                </svg>
                              </span>
                            </div>
                            <p>抄送人</p>
                          </a>
                          <a
                            className="add-node-popover-item condition"
                            onClick={() =>
                              this.addType(
                                '04',
                                this.state.nodeConfig.childNode,
                              )
                            }
                          >
                            <div className="item-wrapper">
                              <span className="iconfontBusModelar iconfontBusModelarBranch">
                                <svg className="icon" aria-hidden="true">
                                  <use href="#icon-fenzhi-4"></use>
                                </svg>
                              </span>
                            </div>
                            <p>条件分支</p>
                          </a>
                        </div>
                      )
                    }
                    trigger="click"
                  >
                    <button
                      onClick={() => this.addNode('type-!04')}
                      className="btn"
                      type="button"
                    >
                      <span className="iconfontBusModelar">+</span>
                    </button>
                  </Popover>
                </div>
              </div>
            </div>
          </div>
        )}

        {this.state.nodeConfig.childNode && (
          <NewNode
            nodeConfigData={this.state.nodeConfig.childNode}
            transfer={this.transfer}
          ></NewNode>
        )}

        {this.state.RightSttingvisible && (
          <RightSetting
            rightSettingsTranferNode={this.rightSettingsTranferNode}
            currentNodeInfo={this.state.currentNodeInfo}
          ></RightSetting>
        )}
      </div>
    );
  }
}

export default NodeWrap;
