// @ts-nocheck
import React from 'react';
import {
  FcButton as Button,
  FcDrawer as Drawer,
  FcMessage as message,
  FcForm as Form,
  FcInput as Input,
  FcSelect as Select,
  FcRow as Row,
  FcCol as Col,
  FcRadio as Radio,
  FcTag as Tag,
  FcSpace as Space,
} from '@ngfed/fc-components';
import OrgTree from '../../OrgTree';
import OrgTreeModal from '../../OrgTreeModal';
const { Option } = Select;
import { getInfosByIds } from '../../BusinessesTemplate/service';
class RightSetting extends React.Component {
  rightSettings = React.createRef();
  state = {
    RightSttingvisible: false,
    peopleType: '',
    orgTreeVisible: false,
    peopleList: [],
    selectPeopleType: '',
    assignee: '',
    isSequential: false,
    condition: 'perssion',
    userOvg: '',
  };

  /**
   * 进入就先显示，右侧属性栏
   */
  componentWillMount() {
    this.setState({ RightSttingvisible: true });
  }

  /**
   * 回显右侧数据
   * nodeName 节点名字
   * isSequential 判断是否会签
   * throughStrategy 会签通过策略
   * condition 通过表达式
   * candidateUsers 候选用户
   */

  componentDidMount() {
    const currentNodeInfo = this.props.currentNodeInfo;
    console.log('进入右侧设置', currentNodeInfo);
    const {
      nodeName,
      isSequential,
      throughStrategy,
      condition,
    } = this.props.currentNodeInfo;

    setTimeout(() => {
      this.rightSettings.current.setFieldsValue({
        nodename: nodeName,
        isSequential:
          isSequential === true
            ? 'true'
            : isSequential == false
            ? 'false'
            : false,
        condition: condition,
        throughStrategy: condition?.includes('%') == true ? 'per' : 'perssion',
      });

      this.setState({
        isSequential:
          isSequential === true
            ? 'true'
            : isSequential == false
            ? 'false'
            : false,
        condition: condition?.includes('%') == true ? 'per' : 'perssion',
      });

      // 如果node类型是01：审核人,并且存在处理人,并且是用户变量,调用getInfosByIds方法回显姓名
      if (currentNodeInfo.type == '01' && currentNodeInfo.assignee) {
        this.rightSettings.current.setFieldsValue({ peopleType: 1 });
        this.getInfosByIds(currentNodeInfo);
        this.setState({ selectPeopleType: 'user' });
      }
      if (currentNodeInfo.type == '01' && currentNodeInfo.candidateUsers) {
        this.rightSettings.current.setFieldsValue({ peopleType: 1 });
        this.getInfosByIds(currentNodeInfo);
        this.setState({ selectPeopleType: 'candidateUsers' });
      }
    });
  }

  /**
   * 回显处理人
   */
  getInfosByIds = (currentNodeInfo) => {
    //  指定用户变量
    if (currentNodeInfo.type == '01' && currentNodeInfo.assignee) {
      if (currentNodeInfo.assignee.includes('${') == false) {
        getInfosByIds({
          ids: currentNodeInfo.assignee,
        }).then((res) => {
          if (res.body) {
            const result = res?.body?.infosByIds
              ? res?.body?.infosByIds
              : res.body;
            result.map((item) => {
              item.id = item.empNo ? item.empNo : item.id;
            });
            this.setState({
              peopleList: result,
              peopleType: 1,
              assignee: [currentNodeInfo.assignee],
            });
          }
        });
      } else {
        this.setState({
          peopleList: [
            { id: '1100', name: '用户变量: ' + currentNodeInfo.assignee },
          ],
          assignee: [currentNodeInfo.assignee],
          peopleType: 1,
        });
      }
    }
    // 如果是候选用户变量
    if (currentNodeInfo.type == '01' && currentNodeInfo.candidateUsers) {
      if (currentNodeInfo.candidateUsers.includes('${') == false) {
        getInfosByIds({
          ids: currentNodeInfo.candidateUsers.toString(),
        }).then((res) => {
          if (res.body) {
            const result = res?.body?.infosByIds
              ? res?.body?.infosByIds
              : res.body;
            result.map((item) => {
              item.id = item.empNo ? item.empNo : item.id;
            });
            this.setState({
              peopleList: res.body,
              peopleType: 1,
              assignee: [currentNodeInfo.assignee],
            });
          }
        });
      } else {
        this.setState({
          peopleList: [
            {
              id: '1100',
              name: '候选用户变量: ' + currentNodeInfo.candidateUsers,
            },
          ],
          assignee: [currentNodeInfo.assignee],
          peopleType: 1,
        });
      }
    }
  };

  /**
   * 关闭右侧属性栏，同时清除form表单值，调用父组件方法
   */
  onClose = () => {
    this.setState({
      RightSttingvisible: false,
    });
    this.rightSettings.current.resetFields();
    this.props.rightSettingsTranferNode();
  };

  /**
   * 右侧属性栏 属性设置
   * 通过直接更改数组的值，达到更改数据的效果
   * candidateUsers 候选用户变量
   */
  onOk = () => {
    // 如果是 候选用户变量 或者处理人大于2 就设置处理人为candidateUsers
    const {
      nodename,
      isSequential,
      throughStrategy,
      condition,
    } = this.rightSettings.current.getFieldsValue();
    if (
      this.state.selectPeopleType == 'candidateUserVar' ||
      this.state.peopleList.length > 1
    ) {
      if (isSequential == 'false' || isSequential == 'true') {
        this.props.currentNodeInfo.assignee = this.state.assignee.toString();
        delete this.props.currentNodeInfo.candidateUsers;
      } else {
        this.props.currentNodeInfo.candidateUsers = this.state.assignee.toString();
        delete this.props.currentNodeInfo.assignee;
      }
    } else {
      this.props.currentNodeInfo.assignee = this.state.assignee.toString();
      delete this.props.currentNodeInfo.candidateUsers;
    }

    // 判断是否是条件节点
    if (this.props.currentNodeInfo.type == '03') {
      this.props.currentNodeInfo.condition =
        condition == undefined ? null : condition;
      this.props.currentNodeInfo.nodeName = nodename;
    } else {
      this.props.currentNodeInfo.condition =
        condition == undefined ? null : condition;
      this.props.currentNodeInfo.nodeName = nodename;
      this.props.currentNodeInfo.isSequential =
        isSequential === 'true' ? true : isSequential == 'false' ? false : null;
      this.props.currentNodeInfo.throughStrategy =
        throughStrategy == undefined ? null : throughStrategy;
    }
    this.props.rightSettingsTranferNode();
    this.rightSettings.current.resetFields();
  };

  peopleType = () => {
    const type = this.rightSettings.current.getFieldsValue().peopleType;
    this.setState({ peopleType: type });
  };

  // 组织架构树传值
  getUserData = (value, type) => {
    if (
      type == 'user' ||
      type == 'candidateUsers' ||
      type == 'userVar' ||
      type == 'candidateUserVar'
    ) {
      // 处理传值的变量
      if (type == 'userVar') {
        this.setState({
          assignee: value,
          peopleList: [{ name: '用户变量: ' + value, id: '1100' }],
          selectPeopleType: type,
        });
      }
      if (type == 'candidateUserVar') {
        this.setState({
          assignee: value,
          peopleList: [{ name: '候选用户变量: ' + value, id: '1100' }],
          selectPeopleType: type,
        });
      }
      if (type == 'user' || type == 'candidateUsers') {
        let assignee = value.map((obj) => {
          return obj.empNo;
        });
        this.setState({
          assignee: assignee,
          peopleList: value,
          selectPeopleType: type,
        });
      }
    } else {
      message.warn('暂不支持');
    }
    this.setState({ orgTreeVisible: false });
  };

  transferSelectType = (e) => {
    this.setState({ selectPeopleType: e });
  };

  // 根据id删除审核人
  deletById = (value) => {
    const arrDelegateLis = this.state.peopleList.filter(
      (item) => item.id !== value,
    );
    let assignee = arrDelegateLis.map((obj) => {
      return obj.empNo;
    });
    this.setState({
      peopleList: arrDelegateLis,
      assignee: assignee,
    });
  };

  /**
   *
   * @returns 权重传值
   */
  transferUserOvg = (e) => {};
  render() {
    return (
      <>
        {/* <Button type="primary" onClick={this.showDrawer}>
             <PlusOutlined /> New account
           </Button> */}
        <Drawer
          title={
            this.props.currentNodeInfo.type == '03' ? '条件设置' : '审批人设置'
          }
          width={600}
          onClose={this.onClose}
          visible={this.state.RightSttingvisible}
          bodyStyle={{ paddingBottom: 80, paddingLeft: 0, paddingRight: 0 }}
          footer={
            <div
              style={{
                textAlign: 'right',
              }}
            >
              <Button onClick={this.onClose} style={{ marginRight: 8 }}>
                取消
              </Button>
              <Button onClick={this.onOk} type="primary">
                确认
              </Button>
            </div>
          }
        >
          {this.props.currentNodeInfo.type == '01' && (
            <Form layout="vertical" hideRequiredMark ref={this.rightSettings}>
              <Row
                style={{ paddingLeft: 20, paddingRight: 20, marginRight: 0 }}
              >
                <Col span={24}>
                  <Form.Item
                    name="peopleType"
                    label=""
                    style={{ display: 'initial' }}
                    rules={[{ required: true, message: '请输入' }]}
                  >
                    <Radio.Group onChange={this.peopleType}>
                      {/* <Radio value={1}>指定人员</Radio> */}
                      <Radio value={1}>发起人自选</Radio>
                      <Radio value={2}>主管</Radio>
                      <Radio value={3}>发起人自己</Radio>
                    </Radio.Group>
                  </Form.Item>
                </Col>
                {this.state.peopleType == '1' && (
                  <>
                    <Col span={24}>
                      <Button
                        type="primary"
                        style={{ marginTop: '15px' }}
                        onClick={() => {
                          this.setState({ orgTreeVisible: true });
                        }}
                      >
                        添加成员
                      </Button>
                    </Col>
                    <Col span={20} style={{ display: 'contents' }}>
                      {this.state.peopleList &&
                        this.state.peopleList.map((item, index) => {
                          return (
                            <Tag
                              style={{
                                maxWidth: 247,
                                textOverflow: 'ellipsis',
                                overflow: 'hidden',
                                lineHeight: 'initial',
                                padding: 8,
                                marginTop: 8,
                              }}
                              color="blue"
                              closable
                              onClose={(e) => {
                                e.preventDefault();
                                this.deletById(item.id);
                              }}
                              key={index}
                            >
                              {item.name}
                            </Tag>
                          );
                        })}
                      {this.state.peopleList.length != 0 && (
                        <Button
                          style={{
                            marginTop: 12,
                            border: 'none',
                            color: '#3296fa',
                          }}
                          onClick={() => {
                            this.setState(
                              { peopleList: [], assignee: '' },
                              () => {
                                console.log('清除审核人');
                              },
                            );
                          }}
                        >
                          清除
                        </Button>
                      )}
                    </Col>
                  </>
                )}
              </Row>
              <div className="selected_list"></div>
              {this.state.peopleList.length > 1 &&
                this.state.peopleType == '1' && (
                  <>
                    <Row
                      style={{
                        paddingLeft: 20,
                        paddingRight: 20,
                        marginRight: 0,
                      }}
                    >
                      <Col span={24}>
                        <Form.Item
                          style={{ marginBottom: 0 }}
                          name="isSequential"
                          label="多人审批时采用的审批方式（会签）"
                          rules={[
                            {
                              required: true,
                              message: '请输入',
                            },
                          ]}
                        >
                          <Radio.Group
                            onChange={(e) => {
                              this.setState({ isSequential: e.target.value });
                            }}
                          >
                            <Space direction="vertical">
                              <Radio value={false}>无</Radio>
                              <Radio value={'true'}>并行</Radio>
                              <Radio value={'false'}>串行</Radio>
                            </Space>
                          </Radio.Group>
                        </Form.Item>
                      </Col>
                    </Row>

                    {/* 通过策略 */}

                    {this.state.isSequential && (
                      <Row
                        style={{
                          paddingLeft: 20,
                          paddingRight: 20,
                          marginRight: 0,
                        }}
                      >
                        <Col span={10}>
                          <Form.Item
                            style={{ marginBottom: 0, marginTop: '24px' }}
                            name="throughStrategy"
                            label="通过策略"
                            rules={[
                              {
                                required: true,
                              },
                            ]}
                          >
                            <Select
                              defaultValue="perssion"
                              onChange={(e) => {
                                this.setState({ condition: e });
                                this.rightSettings.current.setFieldsValue({
                                  condition: '',
                                });
                              }}
                            >
                              <Option value="per">比例通过</Option>
                              <Option value="perssion">表达式通过</Option>
                            </Select>
                          </Form.Item>
                        </Col>
                        {this.state.condition == 'per' && (
                          <Form.Item
                            name="condition"
                            label="条件"
                            style={{ marginBottom: 0, marginTop: '24px' }}
                          >
                            <Select style={{ width: 150 }} placeholder="请选择">
                              <Option value="10%">10%</Option>
                              <Option value="20%">20%</Option>
                              <Option value="30%">30%</Option>
                              <Option value="40%">40%</Option>
                              <Option value="50%">50%</Option>
                              <Option value="60%">60%</Option>
                              <Option value="70%">70%</Option>
                              <Option value="80%">80%</Option>
                              <Option value="90%">90%</Option>
                              <Option value="100%">100%</Option>
                            </Select>
                          </Form.Item>
                        )}
                        {this.state.condition == 'perssion' && (
                          <Form.Item
                            name="condition"
                            label="条件"
                            style={{ marginBottom: 0, marginTop: '24px' }}
                          >
                            <Input placeholder="请输入"></Input>
                          </Form.Item>
                        )}
                      </Row>
                    )}
                    <div className="selected_list"></div>
                  </>
                )}

              <Row
                style={{ paddingLeft: 20, paddingRight: 20, marginRight: 0 }}
              >
                <Col span={12}>
                  <Form.Item name="nodename" label="节点名称：">
                    <Input></Input>
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          )}
          {this.props.currentNodeInfo.type == '03' && (
            <Form layout="vertical" hideRequiredMark ref={this.rightSettings}>
              <Row
                style={{ paddingLeft: 20, paddingRight: 20, marginRight: 0 }}
              >
                <Col span={24}>
                  <Form.Item
                    name="condition"
                    label="通过表达式（当审批单同时满足以下条件时进入此流程）"
                    style={{ fontWeight: 600 }}
                    rules={[
                      {
                        pattern: /^\$\{.*\}$/,
                        message: '请以`${***}`形式',
                      },
                    ]}
                  >
                    <Input></Input>
                  </Form.Item>
                </Col>
              </Row>
              <Row
                style={{ paddingLeft: 20, paddingRight: 20, marginRight: 0 }}
              >
                <Col span={24}>
                  <Form.Item
                    name="nodename"
                    label="节点名字"
                    style={{ fontWeight: 600 }}
                    rules={[{ required: true, message: '请输入' }]}
                  >
                    <Input></Input>
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          )}
          {this.props.currentNodeInfo.type == '00' && (
            <Form ref={this.rightSettings}>
              <span>暂无</span>
            </Form>
          )}
          {this.props.currentNodeInfo.type == '02' && (
            <Form ref={this.rightSettings}>
              <span>暂无</span>
            </Form>
          )}

          {/* 选择 处理人 */}
          {this.state.orgTreeVisible && (
            <OrgTreeModal
              transfer={this.getUserData}
              transferSelectType={this.transferSelectType}
              activityId={this.props.currentNodeInfo.activityId}
              condition={this.state.condition}
              delegateList={this.state.peopleList}
              selectType={this.state.selectPeopleType}
              selectUserHandleCancel={() => {
                this.setState({ orgTreeVisible: false });
              }}
              userOvg={this.state.userOvg}
              transferUserOvg={this.transferUserOvg}
            ></OrgTreeModal>
          )}
        </Drawer>
      </>
    );
  }
}
export default RightSetting;
