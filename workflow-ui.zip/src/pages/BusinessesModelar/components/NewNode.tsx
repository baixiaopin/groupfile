// @ts-nocheck
import React from 'react';

import { FcButton as Button } from '@ngfed/fc-components';
import NodeWrap from './NodeWrap';
import RightSetting from './RightSetting';
import '../index.less'; // contains .diagram-component CSS
// render function...
class NewNode extends React.Component {
  state = {
    nodeConfig: this.props.nodeConfigData,
    RightSttingvisible: false,
    visible: false,
    currentNodeInfo: null,
  };
  componentDidMount() {}

  /**
   * 设置节点属性
   * @param e 当前选中节点的信息
   */
  setPerson = (e) => {
    this.setState({
      RightSttingvisible: true,
      currentNodeInfo: e,
    });
  };

  /**
   * 网关添加多一条件，
   */
  addTerm = () => {
    // console.log(this.state.nodeConfig.conditionNodes.length);
    const ActivityIdTime = 'ActId' + new Date().getTime();
    const len = this.state.nodeConfig.conditionNodes.length;
    this.state.nodeConfig.conditionNodes.push({
      nodeName: '请设置条件',
      type: '03',
      activityId: ActivityIdTime + 'condition' + (len + 1),
      priorityLevel: len,
      conditionList: [],
      nodeUserList: [],
      childNode: null,
    });
    this.props.transfer(this.state.nodeConfig);
  };

  // 添加节点
  addNode = (e) => {
    const temp = this.state.visible;
    if (temp === e) {
      this.setState({ visible: '' });
    } else {
      this.setState({ visible: e });
    }
  };

  /**
   * 添加节点，根据节点类型添加不同的节点
   * @param type 添加的节点类型
   * @param childNode 当前节点的子节点
   */
  addType = (type, childNode) => {
    const ActivityIdTime = 'ActId' + new Date().getTime();
    let data;
    if (type != '04') {
      if (type === '01') {
        data = {
          nodeName: '审核人添加',
          error: true,
          type: '01',
          activityId: ActivityIdTime,
          childNode: childNode,
          nodeUserList: [],
        };
      } else if (type === '02') {
        data = {
          nodeName: '抄送人添加',
          type: '02',
          activityId: ActivityIdTime,
          childNode: childNode,
          nodeUserList: [],
        };
      }
      const dataa = this.state.nodeConfig;
      if (this.state.visible == 'type-!04') {
        dataa.childNode = data;
        this.props.transfer(dataa, dataa.activvityId);
      } else {
        dataa.conditionNodes[this.state.visible].childNode = data;
        this.props.transfer(dataa, dataa.activvityId);
      }

      this.setState({ visible: '' });
    } else {
      data = {
        nodeName: '路由',
        type: '04',
        activityId: ActivityIdTime + 'gatWay',
        childNode: null,
        conditionNodes: [
          {
            nodeName: '请设置条件',
            type: '03',
            activityId: ActivityIdTime + 'condition1',
            conditionList: [],
            nodeUserList: [],
            childNode: childNode,
          },
          {
            nodeName: '请设置条件',
            type: '03',
            activityId: ActivityIdTime + 'condition2',
            conditionList: [],
            nodeUserList: [],
            childNode: null,
          },
        ],
      };
      const dataa = this.state.nodeConfig;
      dataa.childNode = data;
      this.props.transfer(dataa, dataa.activvityId);
      this.setState({ visible: '' });
    }
  };

  /**
   * 删除节点
   * @param index 节点序号，类型
   */
  delTerm = (index) => {
    // console.log(index);
    this.props.transfer(this.state.nodeConfig.conditionNodes.splice(index, 1));
    if (this.state.nodeConfig.conditionNodes.length == 0) {
      this.state.nodeConfig.conditionNodes = [];
      this.state.nodeConfig.type = '05';
      if (this.state.nodeConfig.childNode) {
        this.state.nodeConfig = null;
      }
      this.props.transfer(this.state.nodeConfig);
    }
  };

  transfer = (data, ActivityIdTime) => {
    this.props.transfer(data, ActivityIdTime);
  };

  /**
   *子组件传值关闭右侧
   */
  rightSettingsTranferNode = () => {
    this.setState({ RightSttingvisible: false });
  };

  render() {
    return (
      <div>
        {this.state.nodeConfig.type != '04' && (
          <div className="node-wrap">
            <div
              className={
                this.state.nodeConfig.type === '00'
                  ? 'start-node node-wrap-box'
                  : 'node-wrap-box'
              }
            >
              <div>
                <div
                  className="title"
                  style={{
                    background:
                      this.state.nodeConfig.type === '01'
                        ? 'rgb(255, 148, 62)'
                        : this.state.nodeConfig.type === '02'
                        ? 'rgb(50, 150, 250)'
                        : 'rgb(87, 106, 149)',
                  }}
                >
                  {this.state.nodeConfig.type === '01' && (
                    <>
                      <span
                        className="iconfontReviewer"
                        style={{ width: 15, height: 15 }}
                      ></span>
                      <i style={{ paddingLeft: 12, fontStyle: 'normal' }}>
                        审核人
                      </i>
                    </>
                  )}
                  {this.state.nodeConfig.type === '02' && (
                    <>
                      <span
                        className="iconfontSong"
                        style={{ width: 15, height: 15 }}
                      ></span>
                      <i style={{ paddingLeft: 12 }}>抄送人</i>
                    </>
                  )}
                  {this.state.nodeConfig.type === '00' && (
                    <span>{this.state.nodeConfig.nodeName}</span>
                  )}
                </div>

                <div
                  className="content"
                  onClick={() => {
                    this.setPerson(this.state.nodeConfig);
                  }}
                >
                  {this.state.nodeConfig.type === '02' && (
                    <div className="text">{this.state.nodeConfig.nodeName}</div>
                  )}
                  {this.state.nodeConfig.type === '01' && (
                    <div className="text">{this.state.nodeConfig.nodeName}</div>
                  )}
                  {this.state.nodeConfig.type === '00' && (
                    <div className="text">{'所有人'}</div>
                  )}
                  <i className="anticon anticon-right-workflow arrow"></i>
                </div>
              </div>
            </div>
            {/* 连线 */}
            <div className="add-node-btn-box">
              <div className="add-node-btn">
                <button
                  onClick={() => this.addNode('type-!04')}
                  className="btn"
                  type="button"
                >
                  <span className="iconfont">+</span>
                </button>
                {this.state.visible === 'type-!04' && (
                  <div className="add-node-popover-body">
                    <a
                      className="add-node-popover-item"
                      onClick={() =>
                        this.addType('01', this.state.nodeConfig.childNode)
                      }
                    >
                      <div className="item-wrapper">
                        <span className="iconfont"></span>
                      </div>
                      <p>审批人</p>
                    </a>
                    <a
                      className="add-node-popover-item notifier"
                      onClick={() =>
                        this.addType('02', this.state.nodeConfig.childNode)
                      }
                    >
                      <div className="item-wrapper">
                        <span className="iconfont"></span>
                      </div>
                      <p>抄送人</p>
                    </a>
                    <a
                      className="add-node-popover-item condition"
                      onClick={() =>
                        this.addType('04', this.state.nodeConfig.childNode)
                      }
                    >
                      <div className="item-wrapper">
                        <span className="iconfont"></span>
                      </div>
                      <p>条件分支</p>
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        {/*  */}
        {this.state.nodeConfig.type === '04' && (
          <div className="branch-wrap">
            <div className="branch-box-wrap">
              <div className="branch-box">
                <Button className="add-branch" onClick={this.addTerm}>
                  添加条件
                </Button>

                {this.state.nodeConfig.conditionNodes.map((item, index) => {
                  return (
                    <div className="col-box">
                      <div className="condition-node">
                        <div className="condition-node-box">
                          <div className="auto-judge">
                            <div className="title-wrapper">
                              <span> {'条件' + (index + 1)}</span>
                              <span className="priority-title">优先级</span>
                              <i
                                className="anticon anticon-close close"
                                onClick={() => this.delTerm(index)}
                              >
                                x
                              </i>
                            </div>
                            <div
                              className="content"
                              onClick={() => {
                                this.setPerson(item);
                              }}
                            >
                              {item.nodeName}
                            </div>
                            {/* <div className="error_tip"></div> */}
                          </div>

                          {/* 添加节点  */}
                          <div className="add-node-btn-box">
                            <div className="add-node-btn">
                              <button
                                onClick={() => this.addNode(index)}
                                className="btn"
                                type="button"
                              >
                                <span className="iconfont">+</span>
                              </button>
                              {this.state.visible === index && (
                                <div className="add-node-popover-body">
                                  <a
                                    className="add-node-popover-item approver"
                                    onClick={() =>
                                      this.addType('01', item.childNode)
                                    }
                                  >
                                    <div className="item-wrapper">
                                      <span className="iconfont"></span>
                                    </div>
                                    <p>审批人</p>
                                  </a>
                                  <a
                                    className="add-node-popover-item notifier"
                                    onClick={() =>
                                      this.addType('02', item.childNode)
                                    }
                                  >
                                    <div className="item-wrapper">
                                      <span className="iconfont"></span>
                                    </div>
                                    <p>抄送人</p>
                                  </a>
                                  <a
                                    className="add-node-popover-item condition"
                                    onClick={() =>
                                      this.addType('04', item.childNode)
                                    }
                                  >
                                    <div className="item-wrapper">
                                      <span className="iconfont"></span>
                                    </div>
                                    <p>条件分支</p>
                                  </a>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {item.childNode && (
                          <NodeWrap
                            key={index}
                            nodeConfigData={item.childNode}
                            transfer={this.transfer}
                          ></NodeWrap>
                        )}
                        {index === 0 && (
                          <>
                            <div className="top-left-cover-line background"></div>
                            <div className="bottom-left-cover-line background"></div>
                          </>
                        )}

                        {index ===
                          this.state.nodeConfig.conditionNodes.length - 1 && (
                          <>
                            <div className="top-right-cover-line background"></div>
                            <div className="bottom-right-cover-line"></div>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="add-node-btn-box">
                <div className="add-node-btn">
                  <button
                    onClick={() => this.addNode('type-!04')}
                    className="btn"
                    type="button"
                  >
                    <span className="iconfont">+</span>
                  </button>
                  {this.state.visible === 'type-!04' && (
                    <div className="add-node-popover-body">
                      <a
                        className="add-node-popover-item approver"
                        onClick={() =>
                          this.addType('01', this.state.nodeConfig.childNode)
                        }
                      >
                        <div className="item-wrapper">
                          <span className="iconfont"></span>
                        </div>
                        <p>审批人</p>
                      </a>
                      <a
                        className="add-node-popover-item notifier"
                        onClick={() =>
                          this.addType('02', this.state.nodeConfig.childNode)
                        }
                      >
                        <div className="item-wrapper">
                          <span className="iconfont"></span>
                        </div>
                        <p>抄送人</p>
                      </a>
                      <a
                        className="add-node-popover-item condition"
                        onClick={() =>
                          this.addType('04', this.state.nodeConfig.childNode)
                        }
                      >
                        <div className="item-wrapper">
                          <span className="iconfont"></span>
                        </div>
                        <p>条件分支</p>
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {this.state.nodeConfig.childNode && (
          <NodeWrap
            nodeConfigData={this.state.nodeConfig.childNode}
            transfer={this.transfer}
          ></NodeWrap>
        )}

        {this.state.RightSttingvisible && (
          <RightSetting
            rightSettingsTranferNode={this.rightSettingsTranferNode}
            currentNodeInfo={this.state.currentNodeInfo}
          ></RightSetting>
        )}
      </div>
    );
  }
}

export default NewNode;
