// @ts-nocheck
import React from 'react';
import {
  saveBusinessModel,
  updateBusinessModelXML,
} from '../BusinessesTemplate/service';
import './index.less';
import NodeWrap from './components/NodeWrap';
import { FcMessage as message } from '@ngfed/fc-components';
// render function...
class BusinessesModelar extends React.Component {
  state = {
    // 起始节点json数据
    nodeConfig: {
      activityId: 'sid-start-node',
      nodeName: '发起人',
      type: '00',
      conditionList: [],
      nodeUserList: [],
      childNode: null,
      conditionNodes: [],
    },
    // 业务流程flag
    businessProcessFlag: 1,
    // 缩放倍数
    nowVal: 100,
  };

  /**
   * 子组件传值json数据
   * 如果存在就将数据赋值给nodeConfig渲染流程图
   */
  componentWillMount() {
    const businessViewerXml = this.props.businessViewerXml;
    if (businessViewerXml) {
      this.setState({ nodeConfig: this.props.businessViewerXml });
    }
  }

  /**
   * 处理子组件传值过来的数据
   * @param data 传值 添加节点之后的节点数据
   * @param ActivityIdTime 节点id 以'activityId'+时间戳作为id
   */
  transfer = () => {
    let nodesData = this.state.nodeConfig;
    this.reData(nodesData);
    // 确保传值过来的数据可以重新渲染，先将businessProcessFlag置为2，在用setTimeout处理置为1，同时获取函数reData处理后的数据
    this.setState({ businessProcessFlag: 2 });
    setTimeout(() => {
      this.setState({
        businessProcessFlag: 1,
        nodeConfig: this.state.nodeConfig,
      });
    });
  };

  /**
   * 处理数据 因为不能直接修改数组删除，因此以改变数组的类型type,在首页进行一个数据的处理
   * type=='05' 是删除网关条件中最后一个分支节点，循环查找是否含有type等于05的对象，然后进行删除
   * type=='06' 是删除流程的节点和网关条件中的节点，循环查找是否含有type等于06的对象，然后进行删除
   * 如果是网关节点中的则循环条件conditionNodes中的条件查找删除
   * @param nodesData 节点数据
   */
  reData = (nodesData) => {
    for (let key in nodesData) {
      if (
        key == 'childNode' &&
        nodesData[key] != null &&
        nodesData[key].type == '05'
      ) {
        delete nodesData[key];
      }
      if (
        key == 'childNode' &&
        nodesData[key] != null &&
        nodesData[key].type == '06'
      ) {
        nodesData.childNode = nodesData[key].childNode;
      }
      if (nodesData[key] && nodesData[key].childNode) {
        this.reData(nodesData[key]);
      }
      if (
        nodesData[key] &&
        nodesData[key].type == '04' &&
        nodesData[key].conditionNodes
      ) {
        nodesData[key].conditionNodes.map((item) => {
          this.reData(item);
        });
      }
    }
    this.setState({ nodeConfig: nodesData });
  };

  /**
   *
   * @param type 放大还是缩小的类型
   * @returns
   */
  zoomSize = (type) => {
    let nowVal = this.state.nowVal;
    if (type == 1) {
      if (nowVal == 50) {
        return;
      }
      nowVal -= 10;
      this.setState({ nowVal: nowVal });
    } else {
      if (nowVal == 300) {
        return;
      }
      nowVal += 10;
      this.setState({ nowVal: nowVal });
    }
  };

  /**
   * 关闭设计器，调用父组件事件
   */
  closeModelar = () => {
    this.props.closeModelar();
  };

  /**
   * 根据父组件传值的是否有创建人，判断是新建还是需要更新的
   */
  publish = () => {
    if (this.props.currentInfo?.createdBy) {
      updateBusinessModelXML({
        modelId: this.props.currentInfo?.modelId,
        businessJSON: this.state.nodeConfig,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          message.success('保存成功');
          this.props.closeModelar();
        }
      });
    } else {
      saveBusinessModel({
        ...this.props.currentInfo,
        BusinessJson: this.state.nodeConfig,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          message.success('创建成功');
          this.props.closeModelar();
        }
      });
    }
  };

  render() {
    return (
      <div>
        <div className="fd-nav">
          <div className="fd-nav-left">
            <div className="fd-nav-back" onClick={this.closeModelar}>
              <i className="anticon1 bus-anticon-left"> {'<'} </i>
            </div>
            <div className="fd-nav-title">流程设计</div>
          </div>
          <div className="fd-nav-right">
            <button
              type="button"
              className="ant-btn button-publish"
              onClick={this.publish}
            >
              <span>保 存</span>
            </button>
          </div>
        </div>
        <div className="fd-nav-content">
          <section className="dingflow-design-bus">
            <div className="zoomBusinesses">
              <div
                className={
                  'zoom-out' + (this.state.nowVal == 50 ? 'disabled' : '')
                }
                onClick={() => this.zoomSize(1)}
              >
                <span className="reduceNowVal">－</span>
              </div>
              <span>{this.state.nowVal}%</span>
              <div
                className={
                  'zoom-in' + (this.state.nowVal == 300 ? 'disabled' : '')
                }
                onClick={() => this.zoomSize(2)}
              >
                <span className="addNowVal">+</span>
              </div>
            </div>
            <div
              className="box-scale"
              id="box-scale"
              style={{
                transform: 'scale(' + this.state.nowVal / 100 + ')',
                transformOrigin: '50% 0px 0px',
              }}
            >
              {this.state.businessProcessFlag == 1 && (
                <NodeWrap
                  transfer={this.transfer}
                  nodeConfigData={this.state.nodeConfig}
                ></NodeWrap>
              )}
              {this.state.businessProcessFlag == 2 && (
                <NodeWrap
                  transfer={this.transfer}
                  nodeConfigData={this.state.nodeConfig}
                ></NodeWrap>
              )}

              <div className="end-node">
                <div className="end-node-circle"></div>
                <div className="end-node-text">流程结束</div>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default BusinessesModelar;
