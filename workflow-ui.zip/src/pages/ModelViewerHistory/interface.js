import request from '../../utils/request';

/**
 * 查询模型列表
 */
export function queryHistoryModelXML({ id, modelHistoryId }) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelVersionResSVC',
        stdIntfcInd: 'getHistoryModelXML',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
        modelHistoryId,
      },
    },
  });
}
