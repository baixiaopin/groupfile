// @ts-nocheck
import React from 'react';
import BpmnViewer from 'bpmn-js/lib/Modeler';
import '../ProcessViewerModel/index';
import { queryHistoryModelXML as apiQueryHistoryModelXML } from './interface';

class ModelViewerHistory extends React.Component {
  state = {
    taskList: [],
  };

  createNewDiagram() {}

  componentDidMount() {
    if (!this.props.modelId) {
      alert('缺少');
      return;
    }
    this.getModelXML();
  }

  // 获取模型的XML
  async getModelXML() {
    const res = await apiQueryHistoryModelXML({
      id: this.props.modelId,
      modelHistoryId: this.props.modelHistoryId,
    });
    const modelXML = res.body.historyModelXML;
    // this.taskList = this.props.taskData;
    let bpmnViewer = new BpmnViewer({
      container: document.getElementById('canvas'),
    });
    let _self = this;
    bpmnViewer.importXML(modelXML, function (err) {
      if (err) {
      } else {
        let canvas = bpmnViewer.get('canvas');
        canvas.zoom('fit-viewport', 'auto');
        // let overlays = bpmnViewer.get('overlays');
        // let overlayHtml = document.createElement('div');
        // overlays.add('StartEvent_1', {
        //   position: {
        //     top: 0,
        //     right: 0,
        //   },
        //   html: overlayHtml
        // });
        // 判断开始节点或结束节点完成

        if (bpmnViewer._definitions.rootElements.length == 1) {
          bpmnViewer._definitions.rootElements[0].flowElements.forEach(
            (n, index) => {
              if (n.$type === 'bpmn:StartEvent') {
                canvas.addMarker(n.id, 'start-event');
              }
              if (n.$type === 'bpmn:UserTask') {
                canvas.addMarker(n.id, 'user-task');
              }
              if (n.$type === 'bpmn:ServiceTask') {
                canvas.addMarker(n.id, 'service-task');
              }
              if (n.$type === 'bpmn:ExclusiveGateway') {
                canvas.addMarker(n.id, 'highlight');
              }
            },
          );
        }
        if (bpmnViewer._definitions.rootElements.length == 2) {
          bpmnViewer._definitions.rootElements[1].flowElements.forEach(
            (n, index) => {
              if (n.$type === 'bpmn:StartEvent') {
                canvas.addMarker(n.id, 'start-event');
              }
              if (n.$type === 'bpmn:UserTask') {
                canvas.addMarker(n.id, 'user-task');
              }
              if (n.$type === 'bpmn:ServiceTask') {
                canvas.addMarker(n.id, 'service-task');
              }
              if (n.$type === 'bpmn:ParallelGateway') {
                canvas.addMarker(n.id, 'highlight');
              }
              if (n.$type === 'bpmn:ExclusiveGateway') {
                canvas.addMarker(n.id, 'highlight');
              }
            },
          );
        }
      }
    });
  }

  render() {
    return (
      <div className="containers boxx">
        <div id="canvas" className="canvas"></div>
      </div>
    );
  }
}

export default ModelViewerHistory;
