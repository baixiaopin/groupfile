import request from '../../utils/request';

// 查询模型列表
export function queryModelList(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'queryModels',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 新建模型
export function newBuildModel(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'saveModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}
// 校验key值是否重复
export function validateModelKey(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'validateModelKey',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}
// 更新模型
export function updateModel({
  id,
  key,
  name,
  modelType: type,
  description,
  specificType,
}) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'updateModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: { id, key, name, type, description, specificType },
    },
  });
}

// 发布模型，也叫部署模型
export function publishModel(record) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'deployModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        modelId: record.id,
      },
    },
  });
}

/**
 * 删除模型
 * @param {*} id
 */
export function deleteModel(id) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'deleteModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
      },
    },
  });
}

// 导入bpmn
export function importModel(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'importModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 导出
export function checkOutModel(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'checkOutModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 获取流程模型案例
export function getSampleModelXml(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'getSampleModelXml',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 查询业务列表
 */
export function listBusinessModelType() {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'listBusinessModelType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {},
    },
  });
}

/**
 * 技术模型转业务模型
 */
export function transToBusinessModel(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelSVC',
        stdIntfcInd: 'transToBusinessModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 获取业务流程节点
 * @param {*} data
 */
export function getModelActInfo(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'getModelActInfo',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
/**
 * 根据技术模型id查看所有裁剪技术模型信息
 */
export function listTechnologyModelInfo(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ChooseBusinessModelInfoSVC',
        stdIntfcInd: 'listTechnologyModelInfo',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
/**
 * 保存编辑裁剪的技术模型信息
 */
export function editTechnologyModelInfo(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ChooseBusinessModelInfoSVC',
        stdIntfcInd: 'editTechnologyModelInfo',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}
// 获取节点插件配置
export function getConfigurationKey(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelTypeSVC',
        stdIntfcInd: 'getConfigurationKey',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}
// 导出
export function outPutModel(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'outPutModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}