// @ts-nocheck
import {
  FcButton as Button,
  FcCard as Card,
  FcDivider as Divider,
  FcDrawer as Drawer,
  FcForm as Form,
  FcInput as Input,
  FcModal as Modal,
  FcPopconfirm as Popconfirm,
  FcTable as Table,
  FcTreeSelect as TreeSelect,
  FcMessage as message,
  FcConfigProvider as ConfigProvider,
  FcTooltip as Tooltip,
  FcDropdown as Dropdown,
  FcMenu as Menu,
  FcSpin as Spin,
  FcRow
} from '@ngfed/fc-components';
import { sampleTemplate } from './template';
import ModelDesigner from '../ModelDesigner';
import EditingTool from '@/components/editingTool';
import ModelViewer from '../ModelViewer';
import PublishVersionManage from '../PublishVersionManage';
import { FormInstance } from 'antd/lib/form';
import ModelConfig from './components/ModelConfig';
import React from 'react';
import {
  queryModelList,
  updateModel,
  publishModel,
  deleteModel,
  importModel,
  checkOutModel,
  validateModelKey,
  listBusinessModelType,
  transToBusinessModel,
  listTechnologyModelInfo,
  getModelActInfo,
  outPutModel
} from './service';
import { getModelTypeOptions } from '../ModelType/service';
import VersionManage from '../VersionManage';
import Moment from 'moment';
import zhCN from 'antd/lib/locale/zh_CN';
import '../ModelType/index.less'
var modelType = '';

class ModelManage extends React.Component {
  state = {
    modelTypee: '',
    modelInfoArray: [],
    currentModel: {},
    newBuildVisible: false,
    editVisible: false,
    versionManageVisible: false,
    modelPreviewVisible: false,
    processDesignVisible: false,
    modelSonTypeStatus: false,
    modelList: [],
    modelTypeOptions: [],
    modelSonTypeOptions: [],
    modelState: [],
    // 业务模板
    bussinessesType: false,
    bussinessesModelTypeList: [],
    currentModel: '',
    loading: false,
    selectedRowsId: '',
    pagination: {
      current: 1,
      pageSize: 10,
      total: 0,
    },
    mode: 0,
    columns: [
      {
        title: '模型Key',
        dataIndex: 'key',
        key: 'key',

        ellipsis: {
          showTitle: false,
        },
        render: (key) => (
          <Tooltip placement="topLeft" title={key}>
            {key}
          </Tooltip>
        ),
      },
      {
        title: '模型名称',
        dataIndex: 'name',
        key: 'name',

        ellipsis: {
          showTitle: false,
        },
        render: (name) => (
          <Tooltip placement="topLeft" title={name}>
            {name}
          </Tooltip>
        ),
      },
      {
        title: '模型类型（大类）',
        dataIndex: 'typeName',
        key: 'typeName',
        width: 150,
        ellipsis: {
          showTitle: false,
        },
        render: (typeName) => (
          <Tooltip
            placement="topLeft"
            title={typeName == null ? '根目录' : typeName}
          >
            {typeName == null ? '根目录' : typeName}
          </Tooltip>
        ),
      },
      {
        title: '模型小类（小类）',
        dataIndex: 'specificTypeName',
        key: 'specificTypeName',
        width: 150,
        ellipsis: {
          showTitle: false,
        },
        render: (specificTypeName) => (
          <Tooltip placement="topLeft" title={specificTypeName}>
            {specificTypeName}
          </Tooltip>
        ),
      },
      {
        title: '当前版本',
        dataIndex: 'version',
        key: 'version',
        width: 130,
        ellipsis: {
          showTitle: false,
        },
        render: (version) => (
          <Tooltip placement="topLeft" title={version}>
            {version}
          </Tooltip>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'created',
        key: 'created',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      {
        title: '修改时间',
        dataIndex: 'lastUpdated',
        key: 'lastUpdated',

        ellipsis: {
          showTitle: false,
        },
        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      {
        title: '创建人',
        dataIndex: 'createdBy',
        key: 'createdBy',

        ellipsis: {
          showTitle: true,
        },
        render: (createdBy) => (
          <Tooltip placement="topLeft" title={createdBy}>
            {createdBy}
          </Tooltip>
        ),
      },
      {
        title: '修改人',
        dataIndex: 'lastUpdatedBy',
        key: 'lastUpdatedBy',

        ellipsis: {
          showTitle: false,
        },
        render: (lastUpdatedBy) => (
          <Tooltip placement="topLeft" title={lastUpdatedBy}>
            {lastUpdatedBy}
          </Tooltip>
        ),
      },
      {
        title: '模型描述',
        dataIndex: 'description',
        key: 'description',

        ellipsis: {
          showTitle: false,
        },
        render: (description) => (
          <Tooltip placement="topLeft" title={description}>
            {description}
          </Tooltip>
        ),
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',
        width: 350,
        fixed: 'right',
        render: (text, record, index) => (
          <>
            <a
              onClick={(e) => {
                e.preventDefault();
                this.openEdit(record);
              }}
            >
              编辑
            </a>
            <Divider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />
            <a
              onClick={(e) => {
                e.preventDefault();
                this.openProcessDesign(record);
              }}
            >
              流程设计
            </a>
            <Divider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />
            <Popconfirm
              title="确认发布？"
              onConfirm={() => this.publish(record)}
              okText="是"
              cancelText="否"
            >
              <a>发布</a>
            </Popconfirm>
            <Divider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />
            <Popconfirm
              title="确认删除？"
              onConfirm={() => this.deleteModel(record)}
              okText="是"
              cancelText="否"
            >
              <a>删除</a>
            </Popconfirm>
            <Divider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />
            {/* <a
              onClick={(e) => {
                e.preventDefault();
                this.export(record);
              }}
            >
              导出
            </a> */}
             <a    
                  onClick={(e) => {
                  e.preventDefault();
                  this.exportTwo(record);
                }}>导出</a>
            <Divider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />

            <Dropdown
              placement="bottomCenter"
              overlay={
                <Menu>
                  <Menu.Item>
                    <a
                      onClick={(e) => {
                        e.preventDefault();
                        this.bussinessesTypeConfig(record);
                      }}
                    >
                      转化为业务模板
                    </a>
                  </Menu.Item>
                  <Menu.Item>
                    <a
                      onClick={(e) => {
                        e.preventDefault();
                        this.openModelConfig(record);
                      }}
                    >
                      节点配置
                    </a>
                  </Menu.Item>
                  <Menu.Item>
                    <a
                      onClick={(e) => {
                        e.preventDefault();
                        this.openModelPreview(record);
                      }}
                    >
                      模型预览
                    </a>
                  </Menu.Item>
                  <Menu.Item>
                    <a
                      onClick={(e) => {
                        e.preventDefault();
                        this.openPublishVersion(record);
                      }}
                    >
                      发布版本
                    </a>
                  </Menu.Item>
                  <Menu.Item>
                    <a
                      onClick={(e) => {
                        e.preventDefault();
                        this.openVersionManage(record);
                      }}
                    >
                      历史版本
                    </a>
                  </Menu.Item>
                </Menu>
              }
            >
              <a
                onClick={(e) => {
                  e.preventDefault();
                }}
              >
                更多功能
              </a>
            </Dropdown>
          </>
        ),
      },
    ],
    modelConfigVisable: false,
    configurationKeys: [],
    chooseBusinessModelInfoResps: [],
    exportTwoVisable:false,
    currentEditRowData:{},
  };

  searchFormRef = React.createRef<FormInstance>();
  newBuildFormRef = React.createRef<FormInstance>();
  editFormRef = React.createRef<FormInstance>();
  settingBusinessKey = React.createRef<FormInstance>();

 // 导出
 exportTwo=(record)=>{
  console.log(record);
  this.setState({ exportTwoVisable: true, currentEditRowData: record });
}
// 下载 json
handleDwnloadJSON=()=>{
  let jsonData = this.state.currentEditRowData
outPutModel({
  modelId: jsonData.id,
  modelTypeId:"00",
  outputType: '01',
}).then((res) => {
  console.log(res);
  let result=res.body
  let filename = jsonData.name;
  let contentType = 'application/json;charset=utf-8';
  if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    let blob = new Blob(
      [decodeURIComponent(encodeURI(JSON.stringify(result)))],
      { type: contentType },
    );
    navigator.msSaveOrOpenBlob(blob, filename);
  } else {
    let a = document.createElement('a');
    a.download = filename;
    a.href =
      'data:' +
      contentType +
      ',' +
      encodeURIComponent(JSON.stringify(result));
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
});
}
// 下载 sql
handleDownloadSql = () => {
  let jsonData = this.state.currentEditRowData
  outPutModel({
    modelId: jsonData.id,
    modelTypeId:"00",
    outputType: '02',
  }).then((res) => { 
    let sqlStatement=`${res.body?.modelDefInfo}${res.body?.modelDetailInfo}${res.body?.modelInfo}`
    sqlStatement=sqlStatement.replaceAll(';',';\n')
    const filename = jsonData.name+'.sql';
     // 创建一个Blob对象，将SQL语句放入其中
  const blob = new Blob([sqlStatement], { type: 'text/plain' });

  // 创建一个下载链接
  const url = window.URL.createObjectURL(blob);

  // 创建一个虚拟的<a>元素来触发下载
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;

  // 模拟点击下载链接
  a.click();

  // 释放URL对象
  window.URL.revokeObjectURL(url);
  })
 
};
  /**
   * 获取模型的类型
   * 调用搜索函数，参数为空查询所有数据
   */
  componentDidMount() {
    getModelTypeOptions().then((res) => {
      if (res.body && res.sysHead.retCd === '000000') {
        this.setState({
          modelTypeOptions: res.body,
        });
      }
    });
    this.search();
  }

  /**
   * 技术模型参数配置
   */
  openModelConfig = (record) => {
    this.setState({ loading: true });
    listTechnologyModelInfo({
      technologyModelId: record.id,
    }).then((res) => {
      if (res.body && res.sysHead.retCd === '000000') {
        if (res?.body?.configurationKeys == null) {
          message.warning('请先在模型类型中配置插件');
          this.setState({ loading: false });
          return false;
        }
        getModelActInfo({
          id: record.id,
        }).then((_res) => {
          let modelInfoArray = [];
          if (_res.body) {
            for (let key in _res.body) {
              const modelInfoObj = {};
              modelInfoObj.name = _res.body[key];
              modelInfoObj.id = key;
              modelInfoArray.push(modelInfoObj);
            }
            this.setState({
              modelInfoArray: modelInfoArray,
              modelConfigVisable: true,
              currentModel: record,
              configurationKeys: res?.body?.configurationKeys,
              chooseBusinessModelInfoResps:
                res?.body?.chooseBusinessModelInfoResps,
            });
          }
        });
      }
      setTimeout(() => {
        this.setState({ loading: false });
      }, 200);
    });
  };

  /**
   * 关闭参数配置model
   */
  transferClose = () => {
    this.setState({ modelConfigVisable: false });
  };
  /**
   * 搜索按钮 没有搜索输入值则查询所有数据，相当于刷新
   */
  search = () => {
    this.setState({ loading: true });
    const {
      modelName: name,
      modelType: type,
    } = this.searchFormRef.current?.getFieldsValue();
    queryModelList({
      name,
      type: type === '0' ? '' : type,
      pageNum: this.state.pagination.current,
      pageSize: this.state.pagination.pageSize,
    }).then((res) => {
      // 判断返回的数据格式是否是数组
      if (res.body && res.sysHead.retCd === '000000') {
        const modelList = res.body?.list;
        const { total, pageNum: current, pageSize } = res.body;
        this.setState({
          modelList: modelList,
          pagination: {
            ...this.state.pagination,
            current,
            pageSize,
            total,
          },
        });
      }
      this.setState({ loading: false });
    });
  };

  /**
   * 重置
   */
  reset = () => {
    this.searchFormRef.current?.resetFields();
    this.search();
  };

  /**
   * 新建
   */
  openNewBuild = () => {
    this.setState({
      newBuildVisible: true,
      mode: 1,
    });
  };

  /**
   * 导入JSON数据,生成模型
   * @param e
   */
  openNewFile = (e) => {
    // this.setState({ loading: true });
    const that = this;
    console.log('导入');
    let file = e.target.files[0];
    if (file.type == '') {
      message.error('请导入json格式的文件');
    }
    if (e.target.files[0] !== undefined) {
      const reader = new FileReader();
      let data = '';
      reader.readAsText(file);
      reader.onload = function (event) {
        data = event.target.result;
        let newdata = JSON.parse(data);
        importModel({
          ...newdata,
        }).then((res) => {
          if (res.sysHead.retCd == 'NGWFM-B-001008') {
            message.error('模型key已存在');
          }
          if (res.sysHead.retCd === '000000') {
            message.success('导入成功');
            that.search();
          }
          that.setState({ loading: false });
        });
      };
    }
  };

  // 关闭新建
  closeNewBuild = () => {
    this.setState({
      newBuildVisible: false,
      modelSonTypeStatus: false,
    });
  };

  // 新建模型确认
  confirmNewBuild = async (e) => {
    this.setState({ loading: true });
    try {
      const values = await this.newBuildFormRef.current.validateFields();
      const {
        modelKey: key,
        modelName: name,
        modelType,
        description,
        specificType,
      } = this.newBuildFormRef.current?.getFieldsValue();

      const record = {};
      // console.log(xmlStr)
      let newBpmnTemp = '';
      newBpmnTemp = sampleTemplate
        .replaceAll('testId', key)
        .replaceAll('testName', name);
      record.modelXml = newBpmnTemp;
      record.key = key;
      record.name = name;
      record.type = modelType;
      record.description = description;
      record.specificType = specificType;

      // 校验key值是否重复
      validateModelKey({
        key,
      }).then((res) => {
        if (res.sysHead.retCd === '000000') {
          this.closeNewBuild();
          this.openProcessDesign(record);
          console.log(record);
        }
        this.setState({ loading: false });
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 处理 模型小类树结构
  calcModelTypeOptions = (value, type) => {
    console.log(value, type);
    value.map((item, index) => {
      if (item.value == type) {
        this.setState({ modelSonTypeOptions: item.children });
        return false;
      }
      if (item.children) {
        this.calcModelTypeOptions(item.children, type);
      }
    });
  };

  // 打开编辑
  openEdit = (record) => {
    console.log(this.state.modelTypeOptions);

    this.setState({
      editVisible: true,
      currentModel: record,
      mode: 2,
    });
    setTimeout(() => {
      const fieldsValue = [this.state.currentModel].map((item) => {
        console.log(item);
        this.setState({ modelTypee: item.type }, () => {
          this.calcModelTypeOptions(
            this.state.modelTypeOptions,
            this.state.modelTypee,
          );
        });
        return {
          modelKey: item.key,
          modelName: item.name,
          modelType: item.type == null ? '根目录' : item.type,
          description: item.description,
          specificType: item.specificType,
        };
      })[0];

      // this.state.modelTypeOptions[0].children.map((item)=>{
      //   if (this.state.modelTypee === item.title) {
      //     this.setState({modelSonTypeOptions: item.children})
      //   }
      // })

      this.editFormRef.current?.setFieldsValue(fieldsValue);
    }, 0);
  };

  closeEdit = () => {
    this.setState({
      editVisible: false,
      modelSonTypeStatus: false,
      loading: false,
    });
  };

  // 编辑后更新
  confirmEdit = async (e) => {
    try {
      const values = await this.editFormRef.current.validateFields();
      this.setState({ loading: true });
      const editForm = this.editFormRef.current?.getFieldsValue();
      const params = [editForm].map((item) => {
        return {
          id: this.state.currentModel.id,
          key: editForm.modelKey,
          name: editForm.modelName,
          modelType: editForm.modelType,
          description: editForm.description,
          specificType: editForm.specificType,
        };
      })[0];
      updateModel(params).then((res) => {
        if (res?.sysHead?.retCd === '000000') {
          message.success('更新成功');
          this.setState({ loading: false });
        } else {
          this.setState({ loading: false });
        }
        this.search();
        this.closeEdit();
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 流程设计
  openProcessDesign = (record, sign) => {
    this.setState({
      processDesignVisible: true,
      currentModel: record,
    });
  };

  // 关闭流程设计
  closeProcessDesign = () => {
    this.setState({
      processDesignVisible: false,
    });
    this.search();
    this.setUrlParam('linting', false);
  };

  // 设置或获取url 后面的参数
  setUrlParam = (name, value) => {
    var url = new URL(window.location.href);
    if (value) {
      url.searchParams.set(name, 1);
    } else {
      url.searchParams.delete(name);
    }
    window.history.replaceState({}, null, url.href);
  };

  // 发布
  publish = (record: any) => {
    this.setState({ loading: true });
    publishModel(record).then((res) => {
      if (res?.sysHead?.retCd === '000000') {
        message.success('发布成功');
      }
      this.setState({ loading: false });
      this.search();
    });
  };

  // 版本管理
  openVersionManage = (record) => {
    this.setState({
      versionManageVisible: true,
      currentModel: record,
    });
  };

  // 关闭版本管理
  closeVersionManage = () => {
    this.setState({
      versionManageVisible: false,
    });
  };

  // 发布版本
  openPublishVersion = (record) => {
    this.setState({
      publishVersionVisible: true,
      currentModel: record,
    });
  };

  closePublishVersion = () => {
    this.setState({
      publishVersionVisible: false,
    });
  };

  // 模型预览
  openModelPreview = (record) => {
    this.setState({
      modelPreviewVisible: true,
      currentModel: record,
    });
  };

  closeModelPreview = () => {
    this.setState({
      modelPreviewVisible: false,
    });
  };

  // 删除
  deleteModel = (record: any) => {
    this.setState({ loading: true });
    deleteModel(record.id).then((res) => {
      if (res?.sysHead?.retCd === '000000') {
        message.success('删除成功');
        this.search();
      }
      this.setState({ loading: false });
    });
  };

  formatModelType = (dataSource, targetValue) => {
    if (targetValue) {
      return dataSource.map((item) => {
        if (item.value === targetValue) {
          modelType = item.title;
        } else {
          if (item.children) {
            this.formatModelType(item.children, targetValue);
          }
        }
        return modelType;
      });
    }
  };

  // 导出 新建利用Blob对象
  export = (e) => {
    let json = e;
    checkOutModel({
      id: json.id,
    }).then((res) => {
      let filename = res.body.modelInfo.name;
      let contentType = 'application/json;charset=utf-8';
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        let blob = new Blob(
          [decodeURIComponent(encodeURI(JSON.stringify(res.body)))],
          { type: contentType },
        );
        navigator.msSaveOrOpenBlob(blob, filename);
      } else {
        let a = document.createElement('a');
        a.download = filename;
        a.href =
          'data:' +
          contentType +
          ',' +
          encodeURIComponent(JSON.stringify(res.body));
        a.target = '_blank';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    });
  };

  /**
   * 转化为业务模板
   */

  bussinessesTypeConfig = (record) => {
    this.setState({ loading: true });
    listBusinessModelType({}).then((res) => {
      console.log(res);
      this.setState({
        bussinessesType: true,
        bussinessesModelTypeList: Array.isArray(res.body) ? res.body : [],
        currentModel: record.id,
        loading: false,
      });
    });
  };

  bussinessesTypeOk = async (e) => {
    if (!this.state.selectedRowsId) {
      message.warn('请选择一个类型进行转换!');
      return false;
    }
    this.setState({ loading: true });
    try {
      const settingBusinessKey = await this.settingBusinessKey.current?.validateFields();
      transToBusinessModel({
        ...settingBusinessKey,
        baseModelId: this.state.currentModel,
        businessTypeId: this.state.selectedRowsId,
      }).then((res) => {
        console.log(res);
        if (res.sysHead.retCd == '000000') {
          this.setState({ bussinessesType: false, selectedRowsId: '' });
          message.success('转化成功');
        }
      });
      this.setState({ loading: false });
    } catch (err) {
      this.setState({ loading: false });
      console.log('请注意必输字段');
    }
  };
  closeBussinessesType = () => {
    this.setState({ bussinessesType: false });
  };

  /**
   *  显示模型小类
   */
  modelTypeSelect = (value, node) => {
    console.log(value, node);
    this.setState({
      modelSonTypeStatus: true,
      modelSonTypeOptions: node.children,
    });
    if (this.state.mode === 1) {
      this.newBuildFormRef.current.setFieldsValue({ specificType: '' });
    } else if (this.state.mode === 2) {
      this.editFormRef.current.setFieldsValue({ specificType: '' });
    } else {
      return;
    }
  };

  render() {
    const rowSelection = {
      onChange: (selectedRowKeys: React.Key[], selectedRows: DataType[]) => {
        console.log(
          `selectedRowKeys: ${selectedRowKeys}`,
          'selectedRows: ',
          selectedRows,
        );
        this.setState({ selectedRowsId: selectedRows[0].id });
      },
      getCheckboxProps: (record: DataType) => ({
        disabled: record.name === 'Disabled User', // Column configuration not to be checked
        name: record.name,
      }),
    };
    return (
      <ConfigProvider locale={zhCN}>
        <Spin spinning={this.state.loading}>
          <section>
            <Card bordered style={{ marginBottom: 8 }}>
              <Form
                ref={this.searchFormRef}
                layout="inline"
                onFinish={this.search}
                initialValues={{
                  modelName: '',
                  modelType: '',
                  modelState: '',
                }}
                style={{ marginLeft: 16 }}
              >
                <Form.Item
                  label="模型名称"
                  name="modelName"
                  style={{ marginBottom: 0 }}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  label="模型类型"
                  name="modelType"
                  style={{ marginBottom: 0 }}
                >
                  <TreeSelect
                    style={{ width: 174 }}
                    treeData={this.state.modelTypeOptions}
                    treeDefaultExpandAll
                  />
                </Form.Item>
                <Form.Item style={{ margin: 'auto 0' }}>
                  <Button
                    type="primary"
                    htmlType="submit"
                    style={{ marginRight: 8 }}
                  >
                    查询
                  </Button>
                  <Button onClick={this.reset}>重置</Button>
                </Form.Item>
              </Form>
            </Card>

            <Card
              title="模型管理"
              extra={
                <div>
                  <EditingTool onOpenFIle={this.openNewFile} />
                  <Button
                    type="primary"
                    onClick={this.openNewBuild}
                    style={{ marginLeft: 10 }}
                  >
                    新建
                  </Button>
                </div>
              }
            >
              <Table
                dataSource={this.state.modelList}
                rowKey={(record) => record.id}
                scroll={{
                  x: '130%',
                }}
                pagination={{
                  showTotal: (total) => `共 ${total} 条数据`,
                  showSizeChanger: true,
                  current: this.state.pagination.current,
                  pageSize: this.state.pagination.pageSize,
                  total: this.state.pagination.total,
                  onChange: (page, pageSize) => {
                    this.setState(
                      {
                        pagination: {
                          ...this.state.pagination,
                          current: page,
                          pageSize,
                        },
                      },
                      () => {
                        this.search();
                      },
                    );
                  },
                }}
                bordered
                columns={this.state.columns}
              ></Table>
            </Card>
          </section>

          {this.state.newBuildVisible && (
            <Form layout="horizontal" ref={this.newBuildFormRef}>
              <Modal
                title="新建"
                visible={this.state.newBuildVisible}
                okText="确认"
                cancelText="取消"
                width="30%"
                maskClosable={false}
                onOk={this.confirmNewBuild}
                onCancel={this.closeNewBuild}
              >
                <Form.Item
                  label="模型Key"
                  name="modelKey"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[
                    { required: true },
                    {
                      pattern: /^[a-zA-z][0-9A-Za-z_]+$/g,
                      message:
                        '请以英文、数字和下划线组合,不能以数字和特殊字符开头,不能含有空格，',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  label="模型名称"
                  name="modelName"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[
                    { required: true },
                    {
                      pattern: /^[^ ]{1,15}$/,
                      message: '不能为空，不能超过最大长度',
                    },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  label="模型类型"
                  name="modelType"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[{ required: true, message: '请选择' }]}
                >
                  <TreeSelect
                    treeData={this.state.modelTypeOptions}
                    treeDefaultExpandAll
                    onSelect={this.modelTypeSelect}
                  ></TreeSelect>
                </Form.Item>

                {this.state.modelSonTypeStatus && (
                  <Form.Item
                    label="模型小类"
                    name="specificType"
                    labelCol={{ span: 7 }}
                    wrapperCol={{ span: 12 }}
                    rules={[{ required: true, message: '请选择' }]}
                  >
                    <TreeSelect
                      treeData={this.state.modelSonTypeOptions}
                      treeDefaultExpandAll
                    ></TreeSelect>
                  </Form.Item>
                )}

                <Form.Item
                  label="描述"
                  name="description"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                >
                  <Input.TextArea />
                </Form.Item>
              </Modal>
            </Form>
          )}
          {this.state.editVisible && (
            <Modal
              title="编辑"
              visible={this.state.editVisible}
              okText="确认"
              cancelText="取消"
              maskClosable={false}
              onOk={this.confirmEdit}
              onCancel={this.closeEdit}
            >
              <Form layout="horizontal" ref={this.editFormRef}>
                <Form.Item
                  label="模型Key"
                  name="modelKey"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                >
                  <Input disabled />
                </Form.Item>
                <Form.Item
                  label="模型名称"
                  name="modelName"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[{ required: true, message: '不能为空' }]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  label="模型类型"
                  name="modelType"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[{ required: true, message: '不能为空' }]}
                >
                  <TreeSelect
                    // disabled
                    treeData={this.state.modelTypeOptions}
                    treeDefaultExpandAll
                    onSelect={this.modelTypeSelect}
                  ></TreeSelect>
                </Form.Item>
                <Form.Item
                  label="模型小类"
                  name="specificType"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                  rules={[{ required: true, message: '请选择' }]}
                >
                  <TreeSelect
                    treeData={this.state.modelSonTypeOptions}
                    treeDefaultExpandAll
                  ></TreeSelect>
                </Form.Item>

                <Form.Item
                  label="描述"
                  name="description"
                  labelCol={{ span: 7 }}
                  wrapperCol={{ span: 12 }}
                >
                  <Input.TextArea />
                </Form.Item>
              </Form>
            </Modal>
          )}
          {this.state.processDesignVisible && (
            <Drawer
              title="流程设计"
              placement="top"
              visible={this.state.processDesignVisible}
              onClose={this.closeProcessDesign}
              bodyStyle={{ overflow: 'inherit' }}
              headerStyle={{
                borderBottom: 'none',
                padding: '20px 24px 0 24px',
                margin: '10px 8px 0 0',
              }}
              width="100%"
              height="100%"
              footer={null}
              extra={<Button onClick={this.closeProcessDesign}>关闭</Button>}
            >
              <ModelDesigner
                closeProcessDesign={this.closeProcessDesign}
                modelData={this.state.currentModel}
              />
            </Drawer>
          )}
          {this.state.versionManageVisible && (
            <Drawer
              title="历史版本"
              placement="top"
              visible={this.state.versionManageVisible}
              onClose={this.closeVersionManage}
              width="100%"
              height="100%"
              footer={null}
              extra={<Button onClick={this.closeVersionManage}>关闭</Button>}
            >
              <VersionManage modelId={this.state.currentModel.id} />
            </Drawer>
          )}
          {this.state.publishVersionVisible && (
            <Drawer
              title="发布版本"
              placement="top"
              visible={this.state.publishVersionVisible}
              onClose={this.closePublishVersion}
              width="100%"
              height="100%"
              footer={null}
              extra={<Button onClick={this.closePublishVersion}>关闭</Button>}
            >
              <PublishVersionManage modelKey={this.state.currentModel.key} />
            </Drawer>
          )}

          {this.state.modelPreviewVisible && (
            <Drawer
              title="模型预览"
              placement="top"
              visible={this.state.modelPreviewVisible}
              onClose={this.closeModelPreview}
              width="100%"
              height="100%"
              footer={null}
              extra={<Button onClick={this.closeModelPreview}>关闭</Button>}
            >
              <ModelViewer modelId={this.state.currentModel.id} />
            </Drawer>
          )}
          {/* <ProcessViewerModel   xmlData={xmlData}></ProcessViewerModel> */}
          {this.state.bussinessesType && (
            <Modal
              title="选择转化的业务类型"
              visible={this.state.bussinessesType}
              okText="确认"
              width="60%"
              cancelText="取消"
              maskClosable={false}
              onOk={this.bussinessesTypeOk}
              onCancel={this.closeBussinessesType}
            >
              <Form ref={this.settingBusinessKey}>
                <Form.Item
                  label="业务key"
                  name="businessKey"
                  rules={[
                    { required: true },
                    {
                      pattern: /^[a-zA-z][0-9A-Za-z]+$/g,
                      message:
                        '请以英文和数字组合,不能以数字和特殊字符开头,不能含有空格',
                    },
                  ]}
                >
                  <Input style={{ width: '50%' }}></Input>
                </Form.Item>
              </Form>
              <Divider></Divider>
              <Table
                rowSelection={{
                  ...rowSelection,
                  type: 'radio',
                }}
                dataSource={this.state.bussinessesModelTypeList}
                rowKey={(record) => record.id}
                pagination={{
                  showTotal: (total) => `共 ${total} 条数据`,
                  showSizeChanger: false,
                  // current: this.state.pagination.current,
                  pageSize: 5,
                }}
                bordered
              >
                <Table.Column
                  title="编码"
                  dataIndex="code"
                  key="code"
                  align="center"
                ></Table.Column>
                <Table.Column
                  title="类型类型名称"
                  dataIndex="typeName"
                  key="typeName"
                  align="center"
                ></Table.Column>

                <Table.Column
                  title="描述"
                  dataIndex="description"
                  key="description"
                  align="center"
                ></Table.Column>
                <Table.Column
                  title="创建时间"
                  dataIndex="createTime"
                  key="createTime"
                  align="center"
                  render={(text, record, index) => {
                    return <>{Moment(text).format('yyyy-MM-DD HH:mm:ss')}</>;
                  }}
                ></Table.Column>
                <Table.Column
                  title="修改时间"
                  dataIndex="updateTime"
                  key="updateTime"
                  align="center"
                  render={(text, record, index) => {
                    return (
                      <>
                        {' '}
                        {text ? Moment(text).format('yyyy-MM-DD HH:mm:ss') : ''}
                      </>
                    );
                  }}
                ></Table.Column>
              </Table>
            </Modal>
          )}
          {this.state.modelConfigVisable && (
            <ModelConfig
              modelInfoArray={this.state.modelInfoArray}
              configurationKeys={this.state.configurationKeys}
              chooseBusinessModelInfoResps={
                this.state.chooseBusinessModelInfoResps
              }
              currentModel={this.state.currentModel}
              transferClose={this.transferClose}
            ></ModelConfig>
          )}
        </Spin>
        {
          this.state.exportTwoVisable&&(
            <Modal title={`模型名称为：${this.state.currentEditRowData?.name}(${this.state.currentEditRowData?.key})`} visible={this.state.exportTwoVisable}
             footer={null}  onCancel={()=>this.setState({exportTwoVisable:false})}>
              <FcRow>
              请选择下载格式
              </FcRow>
           <FcRow>
           <Button style={{ borderRadius: '16px !important' }} 
           className={'uploadBoxButton'} 
           onClick={this.handleDwnloadJSON}>JSON下载</Button>
             <Button className={'uploadBoxButton'} onClick={this.handleDownloadSql}>SQL下载</Button>
           </FcRow>
          </Modal>
          )
        }
      </ConfigProvider>
    );
  }
}

export default ModelManage;
