// @ts-nocheck
import React, { Component } from 'react';
import {
  FcCard as Card,
  FcMessage as message,
  FcForm as Form,
  FcModal as Modal,
  FcInput as Input,
  FcSelect as Select,
  FcRow as Row,
  FcTable as Table,
  FcRadio as Radio,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import { Scrollbars } from 'react-custom-scrollbars';
const { Option } = Select;
import { Cascader } from 'antd';
const { SHOW_CHILD } = Cascader;
import { getModelActInfo, editTechnologyModelInfo } from '../service';
// 视图
export default class BusinessConfig extends Component {
  chooseBusinessModelInfos = React.createRef();
  state = {
    dataSource: [],
    dataSourceModel: [],
    isModelId: '',
    businessViewerData: {},
    visable: true,
    chooseBusinessModelInfoRespsTemp: [],
    loading: false,
    fixedColumns: [],
  };

  /**
   * 将index传值过来的模板信息赋值给form表单
   * 请求listBusinessModelInfo接口获取裁剪的节点信息，循环数组，将每个节点加上节点id前缀
   */
  // componentDidMount() {

  // }

  /**
   * 请求getModelActInfo接口获取流程所有任务节点，进行裁剪
   * 把获取到的对象，转化为数组，[{name:'',id:''}]
   */
  componentWillMount() {
    // 获取数据
    const chooseBusinessModelInfoRespsTemp = this.props
      .chooseBusinessModelInfoResps;
    const modelInfoArray = this.props.modelInfoArray;
    // 如果是第一次配置参数，chooseBusinessModelInfoRespsTemp为空，将循环生成数据，配置节点id模型设计id
    console.log(chooseBusinessModelInfoRespsTemp);
    let newBusinessModelInfoResps = [];
    chooseBusinessModelInfoRespsTemp?.map((item, index) => {
      delete item.businessModelId;
      delete item.choose;
      item.key1 = index + '0';
      if (item.configurationInfo != '{}') {
        const configurationInfo = JSON.parse(item.configurationInfo);
        for (let key in configurationInfo) {
          item[key] = configurationInfo[key];
        }
      }
    });

    modelInfoArray?.map((item, index) => {
      let obj = {};
      obj.name = item.name;
      obj.actId = item.id;
      obj.technologyModelId = this.props.currentModel.id;
      chooseBusinessModelInfoRespsTemp.map((_item) => {
        if (item.id == _item.actId) {
          obj = _item;
          obj.name = item.name;
        }
      });
      newBusinessModelInfoResps.push(obj);
    });

    this.setState({
      chooseBusinessModelInfoRespsTemp: newBusinessModelInfoResps,
    });
    // 循环生成table的表头
    const configurationKeys = this.props.configurationKeys;
    if (configurationKeys) {
      let columns = [
        {
          title: '节点名字',
          key: 'name',
          fixed: 'left',
          dataIndex: 'name',
          width: 200,
        },
      ];
      configurationKeys.map((item, index) => {
        let temp = [
          {
            title: item.description,
            key: item.keyV,
            dataIndex: item.keyV,
            width: 200,
            render: (_, record, index) => {
              if (item.value == 'Boolean') {
                return (
                  <Radio.Group
                    defaultValue={record[item.keyV]}
                    onChange={(value) =>
                      this.onChangeBooleanOrInput(
                        value,
                        record,
                        index,
                        item.keyV,
                      )
                    }
                  >
                    <Radio value="00">是</Radio>
                    <Radio value="01">否</Radio>
                  </Radio.Group>
                );
              }
              if (item.value == 'Array') {
                return (
                  <Select
                    defaultValue={record[item.keyV]}
                    style={{ width: '100%' }}
                    onChange={(value) =>
                      this.onChangeArray(value, record, index, item.keyV)
                    }
                    dropDownAbove
                  >
                    {item.paramaterData?.map((_item) => {
                      return (
                        <Option value={_item.value}>{_item.description}</Option>
                      );
                    })}
                  </Select>
                );
              }
              if (item.value == 'Arrays') {
                return (
                  <>
                    <Cascader
                      fieldNames={{
                        label: 'description',
                        value: 'value',
                        children: 'permissionList',
                      }}
                      showCheckedStrategy={SHOW_CHILD}
                      multiple
                      onChange={(value) =>
                        this.onChangeArray(value, record, index, item.keyV)
                      }
                      maxTagCount={1}
                      options={item.paramaterData}
                      placeholder="Please select"
                      displayRender={(label) => label.join('/')}
                      defaultValue={record[item.keyV]}
                    />
                  </>
                );
              }
              if (item.value == 'Object' || item.value == 'String') {
                return (
                  <Input
                    defaultValue={record[item.keyV]}
                    style={{ width: '100%' }}
                    onChange={(value) =>
                      this.onChangeBooleanOrInput(
                        value,
                        record,
                        index,
                        item.keyV,
                      )
                    }
                  ></Input>
                );
              }
            },
          },
        ];
        columns = columns.concat(temp);
      });
      this.setState({ fixedColumns: columns });
    }
  }

  // 改变Boolean值
  onChangeBooleanOrInput = (value, record, index, keyV) => {
    console.log(value, record, index, keyV);
    const newData = [...this.state.chooseBusinessModelInfoRespsTemp];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord[keyV] = value.target.value;
    newData.splice(index, 1, { ...item, ...cpRecord });
    console.log('newData', newData);
    this.setState({
      chooseBusinessModelInfoRespsTemp: newData,
    });
  };
  // 改变Array值
  onChangeArray = (value, record, index, keyV) => {
    console.log(value, record, index, keyV);
    const newData = [...this.state.chooseBusinessModelInfoRespsTemp];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord[keyV] = value;
    newData.splice(index, 1, { ...item, ...cpRecord });
    console.log('newData', newData);
    this.setState({
      chooseBusinessModelInfoRespsTemp: newData,
    });
  };

  /**
   * 保存裁剪的业务节点
   * 获取到表单数据，对数据进行处理分类:按照每一列的id（节点id+）,查询对象中key中含有这个节点id+的为一类
   * 去掉节点id+
   * @param e
   */
  saveTechnologyConfig = async (e) => {
    this.setState({ loading: true });
    console.log(this.state.chooseBusinessModelInfoRespsTemp);
    const chooseBusinessModelInfoRespsTemp = this.state
      .chooseBusinessModelInfoRespsTemp;

    chooseBusinessModelInfoRespsTemp?.map((item) => {
      delete item.configurationInfo;
      delete item.name;
      delete item.id;
      let configurationInfo = {};
      for (let key in item) {
        configurationInfo[key] = item[key];
      }
      delete configurationInfo.id;
      delete configurationInfo.actId;
      delete configurationInfo.technologyModelId;
      item.configurationInfo = configurationInfo;
    });
    console.log(chooseBusinessModelInfoRespsTemp);

    editTechnologyModelInfo({
      chooseBusinessModelInfos: chooseBusinessModelInfoRespsTemp,
    }).then((res) => {
      console.log(res);
      if (res.sysHead.retCd == '000000') {
        this.setState({ visable: false });
        message.success('保存成功');
      }
      this.setState({ loading: false });
      this.props.transferClose();
    });
  };

  //  取消参数配置
  cancleTechnologyConfig = () => {
    this.setState({ visable: false });
    this.props.transferClose();
  };

  // 关闭model
  closeModelPreview = () => {
    this.props.transferCloseModelPreview();
  };

  render() {
    return (
      <Modal
        title="技术节点参数配置"
        visible={this.state.visable}
        okText="确认"
        width={(this.props.configurationKeys?.length + 2) * 200 + 78 + 'px'}
        bodyStyle={{ innerHeight: 500 }}
        cancelText="取消"
        maskClosable={false}
        onOk={this.saveTechnologyConfig}
        onCancel={this.cancleTechnologyConfig}
      >
        <Table
          rowKey={(record) => record.key1}
          columns={this.state.fixedColumns}
          dataSource={this.state.chooseBusinessModelInfoRespsTemp}
          pagination={false}
          scroll={{
            x: (this.props.configurationKeys?.length + 1) * 200 + 78,
            y: 500,
          }}
          bordered
        ></Table>
      </Modal>
    );
  }
}
