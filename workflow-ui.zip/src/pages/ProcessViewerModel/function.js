export function previewVariable(id, activityAssignee) {
  // console.log( id,activityAssignee);

  for (let key in activityAssignee) {
    if (Object.prototype.hasOwnProperty.call(activityAssignee, key)) {
      // console.log('key-value', key, activityAssignee[key]);
      // console.log(activityAssignee[key] + 'choose');
      if (key == id) {
        return activityAssignee[key];
      }
    }
  }
  return '';
}
export function findNodeStatus(id, nodeStatus) {
  for (let key in nodeStatus) {
    if (Object.prototype.hasOwnProperty.call(nodeStatus, key)) {
      if (key == id) {
        return nodeStatus[key].status;
      }
    }
  }
  return 0;
}
