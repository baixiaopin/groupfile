// @ts-nocheck
import React from 'react';
// import BpmnViewer from 'bpmn-js/lib/NavigatedViewer';
import './index.less';
import BpmnViewer from 'bpmn-js/lib/Modeler';
import Moment from 'moment';
import { previewVariable, findNodeStatus } from './function';
import { NodeHistoricRecord, getNamesByIds } from './service';
import styles from '../../components/editingTools/index.module.less'
class ProcessViewerModel extends React.Component {
  state = {
    taskList: [],
    actId: '',
    num: '',
    scale: 1, // 流程图比例
    bpmnModeler: null
  };
  componentWillMount() {
    if (this.props.isUseNodeHistoricRecord) return;
    const activityAssigneeTemp = this.props.activityAssignee;
    for (let key in activityAssigneeTemp) {
      if (Object.prototype.hasOwnProperty.call(activityAssigneeTemp, key)) {
        if (activityAssigneeTemp[key].length != 0) {
          getNamesByIds({
            ids: activityAssigneeTemp[key].toString(),
          }).then((res) => {
            if (res.body) {
              activityAssigneeTemp[key] = res.body;
            }
          });
        }
      }
    }
    this.setState({ activityAssignee: activityAssigneeTemp });
  }
  // 流程图放大缩小
  handleZoom = (radio) => {
    const newScale = !radio
      ? 1.0 // 不输入radio则还原
      : this.state.scale + radio <= 0.2 // 最小缩小倍数
        ? 0.2
        : this.state.scale + radio;

    this.state.bpmnModeler.get('canvas').zoom(newScale);
    this.setState({
      scale: newScale,
    });
  };
  componentDidMount() {
    console.log('流程查看');
    let elementId = '';
    let activityIdFlag = '';
    this.taskList = this.props.taskData;
    // console.log(this.props.taskData, '传值task');
    // 新建一个BpmnViewer对象
    let bpmnViewer = new BpmnViewer({
      container: document.getElementById('canvas'),
      additionalModules: [
        {
          move: ['value', ''],
          bendpoints: ['value', {}],
          contextPadProvider: ['value', ''],
          paletteProvider: ['value', ''],
          zoomScroll: ['value', ''],
          labelEditingProvider: ['value', ''],
        },
      ],
    });
    let _self = this;
    bpmnViewer.importXML(this.props.xmlData, function (err) {
      if (err) {
        console.log('加载失败', err);
      } else {
        let canvas = bpmnViewer.get('canvas');
        canvas.zoom('fit-viewport', 'auto');
        if (_self.props.taskData) {
          bpmnViewer._definitions.rootElements[0].flowElements.forEach((n) => {
            // overlays.container='';
            if (n.$type === 'bpmn:UserTask') {
              // 添加悬浮框,节点显示历史
              let eventBus = bpmnViewer.get('eventBus');
              let overlays = bpmnViewer.get('overlays');
              let claear;
              eventBus.on('element.hover', (e) => {
                //  console.log( e.element.type);
                if (e.element.type === 'bpmn:Process') {
                  claear = setTimeout(() => {
                    overlays.clear();
                  }, 200);
                } else {
                  clearTimeout(claear);
                }
                if (e.element.type == 'bpmn:UserTask') {
                  // 防止重复发启请求
                  if (elementId != e.element.id) {
                    elementId = e.element.id;
                    // 异步清空elementId
                    setTimeout(() => {
                      elementId = '';
                    });

                    if (_self.props.isUseNodeHistoricRecord) {
                    } else {
                      NodeHistoricRecord({
                        processInstanceId: _self.props.processInstanceId,
                        actId: e.element.id,
                      }).then((res) => {
                        let nodeHistory = res.body ? res.body.list : [];
                        // console.log(res);
                        let nodeChird = `<div>`;
                        //  替换年月日
                        const reg = /(\w*)年(.*)月(.*)日(.*)/g;
                        //  取括号里的内容
                        const reg1 = /\"(.*)\"/;
                        for (let i = 0; i < nodeHistory.length; i++) {
                          nodeChird +=
                            '<div class=marginBottomOverly>' +
                            '<span class=spanOverly>' +
                            Moment(nodeHistory[i].operTime).format(
                              'yyyy-MM-DD HH:mm:ss',
                            ) +
                            '</span><sapn class=spanInleBlock>' +
                            ' ' +
                            (nodeHistory[i].remark
                              ? ''
                              : nodeHistory[i].operUser) +
                            ' ' +
                            (nodeHistory[i].remark
                              ? ''
                              : nodeHistory[i].operType) +
                            (nodeHistory[i].operType == '驳回'
                              ? nodeHistory[i].operUser + ' '
                              : '') +
                            nodeHistory[i].remark +
                            '</span></div>';
                        }
                        // 拼接table结束标识
                        nodeChird += '</div>';
                        const overlayHtml = `<div class='nodeDetail'>
                      <h4>节点审批详情 </h4>
                      <h5>${e.element.businessObject.extensionElements !=
                            undefined &&
                            e.element.businessObject.extensionElements.values[1] &&
                            e.element.businessObject.extensionElements.values[1]
                              .id == 'taskName'
                            ? '临时任务添加人：' +
                            e.element.businessObject.extensionElements.values[0]
                              .variable
                            : ''
                          } </h5>
                          <table style='width:318px' border='1'>
                      <tr > 
                      <th class='nodeIdStyle'> 节点id</td> 
                      <th class='nodeStyle'>节点名</td>
                      <th class='nodeStyle'>处理人</td>
                     </tr> 
         
                     <tr> 
                     <td class='nodeStyle'>
                     ${e.element.id}
                     </td> 
                     <td class='nodeStyle'>
                     ${e.element.businessObject.extensionElements !=
                            undefined &&
                            e.element.businessObject.extensionElements.values
                              .length > 1 &&
                            e.element.businessObject.extensionElements.values[1]
                              .id == 'taskName'
                            ? e.element.businessObject.extensionElements.values[1]
                              .variable
                            : e.element.businessObject.name
                          }
                     </td> 
                     <td class='nodePeopleStyle'>
                    ${previewVariable(
                            e.element.id,
                            _self.state.activityAssignee,
                          )}             
                      </td> 
                     </tr>        
                      </table> 
                        <h4 class='nodeHistory'>${nodeHistory.length > 0 ? '节点操作历史:' : ''
                          }</h4>   
                        ${nodeHistory.length > 0 ? nodeChird : ''} 
                          </div>`;

                        overlays.clear();
                        overlays.add(e.element.id, {
                          zIndex: 12,
                          position: { top: -5, left: e.element.width + 10 },
                          html: overlayHtml,
                        });
                      });
                    }
                  }
                }
              });

              eventBus.on('element.click', (e) => {
                if (activityIdFlag != e.element.id) {
                  activityIdFlag = e.element.id;
                  const obj = {};
                  obj.activityId = e.element.id;
                  obj.activityName = previewVariable(
                    e.element.id,
                    _self.props.activityAssignee,
                  );
                  obj.activityIdType = e.element.businessObject.name;
                  obj.nodeStatus = findNodeStatus(
                    e.element.id,
                    _self.props.taskData,
                  );
                  // 点击事件
                  if (e.element.type != 'bpmn:Process') {
                    _self.props.activityNodeInfo
                      ? _self.props.activityNodeInfo(obj)
                      : '';
                  }
                }
              });
              eventBus.on('element.out', (e) => {
                overlays.clear();
              });

              // hasOwnProperty判断对象中是否有对象名n.id
              let completeTask = _self.props.taskData.hasOwnProperty(n.id);
              if (completeTask && _self.props.taskData[n.id].status == '1') {
                canvas.addMarker(n.id, 'highlight-todo');
              }
              if (completeTask && _self.props.taskData[n.id].status == '2') {
                canvas.addMarker(
                  n.id,
                  _self.props.taskData[n.id].numOfExecution == '1'
                    ? 'highlight'
                    : String(
                      'highlight' + _self.props.taskData[n.id].numOfExecution,
                    ),
                );
              }
              // 异常节点
              if (completeTask && _self.props.taskData[n.id].status == '3') {
                canvas.addMarker(n.id, 'highlightAbnormal');
              }
            }
            if (n.$type === 'bpmn:StartEvent') {
              canvas.addMarker(n.id, 'highlight');
            }
            if (n.$type === 'bpmn:ExclusiveGateway') {
              // let completeTask = _self.props.taskData.find(
              //   (m) => m.id === n.id,
              // );
              let completeTask = _self.props.taskData.hasOwnProperty(n.id);
              if (completeTask) {
                canvas.addMarker(n.id, 'highlight');
                return;
              }
            }
            if (n.$type === 'bpmn:ParallelGateway') {
              // let completeTask = _self.props.taskData.find(
              //   (m) => m.id === n.id,
              // );
              let completeTask = _self.props.taskData.hasOwnProperty(n.id);
              if (completeTask) {
                canvas.addMarker(n.id, 'highlight');
                return;
              }
            }
            if (n.$type === 'bpmn:InclusiveGateway') {
              // let completeTask = _self.props.taskData.find(
              //   (m) => m.id === n.id,
              // );
              let completeTask = _self.props.taskData.hasOwnProperty(n.id);
              if (completeTask) {
                canvas.addMarker(n.id, 'highlight');
                return;
              }
            }
            if (n.$type === 'bpmn:SequenceFlow') {
              // let completeTask = _self.props.taskData.find(
              //   (m) => m.id === n.id,
              // );
              let completeTask = _self.props.taskData.hasOwnProperty(n.id);
              if (completeTask) {
                canvas.addMarker(n.id, 'highlight');
                return;
              }
            }
            if (n.$type === 'bpmn:ServiceTask') {
              let completeTask = _self.props.taskData.hasOwnProperty(n.id);
              if (completeTask) {
                canvas.addMarker(n.id, 'highlight');
                return;
              }
            }
            if (n.$type === 'bpmn:EndEvent') {
              let completeTask = _self.props.taskData.hasOwnProperty(n.id);
              if (completeTask) {
                canvas.addMarker(n.id, 'highlight');
                return;
              }
            }
          });
        }
      }
    });
    this.setState({ bpmnModeler: bpmnViewer })
  }
  render() {
    return (
      <div className="containers boxx">
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-around',
            placeItems: 'baseline',
            position: 'relative'
          }}
        >
          <div className="box"
            style={{
              display: 'flex',
              justifyContent: 'center',
              margin: 2,
              position: 'absolute'
            }}>
            <div>
              <span style={{ fontWeight: 'bold' }}>图例:</span>
            </div>

            <div
              className="box1"
              className="highlight"
              style={{ display: 'flex', lineHeight: '22px' }}
            >
              <div className="box1-2 highlight"></div>
              <div>
                <span>进行中</span>
              </div>
            </div>

            <div className="box1" style={{ display: 'flex' }}>
              <div className="box1-1"></div>
              <div>
                <span>已完成</span>
              </div>
            </div>

            <div className="box1" style={{ display: 'flex', lineHeight: '22px' }}>
              <div className="box1-3"></div>
              <div>
                <span>未完成</span>
              </div>
            </div>

            {this.props?.isEffectNode && (
              <div
                className="box1"
                style={{ display: 'flex', lineHeight: '22px' }}
              >
                <div className="box1-4"></div>
                <div>
                  <span>异常</span>
                </div>
              </div>
            )}

            {!this.props?.isShowGradientEffect && (
              <div className="box1" style={{ display: 'flex' }}>
                <div className="box1-1-1"></div>
                <div>
                  <span>多次执行节点，颜色逐渐加深</span>
                </div>
              </div>
            )}
          </div>
          <div style={{
            position: 'absolute',
            right: 0,
            zIndex:'100'
          }}>
            <li className={styles.control}>
              <button type="button" title="放大" onClick={() => this.handleZoom(0.1)}>
                <i className={styles.zoomIn}>
                  <span>放大</span>
                </i>
              </button>
            </li>
            <li className={`${styles.control} `}>
              <button type="button" title="缩小" onClick={() => this.handleZoom(-0.1)}>
                <i className={styles.zoomOut}>
                  <span>缩小</span>
                </i>
              </button>
            </li>
            <li className={styles.control}>
              <button type="button" title="重置大小" onClick={() => this.handleZoom()}>
                <i className={styles.zoom}>
                  <span>重置大小</span>
                </i>
              </button>
            </li>
          </div>
        </div>
        <div id="canvas" className="canvas"></div>
      </div>
    );
  }
}

export default ProcessViewerModel;
