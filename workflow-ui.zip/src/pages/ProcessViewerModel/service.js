import request from '../../utils/request';

export function NodeHistoricRecord(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'NodeHistoricRecord',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

export function processInstancePreviewVariable(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ProcessInstanceSVC',
        stdIntfcInd: 'processInstancePreviewVariable',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 查询回显
export function getNamesByIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'getNamesByIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
