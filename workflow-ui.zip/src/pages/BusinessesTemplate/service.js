import request from '../../utils/request';

// 查询回显
export function getInfosByIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'getInfosByIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 查询业务模型
 * @param {*} data
 */
export function queryBusinessModels(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelSVC',
        stdIntfcInd: 'queryBusinessModels',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 查询业务模型视图
 * @param {*} data
 */
export function getBusinessModelXML(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelSVC',
        stdIntfcInd: 'getBusinessModelXML',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 删除业务模型
 * @param {*} data
 */
export function deleteBusinessModel(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelSVC',
        stdIntfcInd: 'deleteBusinessModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 查询业务类型配置
 * @param {*} data
 */
export function getBusinessModelTypeById(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'getBusinessModelTypeById',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 获取业务流程节点
 * @param {*} data
 */
export function getModelActInfo(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'getModelActInfo',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 保存业务类型配置
 * @param {*} data
 */
export function editBusinessModelInfo(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ChooseBusinessModelInfoSVC',
        stdIntfcInd: 'editBusinessModelInfo',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 获取业务配置信息
 * @param {*} data
 */
export function listBusinessModelInfo(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ChooseBusinessModelInfoSVC',
        stdIntfcInd: 'listBusinessModelInfo',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

/**
 * 查询业务类型列表
 */
export function listBusinessModelType() {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelTypeSVC',
        stdIntfcInd: 'listBusinessModelType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {},
    },
  });
}
// 校验key值是否重复
export function validateModelKey(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'validateModelKey',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}
// 节点配置事实流程图
export function getNewBpmnModelByReassemble(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelSVC',
        stdIntfcInd: 'getNewBpmnModelByReassemble',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}

// 保存流程设计
export function saveBusinessModel(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelSVC',
        stdIntfcInd: 'saveBusinessModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}

// 更新流程设计
export function updateBusinessModelXML(newBuildForm) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'BusinessModelSVC',
        stdIntfcInd: 'updateBusinessModelXML',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: newBuildForm,
    },
  });
}

//  获取流程图xml
export function getModelXML(id) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'getModelXML',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        id,
      },
    },
  });
}
// 更新流程图
export function saveModelXML(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelResSVC',
        stdIntfcInd: 'saveModelXML',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: data,
    },
  });
}

// 发布模型，也叫部署模型
export function publishModel(record) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: 'ModelDefinitionSVC',
        stdIntfcInd: 'deployModel',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: 'NGWKFL',
      },
      localHead: {},
      body: {
        modelId: record.modelId,
      },
    },
  });
}
