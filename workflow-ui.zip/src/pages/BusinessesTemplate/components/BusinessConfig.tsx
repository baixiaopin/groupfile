// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcCard as Card,
  FcMessage as message,
  FcForm as Form,
  FcModal as Modal,
  FcInput as Input,
  FcSelect as Select,
  FcRow as Row,
  FcCol as Col,
  FcRadio as Radio,
  FcEmpty as Empty,
  FcTabs as Tabs,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import { Cascader } from 'antd';
const { SHOW_CHILD } = Cascader;
const { Option } = Select;
import {
  editBusinessModelInfo,
  getModelActInfo,
  listBusinessModelInfo,
  getNewBpmnModelByReassemble,
  saveModelXML,
} from '../service';
import SheetStyle from './index.less';
import BusinessViewer from '../../ModelViewerNoReq/index';
// 视图
export default class BusinessConfig extends Component {
  businessFormInfoRef = React.createRef();
  chooseBusinessModelInfos = React.createRef();
  state = {
    dataSource: [],
    dataSourceModel: [],
    isModelId: '',
    openProcessViewer: false,
    businessViewerData: {},
    loading: true,
  };

  /**
   * 将index传值过来的模板信息赋值给form表单
   * 请求listBusinessModelInfo接口获取裁剪的节点信息，循环数组，将每个节点加上节点id前缀
   */
  componentDidMount() {
    console.log(this.props.currentBuesiness.configurationKeys);

    this.businessFormInfoRef.current.setFieldsValue({
      ...this.props.currentRows,
    });
    listBusinessModelInfo({
      businessModelId: this.props.currentRows.id,
    }).then((res) => {
      if (res.body?.length > 0) {
        let serviceData = {};
        let activityId = [];
        res.body.map((item) => {
          if (item.choose == 0) {
            activityId.push(item.actId);
          }
          serviceData[item.actId + '$+$choose'] =
            item.choose == 0 ? '00' : '01';
          const configurationInfo = JSON.parse(item.configurationInfo);
          for (let key in configurationInfo) {
            serviceData[item.actId + '$+$' + key] = configurationInfo[key];
          }
        });
        this.chooseBusinessModelInfos.current.setFieldsValue({
          ...serviceData,
        });
        this.setState({ loading: false });
      } else {
        getModelActInfo({
          id: this.props.currentRows.baseModelId,
        }).then((res) => {
          let modelInfoArray = [];
          if (res.body) {
            for (let key in res.body) {
              const modelInfoObj = {};
              modelInfoObj.id = key;
              modelInfoArray.push(modelInfoObj);
            }
          }
          let serviceData = {};
          modelInfoArray.map((item) => {
            serviceData[item.id + '$+$choose'] = '00';
          });
          this.chooseBusinessModelInfos.current.setFieldsValue({
            ...serviceData,
          });
          this.setState({ loading: false });
        });
      }
    });
  }

  /**
   * 请求getModelActInfo接口获取流程所有任务节点，进行裁剪
   * 把获取到的对象，转化为数组，[{name:'',id:''}]
   */
  componentWillMount() {
    console.log(this.props.currentBuesiness);
    console.log(this.props.currentRows);
    this.getModelActInfo();
  }
  getModelActInfo = () => {
    getModelActInfo({
      id: this.props.currentRows.baseModelId,
    }).then((res) => {
      console.log(res);
      let modelInfoArray = [];
      if (res.body) {
        for (let key in res.body) {
          const modelInfoObj = {};
          modelInfoObj.name = res.body[key];
          modelInfoObj.id = key;
          modelInfoArray.push(modelInfoObj);
        }
      }
      console.log(modelInfoArray);
      this.setState({ dataSourceModel: modelInfoArray });
    });
  };

  /**
   * 保存裁剪的业务节点
   * 获取到表单数据，对数据进行处理分类:按照每一列的id（节点id+）,查询对象中key中含有这个节点id+的为一类
   * 去掉节点id+
   * @param e
   */
  saveBuessinessConfig = async (e) => {
    const { dataSourceModel } = this.state;
    // try{
    // const values = await this.chooseBusinessModelInfos.current.validateFields();
    const res = this.chooseNodeHaveOne('e');
    if (!res) {
      return false;
    }
    const settings = this.chooseBusinessModelInfos.current?.getFieldsValue();
    dataSourceModel.map((activityId) => {
      settings[activityId.id + '$+$actId'] = activityId.id;
    });
    // 将同一类型的id的放在一个对象里面
    const resultList = dataSourceModel.map((item) => {
      const arr = {};
      for (let key in settings) {
        if (settings.hasOwnProperty(key)) {
          if (key.split('$+$')[0] == item.id) {
            arr[key] = settings[key];
          }
        }
      }
      return arr;
    });
    console.log(resultList);
    dataSourceModel.map((activityId) => {
      resultList.map((item) => {
        for (let key in item) {
          if (Object.prototype.hasOwnProperty.call(item, key)) {
            item[key.replaceAll(key.split('$+$')[0] + '$+$', '')] = item[key];
            item['businessModelId'] = this.props.currentRows.id;
            if (key.includes(activityId.id + '$+$')) {
              delete item[key];
            }
          }
        }
      });
    });
    // 处理数组 选中的00为00，没有选中的为01
    //  创建一个obj对象，放业务属性,然后删除choose、actId、businessModelId三个字段
    resultList.map((item) => {
      const obj = {};
      for (let key in item) {
        if (Object.prototype.hasOwnProperty.call(item, key)) {
          if (key == 'choose') {
            item[key] = item[key] == '00' ? '00' : '01';
          }
          obj[key] = item[key];
          delete obj.choose;
          delete obj.actId;
          delete obj.businessModelId;

          if (key != 'choose' && key != 'actId' && key != 'businessModelId') {
            delete item[key];
          }
        }
      }
      item.configurationInfo = obj;
    });
    console.log(resultList);
    editBusinessModelInfo({
      chooseBusinessModelInfos: resultList,
    }).then((res) => {
      if (res.sysHead.retCd == '000000') {
        this.chooseNode('save');
      }
    });
    // }catch (errorInof) {
    //   message.error('请注意必输字段');
    // }
  };
  //
  onChange = (time, timeString) => {
    console.log(time, timeString);
  };

  /**
   *
   * @returns 动态计算栅格布局中的col的宽度
   */
  calcSpan = () => {
    return Math.floor(
      24 / (this.props.currentBuesiness.configurationKeys?.length + 2),
    );
  };
  // 详情

  // 关闭model
  closeModelPreview = () => {
    this.props.transferCloseModelPreview();
  };

  /**
   * 选择节点
   * @returns
   */
  chooseNode = (e) => {
    const settings = this.chooseBusinessModelInfos.current?.getFieldsValue();
    let chooseActivityId = [];
    for (let key in settings) {
      if (Object.prototype.hasOwnProperty.call(settings, key)) {
        if (settings[key] == '00' && key.includes('$+$choose')) {
          chooseActivityId.push(key.replaceAll('$+$choose', ''));
        }
      }
    }
    getNewBpmnModelByReassemble({
      businessModelId: this.props.currentRows.id,
      modelKey: this.props.currentRows.modelKey,
      activityIds: chooseActivityId,
      name: this.props.currentRows.name,
    }).then((res) => {
      this.setState({
        businessViewerData: res?.body[0],
        openProcessViewer: e == 'save' ? false : true,
      });
      if (e == 'save') {
        saveModelXML({
          id: this.props.currentRows.modelId,
          bpmnModelXml: res.body[0],
        }).then((res) => {
          message.success('保存成功');
          this.props.transferCloseModelPreview();
        });
      }
    });
  };

  /**
   *
   * @returns 流程预览
   */
  openProcessViewer = () => {
    this.chooseNode('e');
  };
  viewHandleOk = () => {
    this.setState({ openProcessViewer: false });
  };

  chooseNodeHaveOne = (e) => {
    const settings = this.chooseBusinessModelInfos.current?.getFieldsValue();
    let chooseActivityId = [];
    for (let key in settings) {
      if (Object.prototype.hasOwnProperty.call(settings, key)) {
        if (settings[key] == '00' && key.includes('$+$choose')) {
          chooseActivityId.push(key.replaceAll('$+$choose', ''));
        }
      }
    }
    console.log(chooseActivityId);
    if (chooseActivityId.length == 0) {
      message.warn('请至少选中一个节点!');
      return false;
    } else {
      return true;
    }
  };
  render() {
    let colStyles = {
      padding: '13px',
    };
    let fdnav = {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 997,
      width: '100%',
      height: '60px',
      fontSize: '14px',
      color: '#fff',
      background: '#3296fa',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
    };
    let fdnavLeft = {
      display: 'flex',
      alignItems: 'center',
    };
    let fdnavBack = {
      display: 'inline-block',
      width: '60px',
      height: '60px',
      fontSize: '22px',
      borderRight: '1px solid #1583f2',
      textAlign: 'center',
      cursor: 'pointer',
    };
    let busAnticonLeft = {
      fontSize: '30px',
      lineHeight: '56px',
    };
    let fdnavTitle = {
      width: 0,
      flex: 1,
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      textOverflow: 'ellipsis',
      padding: '0 15px',
      fontSize: '16px',
      width: '180px',
    };
    let fdnavRight = {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      textAlign: 'right',
    };
    let buttonPublish = {
      minWidth: '80px',
      marginLeft: '4px',
      marginRight: '15px',
      color: '#3296fa',
      borderColor: '#fff',
    };

    let busAnticonLeft1 = {
      width: '24px',
      height: '24px',
      display: 'block',
      margin: 'auto',
      marginTop: '20px',
      background:
        "url('data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjBweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMTYgMTciIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+5p+l55yL5pu05aSaPC90aXRsZT4KICAgIDxnIGlkPSLpobXpnaItMSIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9IuWbvuagh+W6k+S6kembhi0xIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTEzLjAwMDAwMCwgLTI5MC4wMDAwMDApIiBzdHJva2U9IiNGRkZGRkYiIHN0cm9rZS13aWR0aD0iMS42Ij4KICAgICAgICAgICAgPGcgaWQ9Iuafpeeci+abtOWkmi0t55m96ImyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMjEuMDAwMDAwLCAyOTguNTAwMDAwKSByb3RhdGUoLTE4MC4wMDAwMDApIHRyYW5zbGF0ZSgtMTIxLjAwMDAwMCwgLTI5OC41MDAwMDApIHRyYW5zbGF0ZSgxMTMuMDAwMDAwLCAyOTAuNTAwMDAwKSI+CiAgICAgICAgICAgICAgICA8ZyBpZD0i5pu05aSaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1LjAwMDAwMCwgMi4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICA8cG9seWxpbmUgaWQ9Iui3r+W+hCIgcG9pbnRzPSIwIDAgNi41NjQgNS45NzEgMCAxMS45NDIiPjwvcG9seWxpbmU+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==') 0 0 no-repeat",
    };
    return (
      <Spin spinning={this.state.loading}>
        <div style={fdnav}>
          <div style={fdnavLeft}>
            <div
              style={fdnavBack}
              className={SheetStyle.fdnavback}
              onClick={this.closeModelPreview}
            >
              <i style={busAnticonLeft}>
                <span style={busAnticonLeft1}></span>
              </i>
            </div>
            <div style={fdnavTitle}>审批流程参数设置</div>
          </div>
          <div style={fdnavRight}>
            {/* <button type="button"  ><span>发 布</span></button> */}
            <Button style={buttonPublish} onClick={this.saveBuessinessConfig}>
              <span>保存</span>
            </Button>
          </div>
        </div>
        <Card bordered={false}>
          <Form
            ref={this.businessFormInfoRef}
            name="basic"
            initialValues={{ remember: true }}
            labelAlign="left"
          >
            <Row>
              <Col span={8}>
                <Form.Item name="name" label="模板名称">
                  <Input
                    bordered={false}
                    readOnly
                    style={{ height: '35px' }}
                  ></Input>
                </Form.Item>
              </Col>

              <Col span={8}>
                <Form.Item name="modelKey" label="模板Key">
                  <Input
                    bordered={false}
                    readOnly
                    style={{ height: '35px' }}
                  ></Input>
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item name="version" label="版本">
                  <Input
                    bordered={false}
                    readOnly
                    style={{ height: '35px' }}
                  ></Input>
                </Form.Item>
              </Col>
            </Row>

            <Row>
              <Col span={8}>
                <Form.Item name="createdBy" label="创建人">
                  <Input
                    bordered={false}
                    readOnly
                    style={{ height: '35px' }}
                  ></Input>
                </Form.Item>
              </Col>

              <Col span={8}>
                <Form.Item name="lastUpdatedBy" label="最后修改人">
                  <Input
                    bordered={false}
                    readOnly
                    style={{ height: '35px' }}
                  ></Input>
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item name="description" label="描述">
                  <Input
                    bordered={false}
                    readOnly
                    style={{ height: '35px' }}
                  ></Input>
                </Form.Item>
              </Col>
            </Row>
          </Form>
          <br />

          <Card
            title="节点参数配置"
            style={{ fontSize: 14 }}
            extra={
              <Button type="primary" onClick={this.openProcessViewer}>
                流程预览
              </Button>
            }
          >
            {!this.props.currentBuesiness.configurationKeys && (
              <>
                <Empty />
                <Form
                  ref={this.chooseBusinessModelInfos}
                  layout="vertical"
                  name="validate_other"
                  initialValues={{ remember: true }}
                  onFinish={this.saveBuessinessConfig}
                ></Form>
              </>
            )}
            {this.props.currentBuesiness.configurationKeys && (
              <Form
                ref={this.chooseBusinessModelInfos}
                layout="vertical"
                name="validate_other"
                initialValues={{ remember: true }}
                onFinish={this.saveBuessinessConfig}
              >
                <Card
                  bordered
                  bodyStyle={{
                    padding: '0px',
                    backgroundColor: '#f5f5f5',
                  }}
                >
                  <Row justify="center" style={{ fontWeight: 'bold' }}>
                    <Col style={colStyles} span={this.calcSpan()}>
                      {'节点名字'}
                    </Col>
                    <Col style={colStyles} span={this.calcSpan()}>
                      {'是否选择'}
                    </Col>
                    {this.props.currentBuesiness.configurationKeys?.map(
                      (item) => {
                        return (
                          <Col style={colStyles} span={this.calcSpan()}>
                            {item.description}
                          </Col>
                        );
                      },
                    )}
                  </Row>
                </Card>
                {/*  */}

                {this.state.dataSourceModel.map((item, index) => {
                  return (
                    <Card bordered bodyStyle={{ padding: '1px' }}>
                      <Row justify="center">
                        <Form.Item noStyle>
                          <Col style={colStyles} span={this.calcSpan()}>
                            <span>{item.name}</span>
                          </Col>
                        </Form.Item>

                        <Col
                          style={{
                            padding: '5px 14px',
                            lineHeight: '40px',
                          }}
                          span={this.calcSpan()}
                          key={index}
                        >
                          <Form.Item
                            name={item.id + '$+$choose'}
                            noStyle
                            hasFeedback
                            rules={[{ required: true, message: '请输入' }]}
                          >
                            <Radio.Group onChange={this.chooseNodeHaveOne}>
                              <Radio value="00">是</Radio>
                              <Radio value="01">否</Radio>
                            </Radio.Group>
                            {/* <Checkbox.Group style={{ width: '100%' }} >
  
                              <Checkbox value="00"></Checkbox>
                            </Checkbox.Group> */}
                          </Form.Item>
                        </Col>

                        {this.props.currentBuesiness.configurationKeys?.map(
                          (itemTr) => {
                            if (itemTr.value == 'String') {
                              return (
                                <>
                                  <Col
                                    span={this.calcSpan()}
                                    style={{
                                      padding: '5px 14px',
                                      lineHeight: '40px',
                                    }}
                                  >
                                    <Form.Item
                                      name={item.id + '$+$' + itemTr.keyV}
                                      noStyle
                                      hasFeedback
                                      rules={[
                                        { required: true, message: '请输入' },
                                      ]}
                                    >
                                      <Input></Input>
                                    </Form.Item>
                                  </Col>
                                </>
                              );
                            }

                            if (itemTr.value == 'Object') {
                              return (
                                <>
                                  <Col
                                    span={this.calcSpan()}
                                    style={{
                                      padding: '5px 14px',
                                      lineHeight: '40px',
                                    }}
                                  >
                                    <Form.Item
                                      name={item.id + '$+$' + itemTr.keyV}
                                      noStyle
                                      hasFeedback
                                      rules={[
                                        { required: true, message: '请输入' },
                                      ]}
                                    >
                                      <Input></Input>
                                    </Form.Item>
                                  </Col>
                                </>
                              );
                            }

                            if (itemTr.value == 'Array') {
                              return (
                                <>
                                  <Col
                                    span={this.calcSpan()}
                                    style={{
                                      padding: '5px 14px',
                                      lineHeight: '40px',
                                    }}
                                  >
                                    <Form.Item
                                      name={item.id + '$+$' + itemTr.keyV}
                                      noStyle
                                      hasFeedback
                                      rules={[
                                        { required: true, message: '请选择' },
                                      ]}
                                    >
                                      <Select style={{ width: '100%' }}>
                                        {itemTr.paramaterData?.map((_item) => {
                                          return (
                                            <Option value={_item.value}>
                                              {_item.description}
                                            </Option>
                                          );
                                        })}
                                      </Select>
                                    </Form.Item>
                                  </Col>
                                </>
                              );
                            }
                            if (itemTr.value == 'Arrays') {
                              return (
                                <>
                                  <Col
                                    span={this.calcSpan()}
                                    style={{
                                      padding: '5px 14px',
                                      lineHeight: '40px',
                                    }}
                                  >
                                    <Form.Item
                                      name={item.id + '$+$' + itemTr.keyV}
                                      noStyle
                                      hasFeedback
                                      rules={[
                                        { required: true, message: '请选择' },
                                      ]}
                                    >
                                      <Cascader
                                        style={{ width: '100%' }}
                                        fieldNames={{
                                          label: 'description',
                                          value: 'value',
                                          children: 'permissionList',
                                        }}
                                        showCheckedStrategy={SHOW_CHILD}
                                        multiple
                                        options={itemTr.paramaterData}
                                        placeholder="Please select"
                                        displayRender={(label) =>
                                          label.join('/')
                                        }
                                        defaultValue={[
                                          ['pc端value', '可查看value'],
                                          ['移动端value', '可查看value'],
                                        ]}
                                      />
                                    </Form.Item>
                                  </Col>
                                </>
                              );
                            }

                            if (itemTr.value == 'Boolean') {
                              return (
                                <>
                                  <Col
                                    span={this.calcSpan()}
                                    style={{
                                      padding: '5px 14px',
                                      lineHeight: '40px',
                                    }}
                                  >
                                    <Form.Item
                                      name={item.id + '$+$' + itemTr.keyV}
                                      noStyle
                                      hasFeedback
                                      rules={[
                                        { required: true, message: '请输入' },
                                      ]}
                                    >
                                      <Radio.Group>
                                        <Radio value="00">是</Radio>
                                        <Radio value="01">否</Radio>
                                      </Radio.Group>
                                    </Form.Item>
                                  </Col>
                                </>
                              );
                            }
                          },
                        )}
                      </Row>
                    </Card>
                  );
                })}
              </Form>
            )}
          </Card>
        </Card>
        {this.state.openProcessViewer && (
          <Modal
            visible={this.state.openProcessViewer}
            title="流程预览"
            width="65%"
            centered
            // height="50%"
            onOk={this.viewHandleOk}
            onCancel={this.viewHandleOk}
            bodyStyle={{ padding: 0, margin: 0 }}
            footer={null}
          >
            <Card>
              <BusinessViewer
                bpmnModelXml={this.state.businessViewerData}
                // taskData={this.state.taskData}
              ></BusinessViewer>
            </Card>
          </Modal>
        )}
      </Spin>
    );
  }
}
