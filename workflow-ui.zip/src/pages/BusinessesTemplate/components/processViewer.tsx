// @ts-nocheck
import React, { Component } from 'react';
import ModelViewer from '../../ModelViewer';
import SheetStyle from './index.less';
export default class index extends Component {
  // 关闭model
  closeModelPreview = () => {
    this.props.transferCloseModelPreview();
  };
  render() {
    let fdnav = {
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 997,
      width: '100%',
      height: '60px',
      fontSize: '14px',
      color: '#fff',
      background: '#3296fa',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
    };
    let fdnavLeft = {
      display: 'flex',
      alignItems: 'center',
    };
    let fdnavBack = {
      display: 'inline-block',
      width: '60px',
      height: '60px',
      fontSize: '22px',
      borderRight: '1px solid #1583f2',
      textAlign: 'center',
      cursor: 'pointer',
    };
    let busAnticonLeft = {
      fontSize: '30px',
      lineHeight: '56px',
    };
    let fdnavTitle = {
      width: 0,
      flex: 1,
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      textOverflow: 'ellipsis',
      padding: '0 15px',
      fontSize: '16px',
      width: '180px',
    };
    let fdnavRight = {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      textAlign: 'right',
    };
    let busAnticonLeft1 = {
      width: '24px',
      height: '24px',
      display: 'block',
      margin: 'auto',
      marginTop: '20px',
      background:
        "url('data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjBweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMTYgMTciIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+5p+l55yL5pu05aSaPC90aXRsZT4KICAgIDxnIGlkPSLpobXpnaItMSIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9IuWbvuagh+W6k+S6kembhi0xIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTEzLjAwMDAwMCwgLTI5MC4wMDAwMDApIiBzdHJva2U9IiNGRkZGRkYiIHN0cm9rZS13aWR0aD0iMS42Ij4KICAgICAgICAgICAgPGcgaWQ9Iuafpeeci+abtOWkmi0t55m96ImyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMjEuMDAwMDAwLCAyOTguNTAwMDAwKSByb3RhdGUoLTE4MC4wMDAwMDApIHRyYW5zbGF0ZSgtMTIxLjAwMDAwMCwgLTI5OC41MDAwMDApIHRyYW5zbGF0ZSgxMTMuMDAwMDAwLCAyOTAuNTAwMDAwKSI+CiAgICAgICAgICAgICAgICA8ZyBpZD0i5pu05aSaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1LjAwMDAwMCwgMi4wMDAwMDApIj4KICAgICAgICAgICAgICAgICAgICA8cG9seWxpbmUgaWQ9Iui3r+W+hCIgcG9pbnRzPSIwIDAgNi41NjQgNS45NzEgMCAxMS45NDIiPjwvcG9seWxpbmU+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==') 0 0 no-repeat",
    };
    return (
      <div>
        <div style={fdnav}>
          <div style={fdnavLeft}>
            <div style={fdnavBack} onClick={this.closeModelPreview}>
              <i style={busAnticonLeft}>
                <span style={busAnticonLeft1}></span>
              </i>
            </div>
            <div style={fdnavTitle}>流程图预览</div>
          </div>
          <div style={fdnavRight}></div>
        </div>
        <ModelViewer modelId={this.props.modelId}></ModelViewer>
      </div>
    );
  }
}
