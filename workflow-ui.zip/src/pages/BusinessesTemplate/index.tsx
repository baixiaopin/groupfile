// @ts-nocheck

import {
  FcButton as Button,
  FcCard as Card,
  FcMessage as message,
  FcForm as Form,
  FcPopconfirm as Popconfirm,
  FcInput as Input,
  FcTable as Table,
  FcSelect as Select,
  FcConfigProvider as ConfigProvider,
  FcDrawer as Drawer,
  FcTag as Tag,
  FcTooltip as Tooltip,
  FcDivider as Divider,
  FcSpin as Spin,
} from '@ngfed/fc-components';
import {
  queryBusinessModels,
  deleteBusinessModel,
  getBusinessModelTypeById,
  validateModelKey,
  publishModel,
} from './service';
// import BusinessViewer from '../BusinessViewer';
import React from 'react';
import BusinessConfig from './components/BusinessConfig';
import Moment from 'moment';
import zhCN from 'antd/lib/locale/zh_CN';
import ModelViewer from './components/processViewer';

class BusinessesTemplate extends React.Component {
  searchFormRef = React.createRef<FormInstance>();
  newBuildFormRef = React.createRef<FormInstance>();
  state = {
    loading: false,
    pagination: {
      current: 1,
      pageSize: 10,
      total: 0,
    },
    currentBuesiness: {},
    currentRows: {},
    modelBusinessVisible: false,
    designOrViewer: '',
    columns: [
      {
        title: '模板Key',
        dataIndex: 'modelKey',
        key: 'modelKey',

        ellipsis: {
          showTitle: false,
        },
        render: (modelKey) => (
          <Tooltip placement="top" title={modelKey}>
            {modelKey}
          </Tooltip>
        ),
      },
      {
        title: '模板名称',
        dataIndex: 'name',
        key: 'name',

        ellipsis: {
          showTitle: false,
        },
        render: (name) => (
          <Tooltip placement="topLeft" title={name}>
            {name}
          </Tooltip>
        ),
      },
      {
        title: '模板类型名称',
        dataIndex: 'typeName',
        key: 'typeName',

        ellipsis: {
          showTitle: false,
        },
        render: (typeName) => (
          <Tooltip
            placement="topLeft"
            title={typeName == null ? '根目录' : typeName}
          >
            {typeName == null ? '大信贷审批流' : typeName}
          </Tooltip>
        ),
      },
      {
        title: '创建时间',
        dataIndex: 'created',
        key: 'created',

        ellipsis: {
          showTitle: false,
        },
        sorter: {
          compare: (a, b) => a.created - b.created,
          multiple: 3,
        },
        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      {
        title: '修改时间',
        dataIndex: 'lastUpdated',
        key: 'lastUpdated',

        ellipsis: {
          showTitle: false,
        },

        render: (text, record, index) => {
          return text ? (
            <Tooltip
              placement="topLeft"
              title={Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            >
              {Moment(text).format('yyyy-MM-DD HH:mm:ss')}
            </Tooltip>
          ) : (
            ''
          );
        },
      },
      // {
      //   title: '状态',
      //   dataIndex: 'status',
      //   key: 'status',
      //   ellipsis: {
      //     showTitle: true,
      //   },
      //   render: (status) => {
      //     if (status == '00') {
      //       return (
      //         <Tag color="geekblue" key={status}>
      //           {'已发布'}
      //         </Tag>
      //       );
      //     } else {
      //       return (
      //         <Tag color="geekblue" key={status}>
      //           {'未发布'}
      //         </Tag>
      //       );
      //     }
      //   },
      // },
      {
        title: '创建人',
        dataIndex: 'createdBy',
        key: 'createdBy',

        ellipsis: {
          showTitle: true,
        },
        render: (createdBy) => (
          <Tooltip placement="topLeft" title={createdBy}>
            {createdBy}
          </Tooltip>
        ),
      },
      {
        title: '修改人',
        dataIndex: 'lastUpdatedBy',
        key: 'lastUpdatedBy',

        ellipsis: {
          showTitle: false,
        },
        render: (lastUpdatedBy) => (
          <Tooltip placement="topLeft" title={lastUpdatedBy}>
            {lastUpdatedBy}
          </Tooltip>
        ),
      },
      {
        title: '模板描述',
        dataIndex: 'description',
        key: 'description',

        ellipsis: {
          showTitle: false,
        },
        render: (description) => (
          <Tooltip placement="topLeft" title={description}>
            {description}
          </Tooltip>
        ),
      },
      {
        title: '操作',
        dataIndex: 'operation',
        key: 'operation',

        fixed: 'right',
        width: 270,
        render: (text, record, index) => (
          <>
            <a
              onClick={(e) => {
                e.preventDefault();
                this.editBusinessConfig(record);
              }}
            >
              节点配置
            </a>
            {/* <Divider
              type="vertical"
              style={{ margin: '0 6px', display: 'inline-block' }}
            />
            <a
              onClick={(e) => {
                e.preventDefault();
                this.modelProcessDesign(record, 'design');
              }}
              disabled={record.modelId === record.baseModelId ? false : true}
            >
              流程设计
            </a> */}
            <Divider type="vertical" />
            <Popconfirm
              title="确认发布？"
              onConfirm={() => this.publish(record)}
              okText="是"
              cancelText="否"
            >
              <a>发布</a>
            </Popconfirm>
            <Divider type="vertical" />
            <a
              onClick={(e) => {
                e.preventDefault();
                this.modelProcessDesign(record, 'viewer');
              }}
            >
              流程预览
            </a>
            <Divider type="vertical" />
            <Popconfirm
              title="是否删除？"
              onConfirm={() => this.deleteModel(record)}
              okText="是"
              cancelText="否"
            >
              <a>删除</a>
            </Popconfirm>
          </>
        ),
      },
    ],
    businessesTemplate: [],
    // 业务类型
    listBusinessModelType: [],
    processDesignVisible: false,
    currentInfo: '',
    businessViewerXml: '',
  };

  componentDidMount() {
    this.refesh();
  }

  /**
   * 获取模型数据
   */
  refesh = () => {
    const searchForm = this.searchFormRef.current?.getFieldsValue();
    this.setState({ loading: true });
    queryBusinessModels({
      ...searchForm,
      pageNum: this.state.pagination.current,
      pageSize: this.state.pagination.pageSize,
    }).then((res) => {
      if (res.body && res?.sysHead?.retCd == '000000') {
        const { total, pageNum: current, pageSize } = res.body;
        this.setState({
          loading: false,
          businessesTemplate: res.body?.list,
          pagination: {
            ...this.state.pagination,
            current,
            pageSize,
            total,
          },
        });
      }
    });
  };

  /**
   * 发布
   * @param e
   */
  publish = (record: any) => {
    publishModel(record).then((res) => {
      if (res?.sysHead?.retCd === '000000') {
        message.success('发布成功');
      }
      this.refesh();
    });
  };

  // 业务配置编辑
  editBusinessConfig = (e) => {
    getBusinessModelTypeById({
      id: e.businessTypeId,
    }).then((res) => {
      if (res.body) {
        this.setState(
          {
            currentRows: e,

            currentBuesiness: res.body,
          },
          () => {
            this.setState({ modelBusinessVisible: true });
          },
        );
      }
    });
  };
  closeModelPreview = () => {
    this.setState({ modelBusinessVisible: false });
  };

  // 流程预览
  modelProcessDesign = (record, designOrViewer) => {
    this.setState({
      designOrViewer: designOrViewer,
      processDesignVisible: true,
      currentInfo: record,
    });
    // modelProcessDesign({
    //   id: record.modelId,
    // }).then((res) => {
    //   if (res.sysHead.retCd == '000000') {
    //     this.setState({
    //       businessViewerXml: res.body,
    //       designOrViewer: designOrViewer,
    //       processDesignVisible: true,
    //       currentInfo: record,
    //     });
    //   }
    // });
  };
  closeModelViewerPreview = () => {
    this.setState({ processDesignVisible: false, businessViewerXml: '' });
  };

  /**
   * 查询按钮 支持迷糊查询
   */
  clickSearchBtn = () => {
    const searchForm = this.searchFormRef.current?.getFieldsValue();
    this.setState({ loading: true });
    queryBusinessModels({
      ...searchForm,
    }).then((res) => {
      if (res.body) {
        const { total, pageNum: current, pageSize } = res.body;
        this.setState({
          loading: false,
          businessesTemplate: res.body?.list,
          pagination: {
            ...this.state.pagination,
            current,
            pageSize,
            total,
          },
        });
      }
    });
  };

  /**
   * 重置
   */
  reset = () => {
    this.searchFormRef.current.resetFields();
    this.refesh();
  };

  deleteModel = (record: any) => {
    this.setState({ loading: true });
    deleteBusinessModel({
      id: record.id,
    }).then((res) => {
      this.setState({ loading: false });
      if (res.sysHead.retCd == '000000') {
        message.success('删除成功');
        this.refesh();
      }
    });
  };

  // 新建,获取业务类型,进行业务类型id的选择
  // openNewBuild = () => {
  //   listBusinessModelType({}).then((res) => {
  //     if (res.body) {
  //       this.setState({
  //         listBusinessModelType: res.body,
  //         newBuildVisible: true,
  //       });
  //     }
  //   });
  // };

  // closeNewBuild = () => {
  //   this.setState({
  //     newBuildVisible: false,
  //   });
  // };
  // 确定新建
  confirmNewBuild = async (e) => {
    try {
      const newBuildForm = await this.newBuildFormRef.current?.validateFields();
      const key = this.newBuildFormRef.current.getFieldsValue().modelKey;
      validateModelKey({
        key: key,
      }).then((res) => {
        if (res.sysHead.retCd === '000000') {
          this.closeNewBuild();
          this.openProcessDesign(newBuildForm);
        }
      });
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 流程设计
  openProcessDesign = (newBuildForm, sign) => {
    this.setState({
      processDesignVisible: true,
      currentInfo: newBuildForm,
      designOrViewer: 'design',
    });
  };

  /**
   *
   * @returns 子组件传值关闭 流程设计
   */
  closeModelar = () => {
    this.closeModelViewerPreview();
    this.refesh();
  };
  render() {
    return (
      <ConfigProvider locale={zhCN} className="BusinessViewer">
        <Spin spinning={this.state.loading}>
          <Card style={{ marginBottom: 8 }}>
            <Form
              ref={this.searchFormRef}
              layout="inline"
              initialValues={{
                modelName: '',
                modelType: '',
                modelState: '',
              }}
              style={{ marginLeft: 16 }}
              onFinish={this.clickSearchBtn}
            >
              <Form.Item
                label="模版名称"
                name="name"
                style={{ marginBottom: 0 }}
              >
                <Input />
              </Form.Item>
              <Form.Item style={{ margin: 'auto 0' }}>
                <Button
                  type="primary"
                  htmlType="submit"
                  style={{ marginRight: 8 }}
                >
                  查询
                </Button>
                <Button onClick={this.reset}>重置</Button>
              </Form.Item>
            </Form>
          </Card>
          <Card title="流程模板">
            <Table
              dataSource={this.state.businessesTemplate}
              rowKey={(record) => record.id}
              scroll={{
                x: '130%',
              }}
              pagination={{
                showTotal: (total) => `共 ${total} 条数据`,
                showSizeChanger: true,
                current: this.state.pagination.current,
                pageSize: this.state.pagination.pageSize,
                total: this.state.pagination.total,
                onChange: (page, pageSize) => {
                  this.setState(
                    {
                      pagination: {
                        ...this.state.pagination,
                        current: page,
                        pageSize,
                      },
                    },
                    () => {
                      this.refesh();
                    },
                  );
                },
              }}
              bordered
              columns={this.state.columns}
            ></Table>
          </Card>
        </Spin>
        {this.state.modelBusinessVisible && (
          <Drawer
            title="审批流程参数设置"
            placement="top"
            visible={this.state.modelBusinessVisible}
            onClose={this.closeModelPreview}
            width="100%"
            height="100%"
            footer={null}
          >
            <BusinessConfig
              key={'config'}
              currentRows={this.state.currentRows}
              currentBuesiness={this.state.currentBuesiness}
              transferCloseModelPreview={this.closeModelPreview}
            ></BusinessConfig>
          </Drawer>
        )}

        {this.state.processDesignVisible && (
          <Drawer
            title="流程图预览"
            visible={this.state.processDesignVisible}
            onClose={this.closeModelViewerPreview}
            width="100%"
            height="100%"
            bodyStyle={{ padding: 0 }}
            footer={
              <div
                style={{
                  textAlign: 'right',
                }}
              ></div>
            }
          >
            {/* {this.state.designOrViewer == 'design' && (
              <BusinessesModelar
                currentInfo={this.state.currentInfo}
                closeModelar={this.closeModelar}
                businessViewerXml={this.state.businessViewerXml}
              ></BusinessesModelar>
            )} */}
            <ModelViewer
              transferCloseModelPreview={() => {
                this.setState({ processDesignVisible: false });
              }}
              modelId={this.state.currentInfo.modelId}
            ></ModelViewer>
            {/* {this.state.designOrViewer == 'viewer' && (
              <BusinessViewer
                businessViewerXml={this.state.businessViewerXml}
                closeModelar={this.closeModelar}
              ></BusinessViewer>
            )} */}
          </Drawer>
        )}
        {/* 
        {this.state.newBuildVisible && (
          <Modal
            title="新建"
            visible={this.state.newBuildVisible}
            okText="确认"
            cancelText="取消"
            maskClosable={false}
            onOk={this.confirmNewBuild}
            onCancel={this.closeNewBuild}
          >
            <Form ref={this.newBuildFormRef} layout="horizontal">
              <Form.Item
                label="模板key"
                name="modelKey"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  { required: true, message: '请输入' },
                  {
                    pattern: /^[a-zA-z][0-9A-Za-z]+$/g,
                    message:
                      '请以英文和数字组合,不能以数字和特殊字符开头,不能含有空格',
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="模版名称"
                name="name"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  { required: true, message: '请输入' },
                  {
                    pattern: /^[^ ]{1,15}$/,
                    message: '不能超过最大长度',
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label="业务模型类型"
                name="businessTypeId"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
                rules={[{ required: true, message: '请选择' }]}
              >
                <Select
                  showSearch
                  placeholder="请选择"
                  optionFilterProp="children"
                  filterOption={(input, option) =>
                    option.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {this.state.listBusinessModelType &&
                    this.state.listBusinessModelType.map((item, index) => {
                      return (
                        <Select.Option key={index} value={item.id}>
                          {item.typeName}
                        </Select.Option>
                      );
                    })}
                </Select>
              </Form.Item>
              <Form.Item
                label="描述"
                name="description"
                labelCol={{ span: 7 }}
                wrapperCol={{ span: 12 }}
              >
                <Input.TextArea />
              </Form.Item>
            </Form>
          </Modal>
        )} */}
      </ConfigProvider>
    );
  }
}

export default BusinessesTemplate;
