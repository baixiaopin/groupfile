// import {
//   FcMessage as message,
//   FcNotification as notification,
// } from '@ngfed/fc-components';
// import { extend } from 'umi-request';
// import { formatDate, formatTime, randomString } from './index';
// import deviceInfo from './device-info';
// const codeMessage = {
//   200: '成功返回请求的数据。',
//   201: '新建或修改数据成功。',
//   202: '一个请求已经进入后台排队（异步任务）。',
//   204: '删除数据成功。',
//   400: '发出的请求有错误，服务器没有进行新建或修改数据的操作。',
//   401: '用户没有权限（令牌、用户名、密码错误）。',
//   403: '用户得到授权，但是访问是被禁止的。',
//   404: '发出的请求针对的是不存在的记录，服务器没有进行操作。',
//   406: '请求的格式不可得。',
//   410: '请求的资源被永久删除，且不会再得到的。',
//   422: '当创建一个对象时，发生一个验证错误。',
//   500: '服务器发生错误，请检查服务器。',
//   502: '网关错误。',
//   503: '服务不可用，服务器暂时过载或维护。',
//   504: '网关超时。',
// };

// const errorHandler = (error) => {
//   if (!error.response) {
//     return Promise.reject('网络异常');
//   }

//   const response = error;
//   if (response && response.status) {
//     const errorText = codeMessage[response.status] || response.statusText;
//     const { status, url } = response;
//     notification.error({
//       message: `请求错误 ${status}: ${url}`,
//       description: errorText,
//     });
//     return Promise.reject(error.message);
//   }
// };

// const workflowRequest = extend({
//   errorHandler,
// });

// workflowRequest.interceptors.request.use(
//   (url, options) => {
//     // 通用配置修改
//     options.method = 'POST';
//     let token = localStorage.getItem('token');
//     options.headers.token = token && token;
//     let userInfo = JSON.parse(localStorage.getItem('userInformation'));
//     if (!userInfo) {
//       // throw new Error('用户信息获取失败，可能原因：未登录基座。');
//     }
//     const localHead = {
//       // 分页信息
//       pgngObjInf: {
//         // 页码
//         crnPgCnt: options?.data?.localHead?.pgngObjInf?.crnPgCnt,
//         // 页数
//         pgRcrdNum: options?.data?.localHead?.pgngObjInf?.pgRcrdNum,
//       },
//       // 用户信息
//       usrBscInf: {
//         // 员工所属机构名称
//         blngInstNm: userInfo?.sysOrg?.orgName,
//         // 员工所属机构号
//         emplyAsgnInstNo: userInfo?.sysOrg?.orgCode,
//         // 员工名称
//         emplyNm: userInfo?.sysUser?.empName,
//         // 员工编号（即：工号）
//         emplyNo: userInfo?.sysUser?.empNo,
//         // 岗位编号
//         postCd: userInfo?.sysPost.map((item) => {
//           return item?.positionId;
//         }),
//         // 岗位名称
//         postNm: userInfo?.sysPost.map((item) => {
//           return item?.positionName;
//         }),
//         // 角色编号
//         roleCd: userInfo?.sysRole.map((item) => {
//           return item?.roleId;
//         }),
//         // 角色名称
//         roleNm: userInfo?.sysRole.map((item) => {
//           return item?.roleName;
//         }),
//       },
//       // 设备指纹信息
//       eqmtFpInf: deviceInfo,
//     };
//     // // 开发环境
//     if (process.env.WORKFLOW_UI.MODEL === 'development') {
//       let data = {
//         sysHead: {
//           // 走网关必备四要素
//           stdSvcInd: options.data.sysHead.stdSvcInd,
//           stdIntfcInd: options.data.sysHead.stdIntfcInd,
//           stdIntfcVerNo: '1.0.0',
//           srcConsmSysInd: 'NGWKFL',
//           //
//           chnlNo: '030220',
//           consmMainSrlNo: randomString(32),
//           consmPltfmDt: formatDate(new Date()),
//           consmSubSrlNo: '001',
//           consmSvcInd: '',
//           consmSysInd: 'NGWKFL',
//           consmTxnCd: '001',
//           consmTxnMchnDt: formatDate(new Date()),
//           consmTxnMchnTm: formatTime(),
//           dcnNo: '',
//           glbRqsTmstmp: new Date().getTime().toString(),
//           glbSrlNo: randomString(32),
//           idcNo: '',
//           instNo: '136061',
//           lglPrsnCd: '01',
//           mACVal: '',
//           ovtmTmNum: '60',
//           srcConsmTmlNo: '',
//           srcConsmTmlType: '',
//           sysRsrvCharStrg: '',
//           sysRsrvFlgStrg: '',
//           txnChrctrstcType: '0',
//           txnDstcNo: '',
//           usrNo: '01ZK011',
//         },
//         localHead,
//         body: { ...options.data.body },
//       };
//       url = process.env.WORKFLOW_UI_REQUEST_BASE_URL;
//       (options.headers.aacCode = header_parameter_variable_aacCode),
//         (options.headers.cadCode = header_parameter_variable_cadCode);
//       if (
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_UserManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_RoleManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_OrgManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_PositionManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_CommonManagementSVC
//       ) {
//         // 设置组织架构树的srcConsmSysInd
//         data.sysHead.srcConsmSysInd = orgHeader_parameter_variable_appCode;
//         // url替换为组织架构树的url
//         url = process.env.ORGANIZATIONAL_STRUCTURE_TREE_REQUEST_BASE_URL;
//         // 设置组织架构树请求头的aaccode和cadCode
//         (options.headers.aacCode = orgheader_parameter_variable_aacCode),
//           (options.headers.cadCode = orgheader_parameter_variable_cadCode);
//         switch (options.data.sysHead.stdSvcInd) {
//           // 组织架构树
//           case process.env.ORGANIZATIONAL_UserManagementSVC:
//             url = url + `/user/${options.data.sysHead.stdIntfcInd}`;
//             break;
//           case process.env.ORGANIZATIONAL_RoleManagementSVC:
//             url = url + `/role/${options.data.sysHead.stdIntfcInd}`;
//             break;
//           case process.env.ORGANIZATIONAL_OrgManagementSVC:
//             url = url + `/org/${options.data.sysHead.stdIntfcInd}`;
//             break;
//           case process.env.ORGANIZATIONAL_PositionManagementSVC:
//             url = url + `/position/${options.data.sysHead.stdIntfcInd}`;
//             break;
//           case process.env.ORGANIZATIONAL_CommonManagementSVC:
//             url = url + `/common/${options.data.sysHead.stdIntfcInd}`;
//             break;
//           default:
//             url = '未映射到有效URL';
//             break;
//         }
//       }
//       return {
//         url,
//         options: {
//           ...options,
//           data,
//         },
//       };
//     }

//     // 生产环境
//     if (process.env.WORKFLOW_UI.MODEL === 'production') {
//       let data = {
//         sysHead: {
//           // 走网关必备四要素
//           stdSvcInd: options.data.sysHead.stdSvcInd,
//           stdIntfcInd: options.data.sysHead.stdIntfcInd,
//           stdIntfcVerNo: '1.0.0',
//           // 发现该次请求是关于工作流的（根据标准服务标志），就将 srcConsmSysInd 设置为 NGWKFL（目前是）
//           srcConsmSysInd: 'NGWKFL',
//         },
//         localHead,
//         body: { ...options.data.body },
//       };
//       // 判断是否是组织架构树的请求
//       if (
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_UserManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_RoleManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_OrgManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_PositionManagementSVC ||
//         options.data.sysHead.stdSvcInd ==
//           process.env.ORGANIZATIONAL_CommonManagementSVC
//       ) {
//         // 设置组织架构树的aacCode和cadCode
//         (options.headers.aacCode = orgheader_parameter_variable_aacCode),
//           (options.headers.cadCode = orgheader_parameter_variable_cadCode);
//         data = {
//           sysHead: {
//             // 走网关必备四要素
//             stdSvcInd: options.data.sysHead.stdSvcInd,
//             stdIntfcInd: options.data.sysHead.stdIntfcInd,
//             stdIntfcVerNo: '1.0.0',
//             // 发现该次请求是关于组织架构树的（根据标准服务标志）
//             srcConsmSysInd: orgHeader_parameter_variable_appCode,
//             //
//           },
//           localHead,
//           body: { ...options.data.body },
//         };
//         url = process.env.ORGANIZATIONAL_STRUCTURE_TREE_REQUEST_BASE_URL;
//       } else {
//         url = process.env.WORKFLOW_UI_REQUEST_BASE_URL;
//         (options.headers.aacCode = header_parameter_variable_aacCode),
//           (options.headers.cadCode = header_parameter_variable_cadCode);
//         if (options.data.sysHead.flag) {
//           data = {
//             sysHead: {
//               // 走网关必备四要素
//               stdSvcInd: options.data.sysHead.stdSvcInd,
//               stdIntfcInd: options.data.sysHead.stdIntfcInd,
//               stdIntfcVerNo: options.data.sysHead.stdIntfcVerNo,
//               // 发现该次请求是关于组织架构树的（根据标准服务标志）
//               srcConsmSysInd: options.data.sysHead.srcConsmSysInd,
//               //
//             },
//             localHead,
//             body: { ...options.data.body },
//           };
//         }
//       }
//       return {
//         url,
//         options: {
//           ...options,
//           data,
//         },
//       };
//     }
//   },

//   {
//     global: false,
//   },
// );

// workflowRequest.interceptors.response.use(
//   async (res) => {
//     if (res.status !== 200) {
//       throw new Error();
//     }
//     const responseJson = await res.json();
//     if (responseJson.sysHead.retCd === '000000') {
//       return responseJson;
//     } else {
//       notification.error({
//         message: responseJson.sysHead.retInf
//           ? responseJson.sysHead.retInf
//           : responseJson.sysHead.retCd,
//       });
//       return responseJson;
//     }
//   },
//   {
//     global: false,
//   },
// );

// export default workflowRequest;
import { request } from 'ngfe-request';
export default request;
