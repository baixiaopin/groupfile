// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcTag as Tag,
  FcCard as Card,
  FcTree as Tree,
  FcTable as Table,
  FcSelect as Select,
  FcRow as Row,
  FcCol as Col,
  FcInput,
} from '@ngfed/fc-components';
import {
  listPositionByOrgIds,
  listRoleByPostIds,
  listPosition,
  getOrgAndOrgGruopTrees,
  getListOrgTrees,
  getRoleByOrgId,
  getSelectedOrgTreeByOrgId,
} from './service';
const { Column } = Table;
const { DirectoryTree } = Tree;
// import Search from 'antd/lib/input/Search';
const { Search } = FcInput;
class postAndRoleLimit extends React.Component {
  newBuildExecutionListenersReff = React.createRef();
  monitor = React.createRef();
  state = {
    selectType: 'post',
    selectTree: '',
    delegateList: [],
    selectedRowKeys: [],
    orgTreeData: [],
    pageNum: 1,
    pageSize: '',
    total: '',
    treeData: null,
    search: '',
    // 左边选中的树
    expandedKeys: [],
    // 传值控制类型
    typeUser: true,
    typeOrg: true,
    typePost: true,
    typeRole: true,
  };
  componentDidMount() {
    if (this.props.candidateUserVarLimit) {
      const selectedRowKeys = this.props.candidateUserVarLimit.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      this.setState({
        selectedRowKeys: selectedRowKeys,
        delegateList: this.props.candidateUserVarLimit,
      });
    }

    // 判断是否级联
    // console.log('判断是否级联', this.props.isCacscade);
    if (!this.props.isCacscade) {
      if (this.props.candidateUserVarType == 'post') {
        getOrgAndOrgGruopTrees().then((res) => {
          if (res.sysHead.retCd == '000000') {
            this.setState({
              treeData: res.body,
              selectType: 'post',
              typeRole: false,
            });
          }
          listPosition({
            pageSize: 5,
            pageNum: 1,
          }).then((res) => {
            this.setState({
              orgTreeData: res.body.list,
              pageNum: res.body.current,
              pageSize: res.body.pageSize,
              total: res.body.total,
            });
          });
        });
      }
      if (this.props.candidateUserVarType == 'role') {
        getListOrgTrees().then((res) => {
          if (res.sysHead.retCd == '000000') {
            this.setState({
              treeData: res.body,
              selectType: 'role',
              typePost: false,
            });
          }
        });
        getRoleByOrgId({
          pageSize: 5,
          pageNum: 1,
        }).then((res) => {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        });
      }
      return false;
    }
    // console.log('级联');
    if (this.props.candidateUserVarType == 'post') {
      this.setState({ selectType: 'post', typeRole: false });
      const orgIds = this.props.orgIds.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      getSelectedOrgTreeByOrgId({
        pageSize: 5,
        pageNum: 1,
        listOrgId: orgIds,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            treeData: res.body,
            typeRole: false,
          });
        }
      });

      listPositionByOrgIds({
        pageSize: 5,
        pageNum: 1,
        orgId: orgIds.toString(),
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.props.candidateUserVarType == 'role') {
      this.setState({ selectType: 'role', typePost: false });
      const postIds = this.props.postIds.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      listRoleByPostIds({
        pageSize: 5,
        pageNum: 1,
        postId: postIds.toString(),
      }).then((res) => {
        const thePrevious = this.props.thePrevious;
        if (thePrevious) {
          thePrevious.map((item) => {
            item.title = item.name;
            item.key = item.id;
          });
        }
        this.setState({
          treeData: this.props.thePrevious,
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
  }
  onExpand = (expandedKeys) => {
    this.setState({ expandedKeys: expandedKeys }, () => {});
  };
  onSelect = (keys, event) => {
    console.log(keys, event);
    this.setState({ selectTree: keys[0] });
    // 选角色树 listRoleByPostIds
    if (this.state.selectType == 'role') {
      if (this.props.isCacscade) {
        listRoleByPostIds({
          pageSize: 5,
          pageNum: 1,
          postId: keys[0],
        }).then((res) => {
          if (res.sysHead.retCd == '000000') {
            this.setState({
              orgTreeData: res.body.list,
              pageNum: res.body.current,
              pageSize: res.body.pageSize,
              total: res.body.total,
            });
          }
        });
        return false;
      }
      getRoleByOrgId({
        pageSize: 5,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
    // 选岗位树
    if (this.state.selectType == 'post') {
      listPosition({
        pageSize: 5,
        pageNum: 1,
        orgId: keys[0],
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        }
      });
    }
  };
  // 分页设置
  paginationChange = (page, pageSize) => {
    // console.log('分页');
    let reg = new RegExp('[\\u4E00-\\u9FFF]+');
    const orgIds = this.props.orgIds.map((obj) => {
      return obj.id ? obj.id : obj;
    });
    if (this.state.selectType == 'post') {
      if (this.props.isCacscade) {
        listPositionByOrgIds({
          pageSize: pageSize,
          pageNum: page,
          orgId: this.state.selectTree
            ? this.state.selectTree
            : orgIds.toString(),
          positionId:
            reg.test(this.state.search) == true ? '' : this.state.search,
          positionName:
            reg.test(this.state.search) == true ? this.state.search : '',
        }).then((res) => {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        });
        return false;
      }
      listPosition({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        positionId:
          reg.test(this.state.search) == true ? '' : this.state.search,
        positionName:
          reg.test(this.state.search) == true ? this.state.search : '',
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    if (this.state.selectType == 'role') {
      //     this.setState({orgTreeData:[]})
      const postIds = this.props.postIds.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      if (this.props.isCacscade) {
        listRoleByPostIds({
          pageSize: pageSize,
          pageNum: page,
          postId: this.state.selectTree
            ? this.state.selectTree
            : postIds.toString(),
        }).then((res) => {
          this.setState({
            orgTreeData: res.body?.list,
            pageNum: res.body?.current,
            pageSize: res.body?.pageSize,
            total: res.body?.total,
          });
        });
        return false;
      }
      getRoleByOrgId({
        pageSize: pageSize,
        pageNum: page,
        orgId: this.state.selectTree,
        roleId: reg.test(this.state.search) == true ? '' : this.state.search,
        roleName: reg.test(this.state.search) == true ? this.state.search : '',
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
  };
  deletById = (value) => {
    const arrDelegateLis = this.state.delegateList.filter(
      (item) => item.id !== value,
    );
    const arrSelectedRowKeys = this.state.selectedRowKeys.filter(
      (item) => item !== value,
    );
    this.setState(
      {
        delegateList: arrDelegateLis,
        selectedRowKeys: arrSelectedRowKeys,
      },
      () => {
        this.props.transferPostOrRole(this.state.delegateList);
      },
    );
  };
  deletAll = () => {
    this.setState({ delegateList: [], selectedRowKeys: [] }, () => {
      this.props.transferPostOrRole(this.state.delegateList);
    });
  };
  // 查询组织架构树
  onChangeStruct = (e) => {
    this.setState({ searchStruct: e.value });
  };
  onSearch = (value) => {
    this.setState({ search: value.target.value });
    const orgIds = this.props.orgIds.map((obj) => {
      return obj.id ? obj.id : obj;
    });
    const search = value.target.value;
    let reg = new RegExp('[\\u4E00-\\u9FFF]+');
    //  如果选中的是用户和候选人
    //如果选中的岗位
    if (this.state.selectType == 'post') {
      if (this.props.isCacscade) {
        listPositionByOrgIds({
          pageSize: 5,
          pageNum: 1,
          orgId: orgIds.toString(),
          positionId: reg.test(search) == true ? '' : search,
          positionName: reg.test(search) == true ? search : '',
        }).then((res) => {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        });
        return false;
      }
      listPosition({
        pageSize: 5,
        pageNum: 1,
        orgId: this.state.selectTree,
        positionId: reg.test(search) == true ? '' : search,
        positionName: reg.test(search) == true ? search : '',
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
    // 选角色树
    if (this.state.selectType == 'role') {
      const postIds = this.props.postIds.map((obj) => {
        return obj.id ? obj.id : obj;
      });
      if (this.props.isCacscade) {
        listRoleByPostIds({
          pageSize: 5,
          pageNum: 1,
          postId: postIds.toString(),
          roleId: reg.test(search) == true ? '' : search,
          roleName: reg.test(search) == true ? search : '',
        }).then((res) => {
          this.setState({
            orgTreeData: res.body.list,
            pageNum: res.body.current,
            pageSize: res.body.pageSize,
            total: res.body.total,
          });
        });
        return false;
      }
      getRoleByOrgId({
        pageSize: 5,
        pageNum: 1,
        orgId: this.state.selectTree,
        roleId: reg.test(search) == true ? '' : search,
        roleName: reg.test(search) == true ? search : '',
      }).then((res) => {
        this.setState({
          orgTreeData: res.body.list,
          pageNum: res.body.current,
          pageSize: res.body.pageSize,
          total: res.body.total,
        });
      });
    }
  };

  render() {
    const {
      selectedRowKeys,
      delegateList,
      selectType,
      orgTreeData,
    } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        let delegateListTemp = delegateList.concat(selectedRows);
        // 数组去重 选中的角色
        let obj = {};
        let peon = delegateListTemp.reduce((cur, next) => {
          obj[selectType == 'roleTemp' ? next.roleId : next.id]
            ? ''
            : (obj[selectType == 'roleTemp' ? next.roleId : next.id] =
                true && cur.push(next));
          return cur;
        }, []);
        let selectedRowKeyss = selectedRowKeys.concat(
          this.state.selectedRowKeys,
        );
        const unique = [...new Set(selectedRowKeyss)];

        orgTreeData.map((item) => {
          if (selectedRowKeys.indexOf(item.id) == -1) {
            unique.map((_item, index) => {
              if (_item == item.id) {
                unique.splice(index, 1);
              }
            });
            peon.map((_item, index) => {
              if (_item.id == item.id) {
                peon.splice(index, 1);
              }
            });
          }
        });
        this.props.transferPostOrRole(peon, selectType);
        this.setState({
          selectedRowKeys: unique,
          delegateList: peon,
        });
      },
    };

    return (
      <div>
        <Row>
          <Col span={6}>
            <Card bordered bodyStyle={{ padding: '12px 24px' }}>
              <div>
                {this.state.treeData ? (
                  <DirectoryTree
                    onSelect={this.onSelect}
                    onExpand={this.onExpand}
                    defaultExpandParent
                    height={412}
                    defaultExpandAll={this.props.isCacscade}
                    defaultExpandedKeys={['99999']}
                    // expandedKeys={this.state.expandedKeys}
                    treeData={this.state.treeData}
                  />
                ) : (
                  '加载中...'
                )}
              </div>
            </Card>
          </Col>
          <Col span={13}>
            <Card bordered bodyStyle={{ padding: '12px 24px' }}>
              <Search
                placeholder="请输入查询"
                allowClear
                // enterButton="查询"
                onChange={this.onSearch}
                value={this.state.search}
                onBlur={() => {
                  // console.log('清空');
                  this.setState({ searchStruct: '' });
                }}
                style={{ marginBottom: 8 }}
              ></Search>
              <Table
                rowSelection={{
                  ...rowSelection,
                }}
                dataSource={this.state.orgTreeData}
                bordered={false}
                tableLayout="fixed"
                pagination={{
                  showSizeChanger: true,
                  current: this.state.pageNum,
                  pageSize: this.state.pageSize,
                  total: this.state.total,
                  onChange: (page, pageSize) => {
                    this.paginationChange(page, pageSize);
                  },
                }}
                rowKey={(record) =>
                  this.state.selectType == 'role' ? record.roleId : record.id
                }
              >
                <Column
                  title={
                    this.state.selectType == 'user' ||
                    this.state.selectType == 'candidateUsers'
                      ? '用户名'
                      : this.state.selectType == 'post'
                      ? '岗位名称'
                      : '角色名'
                  }
                  dataIndex={
                    this.state.selectType == 'user' ||
                    this.state.selectType == 'candidateUsers'
                      ? 'empName'
                      : this.state.selectType == 'post'
                      ? 'positionName'
                      : 'roleName'
                  }
                  key="name"
                ></Column>
                <Column
                  title={
                    this.state.selectType == 'user' ||
                    this.state.selectType == 'candidateUsers'
                      ? '工号'
                      : this.state.selectType == 'post'
                      ? '岗位Id'
                      : '角色Id'
                  }
                  dataIndex={
                    this.state.selectType == 'user' ||
                    this.state.selectType == 'candidateUsers'
                      ? 'code'
                      : this.state.selectType == 'post'
                      ? 'id'
                      : 'roleId'
                  }
                  key="code"
                ></Column>
              </Table>
            </Card>
          </Col>
          <Col span={5}>
            <Card bordered bodyStyle={{ padding: '12px 24px' }}>
              {this.state.delegateList &&
                this.state.delegateList.map((item, index) => {
                  return (
                    <Tag
                      style={{
                        lineHeight: '35px',
                        marginBottom: '8px',
                        height: '40px',
                      }}
                      color="blue"
                      closable
                      onClose={(e) => {
                        e.preventDefault();
                        this.deletById(item.id);
                      }}
                      key={index}
                    >
                      {item.name}
                    </Tag>
                  );
                })}
              <br />
              {this.state.delegateList.length != 0 && (
                <Button
                  style={{ marginTop: 30 }}
                  onClick={this.deletAll}
                  type="primary"
                >
                  清空
                </Button>
              )}
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}
export default postAndRoleLimit;
