import request from '../../utils/request';

// 根据机构查岗位
export function listPositionByOrgIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'PositionManagementSVC',
        stdIntfcInd: 'listPositionByOrgIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 根据岗位查角色
export function listRoleByPostIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'RoleManagementSVC',
        stdIntfcInd: 'listRoleByPostIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 岗位table
export function listPosition(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'PositionManagementSVC',
        stdIntfcInd: 'listPosition',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 角色人员
export function getRoleByOrgId(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'RoleManagementSVC',
        stdIntfcInd: 'getRoleByOrgId',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 岗位和部门一样
export function getOrgAndOrgGruopTrees(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'OrgManagementSVC',
        stdIntfcInd: 'getOrgAndOrgGruopTrees',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 指定用户 候选人
export function getListOrgTrees(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'OrgManagementSVC',
        stdIntfcInd: 'getListOrgTrees',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 级联 根据选中的机构回显为树结构
export function getSelectedOrgTreeByOrgId(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'OrgManagementSVC',
        stdIntfcInd: 'getSelectedOrgTreeByOrgId',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
