import React, { Component } from 'react';
import styles from './index.module.less';

class EditingTools extends Component {
  handleOpen = () => {
    this.file.click();
  };

  render() {
    const {
      onOpenFIle,
      onZoomIn,
      onZoomOut,
      onZoomReset,
      onUndo,
      onRedo,
      onSave,
      onDownloadXml,
      onDownloadSvg,
      onPreview,
    } = this.props;
    return (
      <div className={styles.editingTools}>
        <ul className={styles.controlList}>
          <li className={`${styles.control}`}>
            <input
              ref={(file) => {
                this.file = file;
              }}
              className={styles.openFile}
              type="file"
              onChange={onOpenFIle}
            />
            <button
              type="button"
              title="打开BPMN文件"
              onClick={this.handleOpen}
            >
              <i className={styles.open}>
                <span>打开BPMN文件</span>
              </i>
            </button>
          </li>

          <li className={styles.control}>
            <button type="button" title="撤销" onClick={onUndo}>
              <i className={styles.undo}>
                <span>撤销</span>
              </i>
            </button>
          </li>
          <li className={`${styles.control} `}>
            <button type="button" title="恢复" onClick={onRedo}>
              <i className={styles.redo}>
                <span>恢复</span>
              </i>
            </button>
          </li>

          <li className={styles.control}>
            <button type="button" title="重置大小" onClick={onZoomReset}>
              <i className={styles.zoom}>
                <span>重置大小</span>
              </i>
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="放大" onClick={onZoomIn}>
              <i className={styles.zoomIn}>
                <span>放大</span>
              </i>
            </button>
          </li>
          <li className={`${styles.control} `}>
            <button type="button" title="缩小" onClick={onZoomOut}>
              <i className={styles.zoomOut}>
                <span>缩小</span>
              </i>
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="保存流程" onClick={onSave}>
              <i className={styles.save}>
                <span>保存流程</span>
              </i>
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="下载BPMN文件" onClick={onDownloadXml}>
              <i className={styles.download}>
                <span>下载BPMN文件</span>
              </i>
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="下载流程图片" onClick={onDownloadSvg}>
              <i className={styles.image}>
                <span>下载流程图片</span>
              </i>
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="图片" onClick={onPreview}>
              <i className={styles.preview}>
                <span>图片</span>
              </i>
            </button>
          </li>
        </ul>
      </div>
    );
  }
}

export default EditingTools;
