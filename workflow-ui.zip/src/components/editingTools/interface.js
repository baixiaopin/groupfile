import request from '../../utils/request';

const stdSvcInd = 'ModelTypeServiceSVC';

export function save(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd,
        stdIntfcInd: 'save',
      },
      localHead: {},
      body: data,
    },
  });
}
