import request from '../../utils/request';

// 根据机构查岗位
export function listPositionByOrgIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'PositionManagementSVC',
        stdIntfcInd: 'listPositionByOrgIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 根据岗位查角色
export function listRoleByPostIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'RoleManagementSVC',
        stdIntfcInd: 'listRoleByPostIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
