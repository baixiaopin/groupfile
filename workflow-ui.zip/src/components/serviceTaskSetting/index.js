// @ts-nocheck
import React, { Component } from 'react';
import {
  FcMessage as message,
  FcForm as Form,
  FcInput as Input,
  FcSelect as Select,
  FcRow as Row,
  FcCol as Col,
  FcModal as Modal,
} from '@ngfed/fc-components';
const { TextArea } = Input;
class postAndRoleLimit extends React.Component {
  serviceTaskSettings = React.createRef();
  state = {
    currentElement: '',
    openServeiceModal: false,
    selectServiceType: '',
    modeler: {},
  };
  componentDidMount() {
    const temp = this.props.currentElement;
    const modeler = this.props.modeler;
    this.setState({
      openServeiceModal: true,
      currentElement: temp,
      modeler: modeler,
    });
    this.echoServeiceSettings();
  }

  // 回显
  echoServeiceSettings = () => {
    const selectServiceType = this.props.currentElement.businessObject.type;
    console.log(selectServiceType);

    const settingsValues = this.props.currentElement.businessObject
      .extensionElements?.values;
    console.log(settingsValues);
    let objService = {};
    if (settingsValues) {
      settingsValues.map((item) => {
        objService[item.name] = item.string.body;
      });
    }
    console.log(objService);
    this.setState({ selectServiceType: selectServiceType }, () => {
      this.serviceTaskSettings.current?.setFieldsValue(objService);
    });
  };
  serveiceTypeModalOk = async (e) => {
    try {
      const settings = await this.serviceTaskSettings.current?.validateFields();
      let currentElement = this.state.currentElement;

      currentElement.businessObject.type = this.state.selectServiceType;

      // 判断是否存在 extensionElements属性
      let extensionElements = this.state.currentElement.businessObject.get(
        'extensionElements',
      );
      if (!extensionElements) {
        extensionElements = this.state.modeler
          .get('moddle')
          .create('bpmn:ExtensionElements');
        currentElement.businessObject.extensionElements = extensionElements;
        currentElement.businessObject.extensionElements.values = [];
      }
      currentElement.businessObject.extensionElements.values = [];
      for (let key in settings) {
        if (Object.prototype.hasOwnProperty.call(settings, key)) {
          if (settings[key] != undefined) {
            console.log(settings[key]);
            let field = this.state.modeler
              .get('moddle')
              .create('flowable:string');
            // 判断如果类型是表达式 就创建expression类型的标签，
            field['body'] = settings[key];
            const executeListener = this.state.modeler
              .get('moddle')
              .create('flowable:Field');
            executeListener['name'] = key;
            executeListener['string'] = field;
            console.log(executeListener);
            currentElement.businessObject.extensionElements.values.push(
              executeListener,
            );
          }
        }
      }
      this.setState({ openServeiceModal: false });
      this.props.serviceTaskTranfer(currentElement);

      // extensionElements.get('values').push(executeListener);
    } catch (err) {
      message.warn('注意必输字段');
    }
  };

  serveiceTypeModalCancle = () => {
    this.setState({ openServeiceModal: false });
    this.props.serviceTaskCancle('e');
  };
  // 类型选择
  selectServiceType = (e) => {
    this.setState({ selectServiceType: e });
  };
  render() {
    return (
      <div>
        <Modal
          title="服务设置"
          visible={this.state.openServeiceModal}
          okText="确认"
          cancelText="取消"
          width="55%"
          maskClosable={false}
          onOk={this.serveiceTypeModalOk}
          onCancel={this.serveiceTypeModalCancle}
        >
          <Col span={12}>
            <Form.Item
              style={{ marginBottom: 0 }}
              label="请选择业务"
              labelCol={{ span: 9 }}
              wrapperCol={{ span: 15 }}
            >
              <Select
                placeholder="默认值"
                onChange={this.selectServiceType}
                value={this.state.selectServiceType}
              >
                <Select.Option value="mail">邮件任务</Select.Option>
                <Select.Option value="http">HTTP任务</Select.Option>
                <Select.Option value="shell">shell任务</Select.Option>
              </Select>
            </Form.Item>
          </Col>
          <Form
            onFinish={this.serveiceTypeModalOk}
            ref={this.serviceTaskSettings}
          >
            {this.state.selectServiceType == 'http' && (
              <>
                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="请求方法"
                      name="requestMethod"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                      rules={[{ required: true, message: '必填，请输入' }]}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="get">get</Select.Option>
                        <Select.Option value="post">post</Select.Option>
                        <Select.Option value="PUT">PUT</Select.Option>
                        <Select.Option value="DELETE">DELETE</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="请求路径"
                      name="requestUrl"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                      rules={[{ required: true, message: '必填，请输入' }]}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="禁用重定向"
                      name="disallowRedirects"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="true">是</Select.Option>
                        <Select.Option value="false">否</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="响应变量名称"
                      name="responseVariableName"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="请求失败码"
                      name="failStatusCodes"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="处理状态码/成功"
                      name="handleStatusCodes"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="是否忽略异常"
                      name="ignoreException"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="true">是</Select.Option>
                        <Select.Option value="false">否</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="是否保存请求变量"
                      name="saveRequestVariables"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="true">是</Select.Option>
                        <Select.Option value="false">否</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="是否保存响应参数"
                      name="saveResponseParameters"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="true">是</Select.Option>
                        <Select.Option value="false">否</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="是否将响应参数保存为瞬时变量"
                      name="saveResponseParametersTransient"
                      labelCol={{ span: 11 }}
                      wrapperCol={{ span: 13 }}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="true">是</Select.Option>
                        <Select.Option value="false">否</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="否将响应变量以json存储"
                      name="saveResponseVariableAsJson"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="true">是</Select.Option>
                        <Select.Option value="false">否</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="响应结果前缀"
                      name="resultVariablePrefix"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="请求头"
                      style={{ marginBottom: 0 }}
                      name="requestHeaders"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <TextArea></TextArea>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="请求体"
                      name="requestBody"
                      style={{ marginBottom: 0 }}
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <TextArea></TextArea>
                    </Form.Item>
                  </Col>
                </Row>
              </>
            )}

            {this.state.selectServiceType == 'mail' && (
              <>
                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="发件人邮箱"
                      name="from"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                      rules={[{ required: true, message: '必填，请输入' }]}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="收件人邮箱"
                      name="to"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                      rules={[{ required: true, message: '必填，请输入' }]}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="抄送人邮箱"
                      name="cc"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="密送人邮箱"
                      name="bcc"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="邮件内容编码"
                      name="charset"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="邮件内容"
                      style={{ marginBottom: 0 }}
                      name="text"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                      rules={[{ required: true, message: '必填，请输入' }]}
                    >
                      <TextArea></TextArea>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="html内容"
                      name="html"
                      style={{ marginBottom: 0 }}
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <TextArea></TextArea>
                    </Form.Item>
                  </Col>
                </Row>
              </>
            )}

            {this.state.selectServiceType == 'shell' && (
              <>
                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="要执行的shell命令"
                      name="command"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                      rules={[{ required: true, message: '必填，请输入' }]}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="参数0"
                      name="arg0"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="参数1"
                      name="arg1"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="参数2"
                      name="arg2"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>
                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="参数3"
                      name="arg3"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="参数4"
                      name="arg4"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="参数5"
                      name="arg5"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="参数6"
                      name="arg6"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="请输入"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="是否避免Shell进程继承当前环境"
                      name="cleanEnv"
                      labelCol={{ span: 10 }}
                      wrapperCol={{ span: 14 }}
                    >
                      <Select placeholder="默认值">
                        <Select.Option value="true">是</Select.Option>
                        <Select.Option value="false">否</Select.Option>
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label="保存输出的变量名"
                      name="outputVariable"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="默认值"></Input>
                    </Form.Item>
                  </Col>
                </Row>

                <Row justify="start">
                  <Col span={12}>
                    <Form.Item
                      label="保存结果错误码的变量名"
                      name="errorCodeVariable"
                      style={{ marginBottom: 0 }}
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="默认值"></Input>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      style={{ marginBottom: 0 }}
                      label="Shell进程的默认目录"
                      name="directory"
                      labelCol={{ span: 9 }}
                      wrapperCol={{ span: 15 }}
                    >
                      <Input placeholder="默认值"></Input>
                    </Form.Item>
                  </Col>
                </Row>
              </>
            )}
          </Form>
        </Modal>
      </div>
    );
  }
}
export default postAndRoleLimit;
