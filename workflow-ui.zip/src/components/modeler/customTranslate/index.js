import CustomTranslate from './customTranslate';

export default {
  __init__: ['translate'],
  translate: ['value', CustomTranslate],
};
