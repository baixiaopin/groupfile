import BaseRenderer from 'diagram-js/lib/draw/BaseRenderer';

import {
  append as svgAppend,
  attr as svgAttr,
  create as svgCreate,
} from 'tiny-svg';
import {
  customElements,
  baseCustomElements,
  customConfig,
  hasLabelElements,
} from './util';
// import { is } from 'bpmn-js/lib/util/ModelUtil';

const HIGH_PRIORITY = 1500;

const propertiesConfig = {
  'bpmn:StartEvent': {
    stroke: 'rgb(137, 194, 194)',
    fill: 'rgb(41, 150, 146,0.9)',
  },
  'bpmn:SequenceFlow': {
    stroke: 'red',
    fill: '#cbffcf',
  },
  'bpmn:Task': {
    stroke: '#CAFF70',
    fill: '#cbffcf',
  },
  'bpmn:UserTask': {
    stroke: '#8a8ce0',
    fill: '#b5abd1',
  },
  'bpmn:ServiceTask': {
    stroke: '#138585',
    fill: '#33bcb7',
  },
  // 互斥网关
  'bpmn:ExclusiveGateway': {
    stroke: '#CAFF70',
    fill: '#cbffcf',
  },
  // 并行网关
  'bpmn:ParallelGateway': {
    stroke: '#CAFF70',
    fill: '#cbffcf',
  },
  // 包容网关
  'bpmn:InclusiveGateway': {
    stroke: '#CAFF70',
    fill: '#cbffcf',
  },
  // 手动任务
  'bpmn:ManualTask': {
    stroke: '#8fd460',
    fill: '#5cdbd3',
  },
  // 接受任务
  'bpmn:ReceiveTask': {
    stroke: '#84e2d8',
    fill: '#138585',
  },
};

export default class CustomRenderer extends BaseRenderer {
  constructor(eventBus, bpmnRenderer, modeling) {
    super(eventBus, HIGH_PRIORITY);
    this.bpmnRenderer = bpmnRenderer;
    this.modeling = modeling;
  }

  canRender(element) {
    // ignore labels
    return !element.labelTarget;
  }

  drawShape(parentNode, element) {
    const type = element.type; // 获取到自定义渲染的类型
    if (baseCustomElements.includes(type)) {
      if (type == 'bpmn:StartEvent') {
        element.width = 40;
        element.height = 40;
      } else {
        element.width = 90;
        element.height = 70;
      }
      let shape = this.bpmnRenderer.drawShape(parentNode, element);
      setShapeProperties(shape, element); // 在此修改shape
      return shape;
    }

    if (customElements.includes(type)) {
      // or customConfig[type]
      const { url, attr } = customConfig[type];
      const customIcon = svgCreate('image', {
        ...attr,
        href: url,
      });
      element['width'] = attr.width; // 这里我是取了巧, 直接修改了元素的宽高
      element['height'] = attr.height;
      svgAppend(parentNode, customIcon);
      // 判断是否有name属性来决定是否要渲染出label
      // if (!hasLabelElements.includes(type) && element.businessObject.name) {
      //   const text = svgCreate('text', {
      //     x: attr.x,
      //     y: attr.y + attr.height + 20,
      //     'font-size': '14',
      //     fill: '#000',
      //   });
      //   text.innerHTML = element.businessObject.name;
      //   svgAppend(parentNode, text);
      // }
      // this.modeling.resizeShape(element, {
      //     x: element.x,
      //     y: element.y,
      //     width: element['width'] / 2,
      //     height: element['height'] / 2
      // })
      return customIcon;
    }
    // else if (type === 'bpmn:TextAnnotation' && element.businessObject.color) {
    //     let color = element.businessObject.color
    //     element.businessObject.di.set('bioc:stroke', color)
    //     const shape = this.bpmnRenderer.drawShape(parentNode, element)
    //     return shape
    // }
    const shape = this.bpmnRenderer.drawShape(parentNode, element);
    return shape;
  }

  getShapePath(shape) {
    return this.bpmnRenderer.getShapePath(shape);
  }
}

function setShapeProperties(shape, element) {
  const type = element.type; // 获取到的类型
  if (propertiesConfig[type]) {
    const properties = propertiesConfig[type];
    Object.keys(properties).forEach((prop) => {
      shape.style.setProperty(prop, properties[prop]);
    });
  }
}

CustomRenderer.$inject = ['eventBus', 'bpmnRenderer', 'modeling'];
