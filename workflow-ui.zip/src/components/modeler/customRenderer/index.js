/*
 * @功能：自定义左侧面板
 */
// 定义左侧工具栏元素
import CustomPalette from '../customPalette/CustomPalette';
//
import CustomRenderer from './CustomRenderer';
// 定义左侧工具栏
import PaletteModule from '../customPalette/palette';

/**
 * paletteProvider 这个名称不能改变
 * 这样相当于直接重写了PaletteProvider这个类, 同时覆盖了其原型上的getPaletteEntries方法, 从而达到覆盖原有的工具栏的效果
 */
export default {
  __depends__: [PaletteModule],
  __init__: ['paletteProvider', 'customRenderer'],
  paletteProvider: ['type', CustomPalette],
  customRenderer: ['type', CustomRenderer],
};
