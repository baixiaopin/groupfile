import React, { Component } from 'react';

class CustomContextPad extends Component {}

export default CustomContextPad;
