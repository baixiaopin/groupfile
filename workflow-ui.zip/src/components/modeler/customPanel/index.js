// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcCard as Card,
  FcTabs as Tabs,
  FcModal as Modal,
  FcForm as Form,
  FcInput as Input,
  FcTable as Table,
  FcSelect as Select,
  FcCollapse as Collapse,
  FcRow as Row,
  FcCol as Col,
  FcSkeleton as Skeleton,
  FcRadio as Radio,
  FcList as List,
  FcBadge as Badge,
  FcTooltip as Tooltip,
  FcMessage as message,
} from '@ngfed/fc-components';
const { TabPane } = Tabs;
const { Column } = Table;
const { Panel } = Collapse;
import { find, groupBy, objectVariableArray } from './function';
import './index.less';
import styles from './index.module.less';
import ServiceTaskSetting from '../../serviceTaskSetting';
import ManualTask from '../../manualTask';
import UserTask from '../../userTask';
class PropertiesView extends Component {
  // 用户任务
  userTaskNodeInfoRef = React.createRef();

  // 服务任务
  serviceTaskNodeInfoRef = React.createRef();
  serviceTaskSettingRef = React.createRef();
  // 子流程
  subProcessTaskNodeInfoRef = React.createRef();
  subProcessTaskSettingRef = React.createRef();
  newBuildExecutionListenersRef = React.createRef();
  newBuildTaskListenersRef = React.createRef();
  //网关流程线
  sequenceFlowNodeInfoRef = React.createRef();
  sequenceFlowSettingRef = React.createRef();
  // 服务类型
  serviceType = React.createRef();
  // 服务类
  serviceClass = React.createRef();
  // 子流程
  subProcessNodeInfoRef = React.createRef();
  // 事务子流程
  TransactionNodeInfoRef = React.createRef();
  // 手工任务
  saveManualTaskNameInfoRef = React.createRef();
  state = {
    modeler: null,
    customElements: [],
    // 当前节点 类型
    currentElement: {},
    currentElementType: '',

    // 服务任务
    openServeiceTypeModal: false,
    openServeiceClassModal: false,
    serviceTypeList: ['服务任务'],
    serviceTypeValue: {},
    // 判断服务类型的字段名是否存在
    serviceVisble: false,
    // 服务类
    addServiceClassList: [],
    serviceClassList: [],
    serviceClassNum: 0,
    // 组织架构树
    selectType: '',
    // 服务任务设置
    openServeiceSettingModal: false,
    // 手动任务
    openManualTaskModal: false,
    // 标签key
    handleModeChangeValue: '1',
    currentElementTypeUserTask: '',
  };
  componentDidMount() {
    // 组件挂载后触发，通过组件间传值 渲染节点值
    setTimeout(() => {
      this.props.modeler.on('selection.changed', (e) => {
        // 判断是否使用模型校验
        if (document.getElementsByClassName('bjsl-button').length > 0) {
          const arr = document.getElementsByClassName('bjsl-button');
          this.props.checkError(arr[0].textContent);
        }
        // 将选中的节点存在变量selectedElement
        const selectedElement = e.newSelection[0];
        console.log(selectedElement, '选中节点');
        if (selectedElement) {
          this.setState({
            currentElement: selectedElement,
            currentElementType: selectedElement.type,
            delegateList: [],
            personnelLimit: false,
            handleModeChangeValue: '1',
            currentElementTypeUserTask: '',
          });

          if (selectedElement.type == 'bpmn:UserTask') {
            setTimeout(() => {
              this.setState({
                currentElementTypeUserTask: 'userTask',
              });
            });
          }
        }
        // 错误边界事件
        // if (selectedElement && selectedElement.type === 'bpmn:BoundaryEvent') {
        //   if (selectedElement?.businessObject?.eventDefinitions?.[0]) {
        //     const error = this.props.modeler.get('moddle').create('bpmn:Error');
        //     console.log(error, '--------------');
        //     error.errorCode = 'errorMessage';
        //     error.id = 'error';
        //     selectedElement.businessObject.eventDefinitions[0].errorRef = error;
        //   }
        // }

        // 回显用户任务
        if (selectedElement && selectedElement.type === 'bpmn:UserTask') {
          const { id, name, $type: type } = selectedElement?.businessObject;
          const { width, height } = selectedElement;
          const {
            name: modelName,
            id: modelKey,
          } = selectedElement.businessObject.$parent;
          this.userTaskNodeInfoRef.current.setFieldsValue({
            id,
            name,
            type,
            width,
            height,
            modelName,
            modelKey,
          });
        }
        // 回显节点流程线任务
        if (selectedElement && selectedElement.type === 'bpmn:SequenceFlow') {
          const { id, name } = selectedElement?.businessObject;
          const { type, width, height } = selectedElement;
          const {
            name: modelName,
            id: modelKey,
          } = selectedElement.businessObject.$parent;
          this.sequenceFlowNodeInfoRef.current.setFieldsValue({
            id,
            name,
            type,
            width,
            height,
            modelName,
            modelKey,
          });
          const attrs = selectedElement.businessObject.$attrs;
          // 判断线段是否存在条件，存在就回显，否则就清空
          if (attrs['flowable:skipExpression']) {
            this.setState(() => {
              this.sequenceFlowSettingRef.current.setFieldsValue({
                name: name,
              });
            });
          } else {
            this.setState(() => {
              this.sequenceFlowSettingRef.current.setFieldsValue({
                skipExpression: '',
                name: '',
              });
            });
          }
          const attrss = selectedElement.businessObject;
          // 后台返回值回显
          if (attrss.conditionExpression) {
            this.setState(() => {
              this.sequenceFlowSettingRef.current.setFieldsValue({
                skipExpression: attrss.conditionExpression.body,
                name: name,
              });
            });
          }
          return;
        }

        // 回显服务任务
        if (selectedElement && selectedElement.type === 'bpmn:ServiceTask') {
          // 回显服务委托实现类，判断是否设置了委托实现类，没有就不显示字段名
          if (
            !selectedElement.businessObject.delegateExpression &&
            !selectedElement.businessObject.class &&
            !selectedElement.businessObject.expression
          ) {
            this.setState({ serviceVisble: false });
          }
          // 如果委托实现类，是委托表达式就回显
          if (selectedElement.businessObject.delegateExpression) {
            this.setState({ serviceVisble: true });
            this.serviceType.current.setFieldsValue({
              type0: 'delegateExpression',
              value0: selectedElement.businessObject.delegateExpression,
              name0: selectedElement.businessObject.documentation[0].text,
            });
          }
          // 如果委托实现类，是类就回显
          if (selectedElement.businessObject.class) {
            this.setState({ serviceVisble: true });
            this.serviceType.current.setFieldsValue({
              type0: 'class',
              value0: selectedElement.businessObject.class,
              name0: selectedElement.businessObject.documentation
                ? selectedElement.businessObject.documentation[0].text
                : '',
            });
          }
          // 如果没有设置委托实现类就清除掉表单
          if (
            !selectedElement.businessObject.delegateExpression &&
            !selectedElement.businessObject.class
          ) {
            this.serviceType.current.resetFields();
            this.serviceClass.current.resetFields();
          }
          // 判断字段名是否存在
          if (!selectedElement.businessObject.extensionElements) {
            this.setState({ serviceClassNum: 0, addServiceClassList: [] });
            this.serviceClass.current.resetFields();
          }
          if (selectedElement.businessObject.extensionElements) {
            // 回显tag标签
            if (selectedElement.businessObject.extensionElements.values) {
              this.setState({
                serviceClassNum:
                  selectedElement.businessObject.extensionElements.values
                    .length,
              });
            }
            // 引入groupBy方法将字段名数组按类型分类
            let twoTypeMontaior = groupBy(
              selectedElement.businessObject.extensionElements.values,
              '$type',
            );
            if (twoTypeMontaior['flowable:Field']) {
              // 回显服务委托的数量
              this.setState({
                addServiceClassList: twoTypeMontaior['flowable:Field'],
              });
              // 取出分类好的数据，按表单要求放入数组中
              let newExectueList = [];
              for (
                let k = 0;
                k < twoTypeMontaior['flowable:Field'].length;
                k++
              ) {
                let newExectueList1 = {};
                newExectueList1['name' + k] =
                  twoTypeMontaior['flowable:Field'][k].name;
                // 判断服务委托属性是string，expression
                if (twoTypeMontaior['flowable:Field'][k].expression) {
                  newExectueList1['type' + k] = 'expression';
                  newExectueList1['value' + k] =
                    twoTypeMontaior['flowable:Field'][k].expression.body;
                }
                if (twoTypeMontaior['flowable:Field'][k].string) {
                  newExectueList1['type' + k] = 'string';
                  newExectueList1['value' + k] =
                    twoTypeMontaior['flowable:Field'][k].string.body;
                }
                newExectueList.push(newExectueList1);
              }
              //  将数组转化为对象并赋值给serviceClass表单
              this.serviceClass.current.setFieldsValue(
                Object.assign(...newExectueList),
              );
            } else {
              this.serviceClass.current.resetFields();
              this.setState({ addServiceClassList: [] });
            }
          }
          // 是否为补偿事件
          if (selectedElement?.businessObject.isForCompensation) {
            this.serviceTaskSettingRef.current.setFieldsValue({
              isForCompensation: true,
            });
          } else {
            this.serviceTaskSettingRef.current.setFieldsValue({
              isForCompensation: false,
            });
          }
          // 回显节点ID和节点名称，面板一
          const { id, name, $type: type } = selectedElement?.businessObject;
          const { width, height } = selectedElement;
          const {
            name: modelName,
            id: modelKey,
          } = selectedElement.businessObject.$parent;
          this.serviceTaskNodeInfoRef.current.setFieldsValue({
            id,
            name,
            type,
            width,
            height,
            modelName,
            modelKey,
          });
          const {
            executionListeners,
            delegateExpresions,
            exclusivedeFinition,
            customProperties,
          } = selectedElement.businessObject.$attrs;
          this.serviceTaskSettingRef.current.setFieldsValue({
            executionListeners,
            delegateExpresions,
            exclusivedeFinition,
            customProperties,
          });
          return;
        }
        // 回显子流程
        if (selectedElement && selectedElement.type === 'bpmn:SubProcess') {
          // 回显服务委托实现类，判断是否设置了委托实现类，没有就不显示字段名
          const { id, name, $type: type } = selectedElement?.businessObject;
          const { width, height } = selectedElement;
          const {
            name: modelName,
            id: modelKey,
          } = selectedElement.businessObject.$parent;
          this.subProcessTaskNodeInfoRef.current.setFieldsValue({
            id,
            name,
            type,
            width,
            height,
            modelName,
            modelKey,
          });
          return;
        }

        // 回显手动任务
        if (selectedElement && selectedElement.type === 'bpmn:ManualTask') {
          // 回显服务委托实现类，判断是否设置了委托实现类，没有就不显示字段名
          const { id, name, $type: type } = selectedElement?.businessObject;
          const { width, height } = selectedElement;
          const {
            name: modelName,
            id: modelKey,
          } = selectedElement.businessObject.$parent;
          this.saveManualTaskNameInfoRef.current.setFieldsValue({
            id,
            name,
            type,
            width,
            height,
            modelName,
            modelKey,
          });
          return;
        }
      });

      this.setState({
        modeler: this.props.modeler,
        customElements: this.props.modeler.customElements,
      });
    }, 0);
  }

  // 更新节点颜色
  setColor = (properties) => {
    const modeling = this.props.modeler.get('modeling');
    modeling.setColor(this.state.currentElement, properties);
  };

  // 保存节点流程线
  saveSequenceFlowSetting = async (e) => {
    this.setColor({
      stroke: null,
      fill: null,
    });
    try {
      const value = this.sequenceFlowSettingRef.current.validateFields();
      const settings = this.sequenceFlowSettingRef.current.getFieldsValue();
      const sequenceFlowInfoFormClone = JSON.parse(JSON.stringify(settings));
      delete sequenceFlowInfoFormClone.skipExpression;
      const properties = {};
      // 循环生成属性
      for (const key in sequenceFlowInfoFormClone) {
        if (sequenceFlowInfoFormClone.hasOwnProperty(key)) {
          const value = sequenceFlowInfoFormClone[key];
          if (value.length !== 0) {
            properties[`flowable:${key}`] = Array.isArray(value)
              ? value.toString()
              : value;
          }
        }
      }
      // 判断节点表达式是否存在
      let conditionExpression = this.state.currentElement.businessObject.get(
        'conditionExpression',
      );
      if (!conditionExpression) {
        conditionExpression = this.props.modeler
          .get('moddle')
          .create('bpmn:FormalExpression', {
            body: `<![CDATA[${properties['flowable:skipExpression']}]]>`,
          });
      }
      // 条件改变重新赋值
      conditionExpression.body = settings.skipExpression;
      this.updateProperties({ conditionExpression: conditionExpression });
      this.updateProperties(properties);
    } catch (errorInof) {
      message.error('格式错误');
    }
  };

  // 保存服务任务节点信息
  saveServiceTaskNodeInfo = () => {
    const settings = this.serviceTaskSettingRef.current.getFieldsValue();
    // 属性
    // 删除多余属性
    const serviceTaskNodeInfoFormClone = JSON.parse(JSON.stringify(settings));
    const properties = {};
    for (const key in serviceTaskNodeInfoFormClone) {
      if (serviceTaskNodeInfoFormClone.hasOwnProperty(key)) {
        const value = serviceTaskNodeInfoFormClone[key];
        if (value.length !== 0) {
          properties[`flowable:${key}`] = Array.isArray(value)
            ? value.toString()
            : value;
        }
      }
    }
    // 存在委托类型就清除旧值
    if (this.state.serviceTypeValue.type0) {
      if (this.state.currentElement.businessObject.delegateExpression) {
        delete this.state.currentElement.businessObject.delegateExpression;
      }
      if (this.state.currentElement.businessObject.class) {
        delete this.state.currentElement.businessObject.class;
      }
      if (this.state.currentElement.businessObject.expression) {
        delete this.state.currentElement.businessObject.expression;
      }
      // 添加服务任务，在当前对象上新加属性
      this.state.currentElement.businessObject[
        this.state.serviceTypeValue.type0
      ] = this.state.serviceTypeValue.value0;
      // 判断是否存在这个文本标签，不存在就创建
      let documentation = this.state.currentElement.businessObject.get(
        'documentation',
      );
      if (!documentation) {
        documentation = this.props.modeler
          .get('moddle')
          .create('bpmn:Documentation');
      }
      let documentation1 = this.props.modeler
        .get('moddle')
        .create('bpmn:Documentation', {
          text: String(this.state.serviceTypeValue.name0),
        });
      documentation = [];
      documentation.push(documentation1);
      this.updateProperties({ documentation: documentation });
    }
    // 节点字段名
    let extensionElements = this.state.currentElement.businessObject.get(
      'extensionElements',
    );
    if (!extensionElements) {
      extensionElements = this.props.modeler
        .get('moddle')
        .create('bpmn:ExtensionElements');
    }
    //判断是否有服务委托类,并且字段名存在
    if (
      this.state.serviceClassList.length > 0 ||
      this.state.currentElement.businessObject.documentation
    ) {
      extensionElements.values = [];
      // 服务任务委托类
      this.state.serviceClassList.forEach((item) => {
        let field = [];
        // 判断如果类型是字符串 就创建string类型的标签，
        if (item.data[1].value == 'string') {
          field = this.props.modeler.get('moddle').create('flowable:string');
        }
        // 判断如果类型是表达式 就创建expression类型的标签，
        if (item.data[1].value == 'expression') {
          field = this.props.modeler
            .get('moddle')
            .create('flowable:expression');
        }
        field['body'] = item.data[2].value;
        const executeListener = this.props.modeler
          .get('moddle')
          .create('flowable:Field');
        executeListener['name'] = item.data[0].value;
        executeListener['string'] = field;
        extensionElements.get('values').push(executeListener);
      });
      this.updateProperties({ extensionElements: extensionElements });
    }
    this.updateProperties(properties);
  };

  // 更新用户名称
  saveUserTaskName = () => {
    const { name, id } = this.userTaskNodeInfoRef.current.getFieldsValue();
    if (id) {
      this.state.currentElement.businessObject.id = id;
    }
    this.updateLabel(name);
  };

  // 更新流程节点名称
  saveSequenceFlowName = () => {
    const { name } = this.sequenceFlowNodeInfoRef.current.getFieldsValue();
    this.updateLabel(name);
  };

  // 更新服务任务名称
  saveServiceName = () => {
    const { name, id } = this.serviceTaskNodeInfoRef.current.getFieldsValue();
    if (id) {
      this.state.currentElement.businessObject.id = id;
    }
    this.updateLabel(name);
  };

  // 更新子流程名称
  saveSubProcessName = () => {
    const {
      name,
      id,
    } = this.subProcessTaskNodeInfoRef.current.getFieldsValue();
    if (id) {
      this.state.currentElement.businessObject.id = id;
    }
    this.updateLabel(name);
  };

  // 更新事务子流程
  saveTransactionName = () => {
    const { name, id } = this.TransactionNodeInfoRef.current.getFieldsValue();
    if (id) {
      this.state.currentElement.businessObject.id = id;
    }
    this.updateLabel(name);
  };

  // 更新自定义属性
  updateProperties = (properties) => {
    const modeling = this.props.modeler.get('modeling');
    modeling.updateProperties(this.state.currentElement, properties);
  };

  // 更新Label
  updateLabel = (label) => {
    const modeling = this.props.modeler.get('modeling');
    modeling.updateLabel(this.state.currentElement, label);
  };

  // 确认服务委托类
  // 确认服务委托类Model
  openServeiceTypeModal = () => {
    this.setState({ openServeiceTypeModal: true });
  };

  // 确认服务委托类
  serveiceTypeModalOk = async (e) => {
    try {
      const values = await this.serviceType.current.validateFields();
      this.setState(
        {
          openServeiceTypeModal: false,
          serviceTypeValue: this.serviceType.current.getFieldsValue(),
          serviceVisble: true,
        },
        () => {
          this.saveServiceTaskNodeInfo();
        },
      );
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 服务委托类关闭
  serveiceTypeModal = () => {
    this.setState({ openServeiceTypeModal: false });
  };

  // 打开服务委托类
  openServeiceClassModal = () => {
    this.setState({ openServeiceClassModal: true });
  };
  serviceClassModalOk = async (e) => {
    try {
      const values = await this.serviceClass.current.validateFields();
      let setting = this.serviceClass.current.getFieldsValue();
      //  处理服务类添加的对象转化为数组,引入objectVariableArray方法处理
      const settingTemp = objectVariableArray(setting);
      this.setState(
        {
          openServeiceClassModal: false,
          serviceClassList: settingTemp,
          serviceClassNum: settingTemp.length,
        },
        () => {
          this.saveServiceTaskNodeInfo();
        },
      );
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };
  serviceClassModal = () => {
    this.setState({ openServeiceClassModal: false });
  };

  // 服务任务 补偿事件
  serviceClassIsForCompensation = () => {
    let {
      isForCompensation,
    } = this.serviceTaskSettingRef.current.getFieldsValue();
    const { name, id } = this.serviceTaskNodeInfoRef.current.getFieldsValue();
    this.state.currentElement.businessObject.isForCompensation = isForCompensation;
    this.updateLabel(name);
  };

  // 添加一条服务信息
  addServiceClassList = () => {
    const num = this.state.addServiceClassList;
    num.push(num.length);
    this.setState({
      addServiceClassList: num,
    });
  };

  // 删除服务字段
  deletServiceClass = (e) => {
    const addListTem = this.state.addServiceClassList;
    addListTem.splice(this.state.addServiceClassList.length - 1, 1);
    this.setState({ addServiceClassList: addListTem });
  };

  // 网关格式判断 saveSequenceFlowSettingTemp
  //  更多服务任务设置
  openServeiceSettingModal = () => {
    this.setState({ openServeiceSettingModal: true });
  };
  serviceTaskTranfer = (e) => {
    this.setState({ openServeiceSettingModal: false, currentElement: e });
  };
  serviceTaskCancle = () => {
    this.setState({ openServeiceSettingModal: false });
  };

  // 手工任务
  saveManualTaskName = () => {
    const { name } = this.saveManualTaskNameInfoRef.current.getFieldsValue();
    this.updateLabel(name);
  };
  // 手动任务
  openManualTaskModal = () => {
    this.setState({ openManualTaskModal: true });
  };
  // 子组件传值取消按钮
  manualTaskCancle = () => {
    this.setState({ openManualTaskModal: false });
  };

  // 子组件传值成功按钮
  manualTaskok = (e) => {
    this.setState({ openManualTaskModal: false, currentElement: e });
  };

  handleModeChange = (e) => {
    this.setState({ handleModeChangeValue: e });
  };
  render() {
    return (
      <>
        <div className="panel">
          <Card>
            <div className="panelpanel">
              <Tabs
                size="small"
                activeKey={this.state.handleModeChangeValue}
                onChange={this.handleModeChange}
              >
                <TabPane tab="节点信息" key="1">
                  <div>
                    {this.state.currentElementType == '' && (
                      <>
                        <Skeleton active></Skeleton>
                      </>
                    )}
                    {/* 网关流程线 */}
                    {this.state.currentElementType == 'bpmn:SequenceFlow' && (
                      <Form
                        ref={this.sequenceFlowNodeInfoRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 16 }}
                        onFinish={this.saveSequenceFlowName}
                      >
                        <Card
                          type="inner"
                          title="节点信息"
                          bodyStyle={{ padding: 0, paddingTop: 12 }}
                        >
                          <Form.Item name="name" label="节点名称">
                            <Input onBlur={this.saveSequenceFlowName} />
                          </Form.Item>
                          <Form.Item name="id" label="节点ID">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="type" label="节点类型">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="宽度">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="height" label="高度">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                        <Card
                          type="inner"
                          title="流程信息"
                          bodyStyle={{
                            padding: 0,
                            paddingTop: 12,
                            marginTop: 10,
                          }}
                        >
                          <Form.Item name="modelName" label="模型名称">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="modelKey" label="KEY">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="描述">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                      </Form>
                    )}

                    {/* 手工任务 */}
                    {this.state.currentElementType == 'bpmn:ManualTask' && (
                      <Form
                        ref={this.saveManualTaskNameInfoRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 16 }}
                        onFinish={this.saveManualTaskName}
                      >
                        <Card
                          type="inner"
                          title="节点信息"
                          bodyStyle={{ padding: 0, paddingTop: 12 }}
                        >
                          <Form.Item name="name" label="节点名称">
                            <Input onBlur={this.saveManualTaskName} />
                          </Form.Item>
                          <Form.Item name="id" label="节点ID">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="type" label="节点类型">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="宽度">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="height" label="高度">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                        <Card
                          type="inner"
                          title="流程信息"
                          bodyStyle={{
                            padding: 0,
                            paddingTop: 12,
                            marginTop: 10,
                          }}
                        >
                          <Form.Item name="modelName" label="模型名称">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="modelKey" label="KEY">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="描述">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                      </Form>
                    )}
                    {/* 用户任务 */}
                    {this.state.currentElementType == 'bpmn:UserTask' && (
                      <Form
                        ref={this.userTaskNodeInfoRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 16 }}
                        onFinish={this.saveUserTaskName}
                      >
                        <Card
                          type="inner"
                          title="节点信息"
                          bodyStyle={{ padding: 0, paddingTop: 12 }}
                        >
                          <Form.Item name="name" label="节点名称">
                            <Input onBlur={this.saveUserTaskName} />
                          </Form.Item>
                          <Form.Item name="id" label="节点ID">
                            <Input onBlur={this.saveUserTaskName} />
                          </Form.Item>
                          <Form.Item name="type" label="节点类型">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="宽度">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="height" label="高度">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                        <Card
                          type="inner"
                          title="流程信息"
                          bodyStyle={{
                            padding: 0,
                            paddingTop: 12,
                            marginTop: 10,
                          }}
                        >
                          <Form.Item name="modelName" label="模型名称">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="modelKey" label="KEY">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="描述">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                      </Form>
                    )}
                    {/* 服务任务 */}
                    {this.state.currentElementType == 'bpmn:ServiceTask' && (
                      <Form
                        ref={this.serviceTaskNodeInfoRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 16 }}
                        onFinish={this.saveServiceName}
                      >
                        <Card
                          type="inner"
                          title="节点信息"
                          bodyStyle={{ padding: 0, paddingTop: 12 }}
                        >
                          <Form.Item name="name" label="节点名称">
                            <Input onBlur={this.saveServiceName} />
                          </Form.Item>
                          <Form.Item name="id" label="节点ID">
                            <Input onBlur={this.saveServiceName} />
                          </Form.Item>
                          <Form.Item name="type" label="节点类型">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="宽度">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="height" label="高度">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                        <Card
                          type="inner"
                          title="流程信息"
                          bodyStyle={{
                            padding: 0,
                            paddingTop: 12,
                            marginTop: 10,
                          }}
                        >
                          <Form.Item name="modelName" label="模型名称">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="modelKey" label="KEY">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="描述">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                      </Form>
                    )}
                    {/* 子流程 */}
                    {this.state.currentElementType == 'bpmn:SubProcess' && (
                      <Form
                        ref={this.subProcessTaskNodeInfoRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 16 }}
                        onFinish={this.saveSubProcessName}
                      >
                        <Card
                          type="inner"
                          title="节点信息"
                          bodyStyle={{ padding: 0, paddingTop: 12 }}
                        >
                          <Form.Item name="name" label="节点名称">
                            <Input onBlur={this.saveSubProcessName} />
                          </Form.Item>
                          <Form.Item name="id" label="节点ID">
                            <Input onBlur={this.saveSubProcessName} />
                          </Form.Item>
                          <Form.Item name="type" label="节点类型">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="宽度">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="height" label="高度">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                        <Card
                          type="inner"
                          title="流程信息"
                          bodyStyle={{
                            padding: 0,
                            paddingTop: 12,
                            marginTop: 10,
                          }}
                        >
                          <Form.Item name="modelName" label="模型名称">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="modelKey" label="KEY">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="描述">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                      </Form>
                    )}
                    {/* 事务子流程 */}
                    {this.state.currentElementType == 'bpmn:Transaction' && (
                      <Form
                        ref={this.TransactionNodeInfoRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 7 }}
                        wrapperCol={{ span: 16 }}
                        onFinish={this.saveTransactionName}
                      >
                        <Card
                          type="inner"
                          title="节点信息事务"
                          bodyStyle={{ padding: 0, paddingTop: 12 }}
                        >
                          <Form.Item name="name" label="节点名称">
                            <Input onBlur={this.saveTransactionName} />
                          </Form.Item>
                          <Form.Item name="id" label="节点ID">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="type" label="节点类型">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="宽度">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="height" label="高度">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                        <Card
                          type="inner"
                          title="流程信息"
                          bodyStyle={{
                            padding: 0,
                            paddingTop: 12,
                            marginTop: 10,
                          }}
                        >
                          <Form.Item name="modelName" label="模型名称">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="modelKey" label="KEY">
                            <Input disabled />
                          </Form.Item>
                          <Form.Item name="width" label="描述">
                            <Input disabled />
                          </Form.Item>
                        </Card>
                      </Form>
                    )}
                  </div>
                </TabPane>
                <TabPane tab="基础设置" key="2" forceRender={true}>
                  <div style={{ overflow: 'auto' }}>
                    {/* 用户任务 */}
                    {this.state.currentElementTypeUserTask == 'userTask' && (
                      <UserTask
                        currentElement={this.state.currentElement}
                        modeler={this.state.modeler}
                      ></UserTask>
                    )}
                    {this.state.currentElementType == '' && (
                      <>
                        {' '}
                        <Skeleton active></Skeleton>
                      </>
                    )}
                    {/* 服务任务 */}
                    {this.state.currentElementType == 'bpmn:ServiceTask' && (
                      <Form
                        ref={this.serviceTaskSettingRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 8 }}
                        wrapperCol={{ span: 16 }}
                      >
                        <Collapse accordion>
                          <Panel header="节点事件" key="1">
                            <Form.Item label="委托实现类">
                              <Button onClick={this.openServeiceTypeModal}>
                                编辑
                              </Button>
                            </Form.Item>
                            {this.state.serviceVisble && (
                              <Form.Item label="字段名">
                                <Badge
                                  count={this.state.serviceClassNum}
                                  style={{ backgroundColor: '#52c41a' }}
                                >
                                  <Button onClick={this.openServeiceClassModal}>
                                    编辑
                                  </Button>
                                </Badge>
                              </Form.Item>
                            )}
                            <Form.Item
                              label="是否为补偿"
                              name="isForCompensation"
                            >
                              <Radio.Group
                                onChange={this.serviceClassIsForCompensation}
                              >
                                <Radio value={true}>是</Radio>
                                <Radio value={false}>否</Radio>
                              </Radio.Group>
                            </Form.Item>
                            <Form.Item
                              label="更多设置"
                              style={{ marginBottom: 0 }}
                            >
                              <Badge
                                // count="1"
                                style={{ backgroundColor: '#52c41a' }}
                              >
                                <Button onClick={this.openServeiceSettingModal}>
                                  编辑
                                </Button>
                              </Badge>
                            </Form.Item>
                          </Panel>
                        </Collapse>
                      </Form>
                    )}
                    {/* 服务任务设置 */}
                    {this.state.openServeiceSettingModal && (
                      <ServiceTaskSetting
                        serviceTaskTranfer={this.serviceTaskTranfer}
                        serviceTaskCancle={this.serviceTaskCancle}
                        currentElement={this.state.currentElement}
                        modeler={this.state.modeler}
                      ></ServiceTaskSetting>
                    )}
                    {/* 网关流程线 */}
                    {this.state.currentElementType == 'bpmn:SequenceFlow' && (
                      <Form
                        ref={this.sequenceFlowSettingRef}
                        labelAlign="right"
                        layout="horizontal"
                        labelCol={{ span: 6 }}
                        wrapperCol={{ span: 17 }}
                        onFinish={this.saveSequenceFlowSetting}
                      >
                        <Collapse accordion>
                          <Panel header="条件判断" key="1">
                            <Form.Item
                              name="skipExpression"
                              style={{ marginBottom: 0 }}
                              label="表达式"
                              rules={[
                                { required: true, message: '请输入' },
                                {
                                  pattern: /^\$\{.*\}$/,
                                  message: '请以`${***}`形式',
                                },
                              ]}
                            >
                              <Input
                                onBlur={this.saveSequenceFlowSetting}
                                style={{ width: '90%' }}
                              />
                            </Form.Item>
                          </Panel>
                        </Collapse>
                      </Form>
                    )}

                    {/* 手动任务 */}
                    {this.state.currentElementType == 'bpmn:ManualTask' && (
                      <Collapse accordion>
                        <Panel header="节点事件" key="1">
                          <Form.Item
                            label="执行监听器"
                            labelCol={{ span: 9 }}
                            wrapperCol={{ span: 15 }}
                          >
                            <Badge
                              // count={this.state.serviceClassNum}
                              style={{ backgroundColor: '#52c41a' }}
                            >
                              <Button onClick={this.openManualTaskModal}>
                                编辑
                              </Button>
                            </Badge>
                          </Form.Item>
                        </Panel>
                      </Collapse>
                    )}
                  </div>
                </TabPane>
              </Tabs>
            </div>
          </Card>
        </div>
        {/* 手动任务 */}
        {this.state.openManualTaskModal && (
          <ManualTask
            manualTaskCancle={this.manualTaskCancle}
            manualTaskok={this.manualTaskok}
            currentElement={this.state.currentElement}
            modeler={this.state.modeler}
          ></ManualTask>
        )}
        {/* 服务任务 */}
        <Form labelAlign="right" layout="horizontal" ref={this.serviceType}>
          <Modal
            title="委托实现"
            visible={this.state.openServeiceTypeModal}
            okText="确认"
            cancelText="取消"
            width="50%"
            maskClosable={false}
            onOk={this.serveiceTypeModalOk}
            onCancel={this.serveiceTypeModal}
          >
            <List
              header={
                <Row style={{ width: '100%', padding: 0 }}>
                  <Col style={{ width: '33%', textAlign: 'center' }}>
                    委托实现名称
                    <Tooltip placement="top" title="委托实现名称">
                      <i className="iconfont">&#xe62a;</i>
                    </Tooltip>
                  </Col>
                  <Col style={{ width: '33%', textAlign: 'center' }}>
                    类型
                    <Tooltip
                      placement="top"
                      title="类：class绑定实现类，委托表达式：delegateExpression表达式绑定实现类"
                    >
                      <i className="iconfont">&#xe62a;</i>
                    </Tooltip>
                  </Col>
                  <Col style={{ width: '33%', textAlign: 'center' }}>
                    值
                    <Tooltip
                      placement="top"
                      title="如class类：com.sdebank.ngdb.workflow.sample.service.servicetask.PostService
                    Task"
                    >
                      <i className="iconfont">&#xe62a;</i>
                    </Tooltip>
                  </Col>
                </Row>
              }
              bordered
              dataSource={this.state.serviceTypeList}
              renderItem={(item, index) => (
                <List.Item style={{ padding: 0 }}>
                  <Row style={{ width: '100%' }}>
                    <Form.Item
                      name={'name' + index}
                      style={{
                        width: '33%',
                        margin: '8px 0',
                        textAlign: 'center',
                      }}
                      rules={[{ required: true, message: '请输入' }]}
                    >
                      <Input
                        style={{ width: '90%', textAlign: 'center' }}
                      ></Input>
                    </Form.Item>
                    <Form.Item
                      name={'type' + index}
                      style={{
                        width: '33%',
                        margin: '8px 0',
                        textAlign: 'center',
                      }}
                      rules={[{ required: true, message: '请选择' }]}
                    >
                      <Select style={{ width: '90%', text: 'left' }}>
                        <Select.Option value="class">类</Select.Option>
                        {/* <Select.Option value="expression">表达式</Select.Option> */}
                        <Select.Option value="delegateExpression">
                          委托表达式
                        </Select.Option>
                      </Select>
                    </Form.Item>
                    <Form.Item
                      name={'value' + index}
                      style={{
                        width: '33%',
                        margin: '8px 0',
                        textAlign: 'center',
                      }}
                      rules={[{ required: true, message: '请输入' }]}
                    >
                      <Input
                        style={{ width: '90%', textAlign: 'center' }}
                      ></Input>
                    </Form.Item>
                  </Row>
                </List.Item>
              )}
            ></List>
          </Modal>
        </Form>
        {/* 字段名 */}
        <Form labelAlign="right" layout="horizontal" ref={this.serviceClass}>
          <Modal
            title="字段名"
            visible={this.state.openServeiceClassModal}
            okText="确认"
            cancelText="取消"
            width="50%"
            maskClosable={false}
            onOk={this.serviceClassModalOk}
            onCancel={this.serviceClassModal}
          >
            <Button
              style={{
                marginTop: '-13px',
                display: 'block',
                marginBottom: '13px',
              }}
              type="primary"
              onClick={this.addServiceClassList}
            >
              添加
            </Button>
            <List
              header={
                <Row style={{ width: '100%', padding: 0 }}>
                  <Col style={{ width: '20%', textAlign: 'center' }}>
                    字段名称
                    <Tooltip placement="top" title="字段名称name">
                      <i className="iconfont">&#xe62a;</i>
                    </Tooltip>
                  </Col>
                  <Col style={{ width: '20%', textAlign: 'center' }}>
                    字段类型
                    <Tooltip
                      placement="top"
                      title="绑定PostServiceTask实现类的fieldA字段"
                    >
                      <i className="iconfont">&#xe62a;</i>
                    </Tooltip>
                  </Col>
                  <Col style={{ width: '40%', textAlign: 'center' }}>
                    值
                    <Tooltip
                      placement="top"
                      title="如表达式值为${1==1}，值为true"
                    >
                      <i className="iconfont">&#xe62a;</i>
                    </Tooltip>
                  </Col>
                  <Col style={{ width: '20%' }}>操作</Col>
                </Row>
              }
              style={{ paddingLeft: 0 }}
              bordered
              dataSource={this.state.addServiceClassList}
              renderItem={(item, index) => (
                <List.Item style={{ padding: 0 }}>
                  <Row style={{ width: '100%' }}>
                    <Form.Item
                      name={'name' + index}
                      style={{
                        width: '20%',
                        margin: '8px 0',
                        textAlign: 'center',
                      }}
                      rules={[{ required: true, message: '请输入' }]}
                    >
                      <Input
                        style={{ width: '90%', textAlign: 'center' }}
                      ></Input>
                    </Form.Item>
                    <Form.Item
                      name={'type' + index}
                      style={{
                        width: '20%',
                        margin: '8px 0',
                        textAlign: 'center',
                      }}
                      rules={[{ required: true, message: '请选择' }]}
                    >
                      <Select style={{ width: '90%' }}>
                        <Select.Option value="string">字符串</Select.Option>
                        {/* <Select.Option value="expression">表达式</Select.Option> */}
                      </Select>
                    </Form.Item>
                    <Form.Item
                      name={'value' + index}
                      style={{
                        width: '40%',
                        margin: '8px 0',
                        textAlign: 'center',
                      }}
                      rules={[{ required: true, message: '请输入' }]}
                    >
                      <Input
                        style={{
                          width: '80%',
                          paddingRight: 0,
                          textAlign: 'center',
                        }}
                      ></Input>
                    </Form.Item>
                    <Col
                      style={{
                        width: '20%',
                        margin: '10px 0',
                      }}
                    >
                      <a
                        onClick={() => {
                          this.deletServiceClass(item);
                        }}
                      >
                        删除
                      </a>
                    </Col>
                  </Row>
                </List.Item>
              )}
            ></List>
          </Modal>
        </Form>
      </>
    );
  }
}
export default PropertiesView;
