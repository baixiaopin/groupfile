export function randomString(e) {
  e = e || 32;
  var t = '0123456789',
    a = t.length,
    n = '';
  for (let i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * a));
  return n;
}

// 判断数组中是否有 这个属性返回有多少个 没有返回-1
export function find(array, attr, val) {
  for (var i = 0; i < array.length; i++) {
    if (array[i][attr] == val) {
      return i;
    }
  }
  return -1;
}

//  数组按类型分类，分为两种监听器
export function groupBy(arr, property) {
  return arr.reduce(function (memo, x) {
    if (!memo[x[property]]) {
      memo[x[property]] = [];
    }
    memo[x[property]].push(x);
    return memo;
  }, {});
}
// 处理函数，将对象变数组
export function objectVariableArray(array) {
  let arr = [];
  for (var key in array) {
    let temp = {};
    temp.name = key;
    temp.value = array[key];
    arr.push(temp);
  }
  let map = {};
  let dest = [];
  for (var i = 0; i < arr.length; i++) {
    let ai = arr[i];

    if (!map[ai.name.replace(/[^0-9]/gi, '')]) {
      dest.push({
        name: ai.name,
        value: ai.value,
        data: [ai],
      });
      map[ai.name.replace(/[^0-9]/gi, '')] = ai;
    } else {
      for (var j = 0; j < dest.length; j++) {
        let dj = dest[j];
        if (
          dj.name.replace(/[^0-9]/gi, '') == ai.name.replace(/[^0-9]/gi, '')
        ) {
          dj.data.push(ai);
          break;
        }
      }
    }
  }
  return dest;
}
