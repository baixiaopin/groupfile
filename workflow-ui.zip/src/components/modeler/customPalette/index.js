/*
 * @功能：自定义左侧面板
 */
// 定义左侧工具栏
import PaletteModule from './palette';
// 定义元素
import CustomPalette from './CustomPalette';

export default {
  __depends__: [PaletteModule],
  __init__: ['paletteProvider'],
  paletteProvider: ['type', CustomPalette],
};
