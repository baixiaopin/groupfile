import Palette from './Palette';

export default {
  __init__: ['palette'],
  palette: ['type', Palette],
};
