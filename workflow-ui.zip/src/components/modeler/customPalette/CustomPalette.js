// @ts-nocheck
import { assign } from 'min-dash';

/**
 * A palette that allows you to create BPMN _and_ custom elements.
 * 定义左侧具体的元素
 */
export default class CustomPalette {
  constructor(
    palette,
    create,
    elementFactory,
    spaceTool,
    lassoTool,
    handTool,
    globalConnect,
    translate,
  ) {
    this.create = create;
    this.elementFactory = elementFactory;
    this.spaceTool = spaceTool;
    this.lassoTool = lassoTool;
    this.handTool = handTool;
    this.globalConnect = globalConnect;
    this.translate = translate;
    // 指定这是一个palette
    palette.registerProvider(this);
  }

  // 这个函数就是绘制palette的核心，函数的名称
  getPaletteEntries = () => {
    const actions = [];
    const {
      create,
      elementFactory,
      translate,
      spaceTool,
      lassoTool,
      handTool,
      globalConnect,
    } = this;
    // 创建action
    function createAction(type, group, className, title, options, customType) {
      function createListener(event) {
        const shape = elementFactory.createShape(
          assign({ type }, options, { customType }),
        );
        // options 参数 判断是否含有这个参数，图形大小和形状
        console.log(type, group, className, title, options, customType);
        if (options) {
          shape.businessObject.di.isExpanded = options;
          // 直接修改图形的大小
          shape.width = 360;
          shape.height = 210;
        }
        // 创建节点的时候默认开始和结束名称
        if (shape.type == 'bpmn:EndEvent') {
          shape.businessObject.name = '结束';
        }
        if (shape.type == 'bpmn:StartEvent') {
          shape.businessObject.name = '开始';
        }
        create.start(event, shape);
      }

      const shortType = type.replace(/^bpmn:/, '');
      const action = {
        group,
        className,
        title: (title && translate(title)) || translate(`Create ${shortType}`),
        action: {
          dragstart: createListener,
          click: createListener,
        },
      };
      return action;
    }
    // 定义左侧pakette图标定义
    assign(actions, [
      {
        title: translate('Tools'),
        group: 'tools',
        children: [
          {
            id: 'hand-tool',
            group: 'tools',
            className: 'bpmn-icon-hand-tool',
            title: translate('Activate the hand tool'),
            action: {
              click: (event) => {
                handTool.activateHand(event);
              },
            },
          },

          {
            id: 'lasso-tool',
            group: 'tools',
            className: 'bpmn-icon-lasso-tool',
            title: translate('Activate the lasso tool'),
            action: {
              click: (event) => {
                lassoTool.activateSelection(event);
              },
            },
          },
          {
            id: 'space-tool',
            group: 'tools',
            className: 'bpmn-icon-space-tool',
            title: translate('Activate the create/remove space tool'),
            action: {
              click: (event) => {
                spaceTool.activateSelection(event);
              },
            },
          },
          {
            id: 'global-connect-tool',
            group: 'tools',
            className: 'bpmn-icon-connection-multi',
            title: translate('Activate the global connect tool'),
            action: {
              // click: (event) => {
              //   globalConnect.toggle(event);
              // },
            },
          },
        ],
      },
      {
        title: translate('FlowGateway'),
        group: 'flowGateway',
        children: [
          {
            id: 'create.exclusive-gateway',
            ...createAction(
              'bpmn:ExclusiveGateway',
              'gateway',
              'bpmn-icon-gateway-xor',
            ),
          },

          {
            id: 'create.parallel-gateway',
            ...createAction(
              'bpmn:ParallelGateway',
              'gateway',
              'bpmn-icon-gateway-parallel',
            ),
          },
          {
            id: 'create.inclusive-gateway',
            ...createAction(
              'bpmn:InclusiveGateway',
              'gateway',
              'bpmn-icon-gateway-or',
            ),
          },
        ],
      },
      {
        title: translate('ProcessControl'),
        group: 'processControl',
        children: [
          {
            id: 'create.start-event',
            ...createAction(
              'bpmn:StartEvent',
              'event',
              'bpmn-icon-start-event-none',
            ),
          },
          {
            id: 'create.user-task',
            ...createAction('bpmn:UserTask', 'activity', 'bpmn-icon-user-task'),
          },
          {
            id: 'create.service-task',
            ...createAction(
              'bpmn:ServiceTask',
              'activity',
              'bpmn-icon-service-task',
            ),
          },
          {
            id: 'create.manual-task',
            ...createAction(
              'bpmn:ManualTask',
              'activity',
              'bpmn-icon-manual-task',
            ),
          },
          {
            id: 'create.receive-task',
            ...createAction(
              'bpmn:ReceiveTask',
              'activity',
              'bpmn-icon-receive-task',
            ),
          },
          {
            id: 'create.intermediate-event-none',
            ...createAction(
              'bpmn:IntermediateThrowEvent',
              'event',
              'bpmn-icon-intermediate-event-none',
            ),
          },

          {
            id: 'create.end-event',
            ...createAction(
              'bpmn:EndEvent',
              'event',
              'bpmn-icon-end-event-none',
            ),
          },
        ],
      },
      // 添加自定义节点
      {
        title: translate('CustomElement'),
        group: 'customElement',
        children: [
          {
            id: 'create.subprocess-expanded',
            ...createAction(
              'bpmn:SubProcess',
              'activity',
              'bpmn-icon-subprocess-expanded',
              '',
              'true',
            ),
          },
          {
            id: 'create.transaction',
            ...createAction(
              'bpmn:Transaction',
              'event',
              'bpmn-icon-transaction',
              '',
              'true',
            ),
          },
          {
            id: 'create.group',
            ...createAction('bpmn:Group', 'event', 'bpmn-icon-group'),
          },
        ],
      },
    ]);
    return actions;
  };
}

// 使用$inject注入一些需要的变量

CustomPalette.$inject = [
  'palette',
  'create',
  'elementFactory',
  'spaceTool',
  'lassoTool',
  'handTool',
  'globalConnect',
  'translate',
];
