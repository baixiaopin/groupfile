import request from '../../utils/request';

// 指定用户 候选人
export function getListOrgTrees(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'OrgManagementSVC',
        stdIntfcInd: 'getListOrgTrees',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 指定用户table
export function listUserByOrg(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'UserManagementSVC',
        stdIntfcInd: 'listUserByOrg',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 角色
export function roleType(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'RoleManagementSVC',
        stdIntfcInd: 'roleType',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 角色人员
export function listRole(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'RoleManagementSVC',
        stdIntfcInd: 'listRole',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 岗位和部门一样
export function getOrgAndOrgGruopTrees(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'OrgManagementSVC',
        stdIntfcInd: 'getOrgAndOrgGruopTrees',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 部门table
export function getOrgAndChildOrg(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'OrgManagementSVC',
        stdIntfcInd: 'getOrgAndChildOrg',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 岗位table
export function listPosition(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'PositionManagementSVC',
        stdIntfcInd: 'listPosition',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

export function listOrgGroupByOrgId(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'listOrgGroupByOrgId',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 查询回显
export function getInfosByIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'getInfosByIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 角色人员
export function getRoleByOrgId(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'RoleManagementSVC',
        stdIntfcInd: 'getRoleByOrgId',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 查询回显
export function getNamesByIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'getNamesByIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
// 用户组table

// 组织架构树用户查询
