import React, { Component } from 'react';
import {
  FcButton as Button,
  FcTag as Tag,
  FcCard as Card,
  FcSwitch as Switch,
  FcDivider as Divider,
  FcTabs as Tabs,
  FcForm as Form,
  FcInput as Input,
  FcTable as Table,
  FcSelect as Select,
  FcCollapse as Collapse,
  FcRow as Row,
  FcCol as Col,
  FcSkeleton as Skeleton,
  FcModal as Modal,
  FcList as List,
  FcBadge as Badge,
  FcTooltip as Tooltip,
  FcMessage as message,
  FcInputNumber,
} from '@ngfed/fc-components';
// import { Modal } from 'antd';
import StyleSheet from './index.less';
const { Panel } = Collapse;
import { getInfosByIds } from './service';
import {
  groupBy,
  find,
  objectVariableArray,
} from '../modeler/customPanel/function';
import OrgTreeModal from '../../pages/OrgTreeModal';
import OrgTreeGroup from '../../pages/OrgTreeGroup';
import OrgLimit from '../orgLimit';
import PostAndRoleLimit from '../postAndRoleLimit';
class UserTask extends Component {
  userTaskSettingRef = React.createRef();
  taskMonitor = React.createRef(); // 任务监听器
  executeMonitor = React.createRef(); // 执行监听器
  state = {
    currentElement: null, // 当前节点
    modeler: null, // 设计器源
    executeNum: 0, // 执行监听器数量
    taskNum: 0, // 任务监听器数量
    selectType: 'user', // 组织架构树选中类型
    throughStrategy: 'per', // 通过策略变量
    peopleList: [],
    // 处理人model框 peopleList回显的数组  delegateList组织架构树返回的选中人员id
    selectUserVisible: false,
    // 人员限定
    personnelLimit: false,
    // 用户组
    selectGroupVisible: false,
    selectGroup: '',
    selectGroupType: '',
    selectGroupTemp: '',
    selectGroupName: [],
    // 执行监听器model框 执行监听器列表，任务监听器列表
    executionListenersModalVisible: false,
    executionListenersList: [],
    taskListenersList: [],
    delegateList: [],
    // 添加执行监听器
    addExecuteList: [],
    // 添加任务监听器
    addTaskList: [],
    // 人员变量限定 机构、岗位和角色
    candidateUserVarOrgVisible: false,
    candidateUserVarPostAndRoleVisible: false,
    candidateUserVarType: '',
    candidateUserVarRoleTemp: [],
    candidateUserVarPostTemp: [],
    candidateUserVarOrgTemp: [],
    candidateUserVarOrgName: [],
    candidateUserVarPostName: [],
    candidateUserVarRoleName: [],
    // 会签方式
    executionMethod: '',
    // 用户权重
    userOvg: '',
    // 是否级联
    isCacscade: false,
    processContinuationListener: false,
  };

  componentWillMount() {
    const selectedElement = this.props.currentElement;
    this.setState({
      currentElement: selectedElement,
      modeler: this.props.modeler,
    });
  }

  /**
   *
   * @returns 根据不同的任务类型，回显节点的详情
   */
  componentDidMount() {
    const selectedElement = this.props.currentElement;
    console.log(selectedElement);
    // 回显用户任务
    if (selectedElement && selectedElement.type === 'bpmn:UserTask') {
      // 回显用户组
      if (selectedElement.businessObject.candidateGroups) {
        let newArry = selectedElement.businessObject.candidateGroups.split(',');
        let arr = [];
        newArry.map((item) => {
          if (item.indexOf('$') == 0) {
            this.setState({
              personnelLimit: true,
              selectGroupName: [item],
              selectGroupType: 'candidateGroupVar',
            });
          }
          if (item.indexOf('$') != 0) {
            getInfosByIds({
              ids: item
                .replaceAll('d:', '03,')
                .replaceAll('r:', '01,')
                .replaceAll('p:', '02,'),
            }).then((res) => {
              const result = res?.body?.infosByIds
                ? res?.body?.infosByIds
                : res.body;
              if (item.includes('d:')) {
                result.type = '03';
              }
              if (item.includes('r:')) {
                result.type = '01';
              }
              if (item.includes('p:')) {
                result.type = '02';
              }
              arr = arr.concat(result);
              this.setState({
                selectGroupName: arr,
                selectGroup: selectedElement.businessObject.candidateGroups,
              });
            });
          }
        });
      } else {
        this.setState({ selectGroupName: [] });
      }
      //  如果extensionElements存在，显示监听器的数量
      if (selectedElement.businessObject.extensionElements) {
        // 调用echoMonitor回显监听器
        this.echoMonitor();
        this.taskListenersAndExecListerers();
        // 将监听器里的 人员限定分开
        let extPropertyType = groupBy(
          selectedElement.businessObject.extensionElements.values,
          'type',
        );
        // 流程续跑
        if (extPropertyType.service) {
          this.setState({ processContinuationListener: true });
          this.userTaskSettingRef.current.setFieldsValue({
            processContinuationListener: true,
          });
        }
        // 是否审委会 isCommittee
        if (extPropertyType.isCommittee) {
          this.setState({
            isCommittee: extPropertyType.isCommittee[0].variable,
          });
          this.userTaskSettingRef.current.setFieldsValue({
            isCommittee: extPropertyType.isCommittee[0].variable,
          });
        }
        // 机构
        if (extPropertyType.departmentIds) {
          this.departmentIds(extPropertyType.departmentIds[0].variable);
        } else {
          this.setState({
            candidateUserVarOrgName: [],
          });
        }
        // 岗位
        if (extPropertyType.postIds) {
          this.postIdsName(extPropertyType.postIds[0].variable);
        } else {
          this.setState({
            candidateUserVarPostName: [],
          });
        }
        // 角色
        if (extPropertyType.roleIds) {
          this.roleIds(extPropertyType.roleIds[0].variable);
        } else {
          this.setState({
            candidateUserVarRoleName: [],
          });
        }
        // url地址
        if (extPropertyType.url) {
          this.userTaskSettingRef.current.setFieldsValue({
            urlAddress: extPropertyType.url[0].variable,
          });
        } else {
          this.userTaskSettingRef.current.setFieldsValue({
            urlAddress: '',
          });
        }
        // 人员认领限制
        if (extPropertyType.claimLimit) {
          this.userTaskSettingRef.current.setFieldsValue({
            claimLimit: extPropertyType.claimLimit[0].variable,
          });
        } else {
          this.userTaskSettingRef.current.setFieldsValue({
            claimLimit: '',
          });
        }
        // 是否级联 isCacscade
        console.log(extPropertyType);
        if (extPropertyType.isCacscade) {
          this.setState({
            isCacscade: extPropertyType.isCacscade[0].variable ? true : false,
          });
        }
      }

      // 如果不存在监听器，就清空
      if (!selectedElement.businessObject.extensionElements) {
        this.setState({
          executeNum: 0,
          taskNum: 0,
          executionListenersList: [],
          taskListenersList: [],
          addTaskList: [],
          addExecuteList: [],
          candidateUserVarOrgName: [],
          candidateUserVarPostName: [],
          candidateUserVarRoleName: [],
        });
        this.executeMonitor.current.resetFields();
        this.taskMonitor.current.resetFields();
        this.userTaskSettingRef.current.resetFields();
      }
      // 回显会签信息
      const loopCharacteristics =
        selectedElement.businessObject.loopCharacteristics;
      if (loopCharacteristics) {
        // 用split将比例表达式以=分割开为两部分
        let splitString =
          loopCharacteristics.completionCondition?.body != undefined
            ? loopCharacteristics.completionCondition?.body.split('=')
            : [];
        // 赋值给userTaskSettingRef表单,通过策略有两种方式，这里用三元表达式区分开
        this.userTaskSettingRef.current.setFieldsValue({
          type:
            splitString[0] ==
            '${multiInstCompleteCondition.passWithProportion(execution)>'
              ? 'per'
              : splitString[0] ==
                '${multiInstWeightCompleteCondition.passWithProportion(execution)>'
              ? 'avg'
              : splitString[0] ==
                '${multiInstanceDirectorCompleteCondition.passWithProportion(execution)>'
              ? 'per'
              : 'expression',

          proportion:
            splitString.length == 2 ? splitString[1].replace('}', '') : '',
          expression:
            splitString[0] ==
            '${multiInstCompleteCondition.passWithProportion(execution)>'
              ? ''
              : splitString[0] ==
                '${multiInstanceDirectorCompleteCondition.passWithProportion(execution)>'
              ? ''
              : loopCharacteristics.completionCondition?.body,
          // splitString[1].replace('}', '')
          executionMethod: String(loopCharacteristics.isSequential),
        });
        console.log(splitString);
        this.setState({
          executionMethod: 'true',
          throughStrategy:
            splitString[0] ==
            '${multiInstCompleteCondition.passWithProportion(execution)>'
              ? 'per'
              : splitString[0] ==
                '${multiInstWeightCompleteCondition.passWithProportion(execution)>'
              ? 'avg'
              : splitString[0] ==
                '${multiInstanceDirectorCompleteCondition.passWithProportion(execution)>'
              ? 'per'
              : 'expression',
        });
      } else {
        this.userTaskSettingRef.current.setFieldsValue({
          type: '',
          proportion: '',
          executionMethod: '',
          avg: '',
        });
        this.setState({ throughStrategy: '' });
      }
      // 回显人员类型 + 指定人员/候选人员/候选组
      const attrs = selectedElement.businessObject.$attrs;
      // 正则表达式取括号里面的内容
      const reg = /\"(.*)\"/;
      if (attrs['flowable:assignee']) {
        // 判断是否会签人员，是会签的人员，去除双引号，否侧就取[attrs['flowable:assignee']]的值

        const temp =
          selectedElement.businessObject.loopCharacteristics != undefined &&
          selectedElement.businessObject?.loopCharacteristics?.collection?.match(
            reg,
          )
            ? [
                selectedElement.businessObject.loopCharacteristics.collection
                  .match(reg)[0]
                  .replace(/"/g, ''),
              ]
            : [attrs['flowable:assignee']];

        const assignTemp = temp[0].split(',execution');
        if (assignTemp[0] != ',' && temp[0] != '${assignee}') {
          // 用户权重
          const userOvg = temp[0].split(',execution,');
          // 调用方法回显审核人
          // 判断选择处理人的类型
          if (assignTemp[0].indexOf('$') == 0) {
            this.setState({ selectType: 'userVar' }, () => {
              this.getInfosByIds(assignTemp[0]);
            });
          } else {
            this.setState({ selectType: 'user', userOvg: userOvg[1] }, () => {
              this.getInfosByIds(assignTemp[0]);
            });
          }
        }
        // 判断会签回显collection里面的
        if (
          assignTemp[0] == '${assignee}' &&
          selectedElement.businessObject.loopCharacteristics?.collection
        ) {
          this.setState({ selectType: 'assignee' }, () => {
            this.getInfosByIds(
              selectedElement.businessObject.loopCharacteristics.collection,
            );
          });
        }
      }
      // 回显放在flowable:candidateUsers标签的用户 候选用户、候选机构等
      if (attrs['flowable:candidateUsers']) {
        const tempPeople =
          [attrs['flowable:candidateUsers'].match(reg)][0] == null
            ? attrs['flowable:candidateUsers']
            : attrs['flowable:candidateUsers'].match(reg)[0].replace(/"/g, '');
        // 调用方法回显审核人

        if (tempPeople.indexOf('$') == 0) {
          this.setState({ selectType: 'candidateUserVar' }, () => {
            this.getInfosByIds(tempPeople);
          });
        } else {
          this.setState({ selectType: 'candidateUsers' }, () => {
            this.getInfosByIds(tempPeople);
          });
        }
      }
      // 清除审核人员显示
      if (!attrs['flowable:assignee'] && !attrs['flowable:candidateUsers']) {
        this.setState({
          delegateList: [],
          peopleList: [],
          candidateUsers: '',
          selectType: '',
        });
      }

      return;
    }
  }
  // 设置固定的两个监听器
  setListenerList = () => {
    const executionListenersList = [
      {
        data: [
          { name: 'event0', value: 'start' },
          { name: 'type0', value: 'delegateExpression' },
          { name: 'value0', value: '${multiExecutionListener}' },
        ],
        name: 'event0',
        value: 'start',
      },
    ];
    const taskListenersList = [
      {
        data: [
          { name: 'event0', value: 'complete' },
          { name: 'type0', value: 'delegateExpression' },
          {
            name: 'value0',
            value:
              this.state.throughStrategy == 'avg'
                ? '${multiWeightTaskListener}'
                : this.state.isCommittee
                ? '${multiDirectorTaskListener}'
                : '${multiTaskListener}',
          },
        ],
        name: 'event0',
        value: 'complete',
      },
    ];
    this.setState({ executionListenersList, taskListenersList });
  };
  // 设置固定的两个监听器之执行监听器
  setListenerListExecuteDest = () => {
    return [
      {
        data: [
          { name: 'event0', value: 'start' },
          { name: 'type0', value: 'delegateExpression' },
          { name: 'value0', value: '${multiExecutionListener}' },
        ],
        name: 'event0',
        value: 'start',
      },
    ];
  };
  // 设置固定的两个监听器之任务监听器
  setListenerLisTaskDest = () => {
    return [
      {
        data: [
          { name: 'event0', value: 'complete' },
          { name: 'type0', value: 'delegateExpression' },
          {
            name: 'value0',
            value:
              this.state.throughStrategy == 'avg'
                ? '${multiWeightTaskListener}'
                : this.state.isCommittee
                ? '${multiDirectorTaskListener}'
                : '${multiTaskListener}',
          },
        ],
        name: 'event0',
        value: 'complete',
      },
    ];
  };

  // 保存用户任务基础设置
  saveUserTaskSetting = () => {
    console.log('保存');
    const settings = this.userTaskSettingRef.current.getFieldsValue();
    const {
      executionListenersList,
      taskListenersList,
      isCommittee,
    } = this.state;

    // 判断是否是变量，控制是否显示人员限定
    if (
      this.state.selectType == 'userVar' ||
      this.state.selectType == 'candidateUserVar' ||
      this.state.selectGroupType == 'candidateGroupVar'
    ) {
      this.setState({ personnelLimit: true });
    }
    //  去掉百分号%
    settings.proportion =
      settings.proportion != undefined
        ? settings.proportion.replace(/%/, '')
        : undefined;
    // 判断处理人取code还是id字段
    // 人员类型标识
    let cardSign = '';
    // 新的处理人数组
    let newDelegateList = [];
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'candidateUsers'
    ) {
      cardSign = '00';
      newDelegateList = this.state.delegateList.map((obj) => {
        return obj.id;
      });
    } else {
      if (this.state.selectType == 'role') {
        cardSign = '01';
        newDelegateList = this.state.delegateList.map((obj) => {
          return obj.id;
        });
      }
      if (this.state.selectType == 'post') {
        cardSign = '02';
        newDelegateList = this.state.delegateList.map((obj) => {
          return obj.id;
        });
      }
      if (this.state.selectType == 'org') {
        cardSign = '03';
        newDelegateList = this.state.delegateList.map((obj) => {
          return obj.id;
        });
      }
      if (
        this.state.selectType == 'userVar' ||
        (this.state.selectType == 'candidateUserVar' &&
          this.state.delegateList.length > 0)
      ) {
        newDelegateList = [this.state.delegateList];
        cardSign = '';
      }
    }

    const newList = {};
    // 用户组
    if ([this.state.selectGroup].length > 0) {
      newList.candidateGroups = this.state.selectGroup.toString();
    }
    // 判断是否是会签 是的就更改asignee属性为${assignee}
    if (newDelegateList.length > 0) {
      if (this.state.currentElement.businessObject.loopCharacteristics) {
        newList.assignee = '${assignee}';
      } else {
        if (this.state.selectType == 'user') {
          delete newList.candidateUsers;
          newList.assignee = newDelegateList;
        }
        if (this.state.selectType == 'candidateUsers') {
          // delete this.state.currentElement.businessObject.$attrs[
          //   `flowable:assignee`
          // ];
          newList.candidateUsers = newDelegateList;
          this.setState({ peopleList: newDelegateList });
        }
        if (this.state.selectType == 'userVar') {
          newList.assignee = this.state.delegateList;
          newList.formFieldValidation = true;
          delete newList.candidateUsers;
        }
        if (this.state.selectType == 'candidateUserVar') {
          newList.candidateUsers = this.state.delegateList;
          newList.formFieldValidation = true;
          delete newList.assignee;
        }
        // 如果审核人存在就回显审核人名字
        if (
          this.state.selectType == 'candidateUserVar' ||
          this.state.selectType == 'userVar' ||
          this.state.selectType == 'user' ||
          this.state.selectType == 'candidateUsers'
        ) {
          if (newDelegateList.toString() != '') {
            this.getInfosByIds(newDelegateList.toString());
          }
        }
        // 候选人 指定用户，角色，岗位，机构
        if (this.state.selectType == 'candidateUsers') {
          newList.candidateUsers = newDelegateList;
        }
        if (this.state.selectType == 'role') {
          // 05 角色
          newList.candidateUsers = `'$'{workflowArrays.parseAssignees('"05","${newDelegateList.toString()}"')}'`.replace(
            /'/g,
            '',
          );
        }
        if (this.state.selectType == 'post') {
          // 06 岗位
          newList.candidateUsers = `'$'{workflowArrays.parseAssignees('"06","${newDelegateList.toString()}"')}'`.replace(
            /'/g,
            '',
          );
        }
        if (this.state.selectType == 'org') {
          // 07 机构
          newList.candidateUsers = `'$'{workflowArrays.parseAssignees('"07","${newDelegateList.toString()}"')}'`.replace(
            /'/g,
            '',
          );
        }
        if (
          this.state.selectType == 'post' ||
          this.state.selectType == 'org' ||
          this.state.selectType == 'role'
        ) {
          // 正则表达式取括号里面的内容
          const reg = /\"(.*)\"/;
          const temp = [newList.candidateUsers.match(reg)[0].replace(/"/g, '')];
          // 判断审核人是否为空，然后回显审核人名字
          if (temp[0] != ',') {
            this.getInfosByIds(temp[0]);
          }
        }
      }
    }

    // 删除多余属性
    if (
      this.state.selectType == 'user' ||
      this.state.selectType == 'assignee' ||
      this.state.selectType == 'userVar'
    ) {
      delete this.state.currentElement.businessObject.$attrs[
        `flowable:candidateUsers`
      ];
    }
    if (
      this.state.selectType == 'candidateUsers' ||
      this.state.selectType == 'post' ||
      this.state.selectType == 'org' ||
      this.state.selectType == 'role' ||
      this.state.selectType == 'candidateUserVar'
    ) {
      if (!this.state.currentElement.businessObject.loopCharacteristics) {
        delete this.state.currentElement.businessObject.$attrs[
          `flowable:assignee`
        ];
      }
    }
    if (
      this.state.selectType == 'candidateUsers' &&
      this.state.currentElement.businessObject.loopCharacteristics
    ) {
      delete this.state.currentElement.businessObject.$attrs[
        `flowable:candidateUsers`
      ];
    }
    // 克隆数组，删除多余的属性
    const userTaskNodeInfoFormClone = JSON.parse(JSON.stringify(newList));
    delete userTaskNodeInfoFormClone.name;
    delete userTaskNodeInfoFormClone.taskListeners;
    delete userTaskNodeInfoFormClone.executionListeners;
    const properties = {};
    // 循环生成属性
    for (const key in userTaskNodeInfoFormClone) {
      // 判断自身是否有这个属性
      if (userTaskNodeInfoFormClone.hasOwnProperty(key)) {
        const value = userTaskNodeInfoFormClone[key];
        if (value.length !== 0) {
          properties[`flowable:${key}`] = Array.isArray(value)
            ? value.toString()
            : value;
        }
      }
    }

    // 判断当前节点是否有这个节点属性，没有就创建这个节点属性
    let extensionElements = this.state.currentElement.businessObject.get(
      'extensionElements',
    );
    if (!extensionElements) {
      extensionElements = this.props.modeler
        .get('moddle')
        .create('bpmn:ExtensionElements', {
          values: [],
        });
    }
    // 创建固定的两个监听器
    let multiExecution1 = this.props.modeler
      .get('moddle')
      .create('flowable:ExecutionListener', {
        delegateExpression: '${multiExecutionListener}',
        event: 'start',
      });
    let multiExecution2 = this.props.modeler
      .get('moddle')
      .create('flowable:TaskListener', {
        delegateExpression: this.state.isCommittee
          ? '${multiDirectorTaskListener}'
          : '${multiTaskListener}',
        event: 'complete',
      });
    // 创建会签节点
    let loopCharacteristics = this.state.currentElement.businessObject.get(
      'loopCharacteristics',
    );
    if (!loopCharacteristics) {
      loopCharacteristics = this.props.modeler
        .get('moddle')
        .create('bpmn:MultiInstanceLoopCharacteristics', {
          collection:
            this.state.throughStrategy == 'avg'
              ? `'$'{workflowArrays.parseAssignees('"${cardSign}","${newDelegateList.toString()}",execution,"${
                  this.state.userOvg
                }"')}'`.replace(/'/g, '')
              : `'$'{workflowArrays.parseAssignees('"${cardSign}","${newDelegateList.toString()}"')}'`.replace(
                  /'/g,
                  '',
                ),
          elementVariable: 'assignee',
          isSequential: settings.executionMethod == 'true' ? true : false,
        });
    }
    let completionCondition = this.state.currentElement.businessObject.get(
      'completionCondition',
    );
    if (!completionCondition) {
      completionCondition = this.props.modeler
        .get('moddle')
        .create('bpmn:Expression', {
          body:
            this.state.throughStrategy == 'avg'
              ? `'$'{multiInstWeightCompleteCondition.passWithProportion(execution)>=${settings.proportion}'}'`.replace(
                  /'/g,
                  '',
                )
              : this.state.throughStrategy == 'per' && this.state.isCommittee
              ? `'$'{multiInstanceDirectorCompleteCondition.passWithProportion(execution)>=${settings.proportion}'}'`.replace(
                  /'/g,
                  '',
                )
              : this.state.throughStrategy == 'per' && !this.state.isCommittee
              ? `'$'{multiInstCompleteCondition.passWithProportion(execution)>=${settings.proportion}'}'`.replace(
                  /'/g,
                  '',
                )
              : settings.expression,
        });
    }
    this.updateProperties({ extensionElements: extensionElements });
    //  获取任务监听器和执行监听器form表单的值
    let executeListeners = this.executeMonitor.current.getFieldsValue();
    let taskListeners = this.taskMonitor.current.getFieldsValue();
    // 处理form表单的值，引入objectVariableArray监听器处理函数，对象变数组，清除监听器
    let executeDest = objectVariableArray(executeListeners);
    let taskDest = objectVariableArray(taskListeners);
    if (
      this.state.isCommittee &&
      executeDest.length == 0 &&
      taskDest.length == 0 &&
      settings.type != 'expression'
    ) {
      executeDest = executionListenersList;
      taskDest = taskListenersList;
    }
    if (
      settings.executionMethod &&
      executeDest.length == 0 &&
      taskDest.length == 0 &&
      settings.type != 'expression'
    ) {
      executeDest = this.setListenerListExecuteDest();
      taskDest = this.setListenerLisTaskDest();
    }
    // 自动保存后，判断获取到的监听器表单数组
    if (
      executeDest.length == 0 &&
      taskDest.length == 0 &&
      this.state.currentElement.businessObject.extensionElements.values
    ) {
      this.state.currentElement.businessObject.extensionElements.values = [];
      this.setState({
        taskListenersList: [],
        addExecuteList: [],
        addTaskList: [],
        executionListenersList: [],
      });
    }
    // 判断会签标签是否存在 executionMethod
    if (
      !this.state.currentElement.businessObject.loopCharacteristics &&
      settings.executionMethod
    ) {
      loopCharacteristics.completionCondition = completionCondition;
      // 设置会签就清除审核人
      delete this.state.currentElement.businessObject.$attrs[
        'flowable:assignee'
      ];
      this.state.peopleListDel = 'delAll';
      console.log(settings);
      // 添加两条固定监听器,表达式通过除外 不加

      this.setState({
        executionMethod: settings.executionMethod,
        peopleList: [],
      });

      this.updateProperties({ loopCharacteristics: loopCharacteristics });
    } else {
      if (
        this.state.throughStrategy == 'per' &&
        this.state.executionListenersList.length == 0 &&
        this.state.taskListenersList.length == 0
      ) {
        this.setListenerList();
      }
      // 存在就更新值
      if (this.state.currentElement.businessObject.loopCharacteristics) {
        // 判断是否要跟新会签人 回显审核人
        if (
          cardSign != '' &&
          newDelegateList.length > 0 &&
          settings.executionMethod != ''
        ) {
          this.getInfosByIds(`${cardSign},${newDelegateList.toString()}`);
        }
        if (!newDelegateList.length == 0) {
          if (this.state.throughStrategy == 'avg') {
            loopCharacteristics.collection = `'$'{workflowArrays.parseAssignees('"${cardSign}","${newDelegateList.toString()}",execution,"${
              this.state.userOvg
            }"')}'`.replace(/'/g, '');
          } else {
            loopCharacteristics.collection = `'$'{workflowArrays.parseAssignees('"${cardSign}","${newDelegateList.toString()}"')}'`.replace(
              /'/g,
              '',
            );
          }
        }

        loopCharacteristics.elementVariable = 'assignee';
        loopCharacteristics.completionCondition = completionCondition;
        (loopCharacteristics.completionCondition.body =
          this.state.throughStrategy == 'avg'
            ? `'$'{multiInstWeightCompleteCondition.passWithProportion(execution)>=${settings.proportion}'}'`.replace(
                /'/g,
                '',
              )
            : this.state.throughStrategy == 'per' && !this.state.isCommittee
            ? `'$'{multiInstCompleteCondition.passWithProportion(execution)>=${settings.proportion}'}'`.replace(
                /'/g,
                '',
              )
            : this.state.isCommittee && this.state.throughStrategy == 'per'
            ? `'$'{multiInstanceDirectorCompleteCondition.passWithProportion(execution)>=${
                settings.expression ? settings.expression : settings.proportion
              }'}'`.replace(/'/g, '')
            : settings.expression),
          (loopCharacteristics.isSequential =
            settings.executionMethod == 'true' ? true : false);

        this.updateProperties({ loopCharacteristics: loopCharacteristics });
        // 取消会签
        if (settings.executionMethod == '') {
          delete this.state.currentElement.businessObject.loopCharacteristics;
          delete this.state.currentElement.businessObject.$attrs[
            'flowable:assignee'
          ];
          delete properties['flowable:assignee'];
          this.state.currentElement.businessObject.extensionElements.values = [];
          delete this.state.currentElement.businessObject.$attrs[
            'flowable:assignee'
          ];
          this.userTaskSettingRef.current.setFieldsValue({
            type: '',
            proportion: '',
            expression: '',
            isCommittee: false,
          });
          (this.state.executionListenersList = []),
            (this.state.taskListenersList = []);
          this.taskMonitor.current.resetFields();
          this.executeMonitor.current.resetFields();
          this.setState(
            {
              taskListenersList: [],
              addExecuteList: [],
              addTaskList: [],
              executionListenersList: [],
              peopleList: [],
              taskNum: '',
              executeNum: '',
              isCommittee: false,
            },
            () => {
              this.updateProperties(properties);
            },
          );
          return false;
        }
      }
      // 删除会签人
      if (this.state.peopleListDel == 'delAll') {
        loopCharacteristics.collection = `'$'{workflowArrays.parseAssignees('"",""')}'`;
        this.setState({ peopleListDel: '' });
      }
    }

    // 判断是否会签是变量
    if (
      this.state.selectType == 'userVar' &&
      this.state.currentElement.businessObject.loopCharacteristics &&
      this.state.currentElement.businessObject.loopCharacteristics.collection
    ) {
      this.state.currentElement.businessObject.loopCharacteristics.collection = this.state.delegateList.toString();
      this.setState({ peopleList: [this.state.delegateList] });
      this.getInfosByIds(this.state.delegateList);
      this.updateProperties({ loopCharacteristics: loopCharacteristics });
    }
    if (
      this.state.selectType == 'candidateUserVar' &&
      this.state.currentElement.businessObject.loopCharacteristics &&
      this.state.currentElement.businessObject.loopCharacteristics.collection
    ) {
      this.state.currentElement.businessObject.loopCharacteristics.collection = this.state.delegateList;
      this.setState({ peopleList: [this.state.delegateList] });
      this.getInfosByIds(this.state.delegateList);
      this.updateProperties({ loopCharacteristics: loopCharacteristics });
    }
    //判断是否有自定义监听器 任务监听器,限定人员
    // 清空监听器

    if (
      this.state.taskListenersList.length > 0 ||
      this.state.executionListenersList.length > 0 ||
      this.state.candidateUserVarPostName.length > 0 ||
      this.state.candidateUserVarRoleName.length > 0 ||
      this.state.candidateUserVarOrgName.length > 0 ||
      settings.urlAddress ||
      settings.claimLimit ||
      settings.type ||
      settings.processContinuationListener ||
      this.state.isCommittee
    ) {
      extensionElements.values = [];
      // 限定角色
      if (this.state.candidateUserVarRoleName.length > 0) {
        const newCandidateUserVar = this.state.candidateUserVarRoleName.map(
          (obj) => {
            return obj.id;
          },
        );
        let candidateUserVarRoleTemp = '';
        newCandidateUserVar.map((item) => {
          candidateUserVarRoleTemp = candidateUserVarRoleTemp + ',' + item;
        });
        let taskCandidateUsers = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'taskCandidateUsers',
            type: 'roleIds',
            variable: candidateUserVarRoleTemp.replace(',', ''),
          });
        extensionElements.values.push(taskCandidateUsers);
      }
      // 限定岗位
      if (this.state.candidateUserVarPostName.length > 0) {
        const newCandidateUserVar = this.state.candidateUserVarPostName.map(
          (obj) => {
            return obj.id;
          },
        );
        let candidateUserVarPostTemp = '';
        newCandidateUserVar.map((item) => {
          candidateUserVarPostTemp = candidateUserVarPostTemp + ',' + item;
        });
        let taskCandidateUsers = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'taskCandidateUsers',
            type: 'postIds',
            variable: candidateUserVarPostTemp.replace(',', ''),
          });
        extensionElements.values.push(taskCandidateUsers);
      }
      // 限定机构
      if (this.state.candidateUserVarOrgName.length > 0) {
        const newCandidateUserVar = this.state.candidateUserVarOrgName.map(
          (obj) => {
            return obj.id;
          },
        );
        let candidateUserVarOrgTemp = '';
        newCandidateUserVar.map((item) => {
          candidateUserVarOrgTemp = candidateUserVarOrgTemp + ',' + item;
        });
        let taskCandidateUsers = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'taskCandidateUsers',
            type: 'departmentIds',
            variable: candidateUserVarOrgTemp.replace(',', ''),
          });
        extensionElements.values.push(taskCandidateUsers);
      }
      // url地址
      if (settings.urlAddress) {
        let urlAddress = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'extProperty',
            type: 'url',
            variable: settings.urlAddress,
          });
        extensionElements.values.push(urlAddress);
      }
      // 人员认领限制
      if (settings.claimLimit) {
        let claimLimit = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'extProperty',
            type: 'claimLimit',
            variable: settings.claimLimit,
          });

        extensionElements.values.push(claimLimit);
      }
      // isCacscade设置是否级联
      const { isCacscade } = this.state;
      if (isCacscade) {
        let isCacscade = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'extProperty',
            type: 'isCacscade',
            variable: true,
          });
        extensionElements.values.push(isCacscade);
      }
      // 设置是否为审委会
      const { isCommittee } = this.state;
      if (isCommittee) {
        let isCommitteeList = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'taskType',
            type: 'isCommittee',
            variable: isCommittee ? true : false,
          });
        extensionElements.values.push(isCommitteeList);
      }

      if (settings.processContinuationListener) {
        let processContinuationListener = this.props.modeler
          .get('moddle')
          .create('flowable:FormProperty', {
            id: 'taskType',
            type: 'service',
            variable: true,
          });
        extensionElements.values.push(processContinuationListener);
      }

      // 创建执行监听器
      executeDest.forEach((item) => {
        const executeListener = this.props.modeler
          .get('moddle')
          .create('flowable:ExecutionListener');
        executeListener['event'] = item.data[0].value;
        executeListener[item.data[1].value] = item.data[2].value;
        extensionElements.get('values').push(executeListener);
      });

      //  创建任务监听器
      taskDest.forEach((item) => {
        const taskListener = this.props.modeler
          .get('moddle')
          .create('flowable:TaskListener');
        taskListener['event'] = item.data[0].value;
        taskListener[item.data[1].value] = item.data[2].value;
        extensionElements.get('values').push(taskListener);
      });
    }
    if (
      this.state.currentElement.businessObject.extensionElements &&
      this.state.currentElement.businessObject.extensionElements.values
    ) {
      // 如果存在就回显监听器-------------------------------------------------
      this.echoMonitor();
    }
    this.updateProperties({ extensionElements: extensionElements });
    // 清除处理组
    if (this.state.selectGroupTemp == 'delAll') {
      delete properties['flowable:candidateGroups'];
      delete this.state.currentElement.businessObject.candidateGroups;
      this.setState({ selectGroupTemp: '' });
    }
    if (this.state.peopleListDel == 'delAll') {
      delete properties['flowable:assignee'];
      delete this.state.currentElement.businessObject.$attrs[
        'flowable:assignee'
      ];
      delete properties['flowable:candidateUsers'];
      delete this.state.currentElement.businessObject.$attrs[
        'flowable:candidateUsers'
      ];
      this.setState({ peopleListDel: '' });
    }
    this.updateProperties(properties);
  };
  // 打开执行监听器对话框
  openExecutionListenersModal = () => {
    this.setState({ executionListenersModalVisible: true });
  };
  // 任务监听器
  openTaskListenersModal = () => {
    this.setState({
      taskListenersModalVisible: true,
    });
  };

  // 回显执行、用户任务监听器
  echoMonitor = () => {
    if (!this.state.currentElement.businessObject?.extensionElements) {
      return false;
    }
    let res = Object.values(
      this.state.currentElement.businessObject?.extensionElements?.values?.reduce(
        (a, { $type }) => {
          a[$type] = a[$type] || { $type, count: 0 };
          a[$type].count++;
          return a;
        },
        Object.create(null),
      ),
    );
    // 先清空表单值，在回显
    this.taskMonitor.current.resetFields();
    this.executeMonitor.current.resetFields();
    // 引入find方法根据类型和值分类，不存在就是-1

    const taskHave = find(res, '$type', 'flowable:TaskListener');
    if (taskHave === -1) {
      this.setState({ taskNum: 0 });
    } else {
      this.setState({ taskNum: res[taskHave].count });
    }

    const execHave = find(res, '$type', 'flowable:ExecutionListener');
    if (execHave === -1) {
      this.setState({ executeNum: 0 });
    } else {
      this.setState({ executeNum: res[execHave].count });
    }

    // 将监听器按类型分类
    let twoTypeMontaior = groupBy(
      this.state.currentElement.businessObject.extensionElements.values,
      '$type',
    );
    // 存在执行监听器
    if (twoTypeMontaior['flowable:ExecutionListener']) {
      // 回显监听器的数量
      this.setState({
        addExecuteList: twoTypeMontaior['flowable:ExecutionListener'],
      });
      // 调用executeMonitorEcho方法回显
      this.executeMonitorEcho(twoTypeMontaior['flowable:ExecutionListener']);
    } else {
      this.setState({ addExecuteList: [] });
    }
    // 存在任务监听器
    if (twoTypeMontaior['flowable:TaskListener']) {
      this.setState({
        addTaskList: twoTypeMontaior['flowable:TaskListener'],
      });
      // 调用taskMonitorEcho方法回显
      this.taskMonitorEcho(twoTypeMontaior['flowable:TaskListener']);
    } else {
      this.setState({ addTaskList: [] });
    }
  };

  // 回显执行监听器
  executeMonitorEcho = (e) => {
    let newExectueList = [];
    for (let k = 0; k < e.length; k++) {
      let newExectueList1 = {};
      newExectueList1['event' + k] = e[k].event;
      // 判断监听器属性是class，还是delegateExpression
      if (e[k].class) {
        newExectueList1['type' + k] = 'class';
        newExectueList1['value' + k] = e[k].class;
      }
      if (e[k].delegateExpression) {
        newExectueList1['value' + k] = e[k].delegateExpression;
        newExectueList1['type' + k] = 'delegateExpression';
      }
      newExectueList.push(newExectueList1);
    }
    //  将数组转化为对象并赋值给执行监听器的表单
    this.executeMonitor.current.setFieldsValue(
      Object.assign(...newExectueList),
    );
  };

  // 回显任务监听器
  taskMonitorEcho = (e) => {
    let newExectueList = [];
    for (let k = 0; k < e.length; k++) {
      let newExectueList1 = {};
      newExectueList1['event' + k] = e[k].event;
      // 判断监听器属性是class，expression还是delegateExpression
      if (e[k].class) {
        newExectueList1['type' + k] = 'class';
        newExectueList1['value' + k] = e[k].class;
      }
      if (e[k].delegateExpression) {
        newExectueList1['value' + k] = e[k].delegateExpression;
        newExectueList1['type' + k] = 'delegateExpression';
      }
      newExectueList.push(newExectueList1);
    }
    //  将数组转化为对象并赋值给表单
    this.taskMonitor.current.setFieldsValue(Object.assign(...newExectueList));
  };

  // 通过策略
  throughStrategy = (e) => {
    this.userTaskSettingRef.current.setFieldsValue({
      proportion: '',
      expression: '',
    });
    if (e == 'per') {
      this.taskMonitor.current?.setFieldsValue({
        event0: 'complete',
        type0: 'delegateExpression',
        value0: this.state.isCommittee
          ? '${multiDirectorTaskListener}'
          : '${multiTaskListener}',
      });
    }
    if (e == 'avg') {
      this.taskMonitor.current?.setFieldsValue({
        event0: 'complete',
        type0: 'delegateExpression',
        value0: '${multiWeightTaskListener}',
      });
    }
    if (e == 'expression') {
      this.executeMonitor.current.resetFields();
      this.taskMonitor.current.getFieldsValue();
      this.setState({
        taskListenersList: [],
        addExecuteList: [],
        addTaskList: [],
        executionListenersList: [],
        taskNum: '',
        executeNum: '',
      });
    }
    this.setState({ throughStrategy: e }, () => {
      this.saveUserTaskSetting();
    });
  };

  // 处理人选择
  selectUser = () => {
    this.setState({
      selectUserVisible: true,
      delegateList: [],
    });
  };

  // 清空限定人员 、用户组
  delHandler = (e) => {
    if (e == 'role') {
      this.setState({ candidateUserVarRoleName: [] }, () => {
        this.saveUserTaskSetting();
      });
    }
    if (e == 'post') {
      if (!this.state.isCacscade) {
        this.setState(
          {
            candidateUserVarPostName: [],
          },
          () => {
            this.saveUserTaskSetting();
          },
        );
        return false;
      }
      this.setState(
        {
          candidateUserVarPostName: [],
          candidateUserVarRoleName: [],
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    }
    if (e == 'org') {
      if (!this.state.isCacscade) {
        this.setState(
          {
            candidateUserVarOrgName: [],
          },
          () => {
            this.saveUserTaskSetting();
          },
        );
        return false;
      }
      this.setState(
        {
          candidateUserVarOrgName: [],
          candidateUserVarPostName: [],
          candidateUserVarRoleName: [],
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    }
    if (e == 'group') {
      this.setState(
        { selectGroupName: [], selectGroupType: '', selectGroupTemp: 'delAll' },
        () => {
          this.saveUserTaskSetting();
        },
      );
    }
    if (e == 'userHandler') {
      this.setState(
        {
          peopleList: [],
          delegateList: [],
          peopleListDel: 'delAll',
          selectType: '',
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    }
  };

  // 组织架构树子组件传值
  transferSelectReviewer = (value, type) => {
    if (value == '') {
      this.setState({ selectUserVisible: false });
      return false;
    }
    // 如果办理人数组为空就清除审核人
    if (value.length == 0) {
      this.delHandler('userHandler');
      return false;
    }
    if (type == 'user') {
      this.setState({
        selectGroupName: [],
        selectGroupType: '',
        selectGroupTemp: 'delAll',
      });
    }
    if (
      type == 'user' ||
      type == 'candidateUsers' ||
      type == 'org' ||
      type == 'post' ||
      type == 'role'
    ) {
      this.setState({
        candidateUserVarOrgName: [],
        candidateUserVarPostName: [],
        candidateUserVarRoleName: [],
      });
    }
    this.setState(
      {
        delegateList: value,
        selectType: type,
        selectUserVisible: false,
        selectUserVisible: false,
      },
      () => {
        this.saveUserTaskSetting();
      },
    );
  };
  // 组织架构树将选中的类型传过来 如果选择用户 则将用户组清空 disable不能设置
  transferSelectType = (e) => {
    if (e == 'user') {
      this.setState({ selectGroupName: [], selectGroupTemp: 'delAll' });
    }
  };

  // 用户权重传值
  transferUserOvg = (value) => {
    if (value) {
      this.setState({ userOvg: value });
    }
  };
  // 用户组传值
  transferSelectGroupType = (value) => {
    this.setState({ selectGroupType: value });
  };

  // 用户组模态框
  selectGroup = () => {
    this.setState({ selectGroupVisible: true });
  };
  transferSelectGroup = (e, type) => {
    const selectGroupTemp = e;
    // 选择的用户组变量
    if (type == 'candidateGroupVar') {
      this.setState(
        {
          selectGroup: [selectGroupTemp],
          selectGroupName: [selectGroupTemp],
          personnelLimit: true,
          selectGroupType: type,
          selectGroupVisible: false,
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    } else {
      if (selectGroupTemp.length > 0) {
        // this.setState({ personnelLimit: false });
        let typeMontaior = groupBy(selectGroupTemp, 'type');
        // 机构
        let newSelectGroup = [];
        if (typeMontaior['03']) {
          let newCandidateUserVarName = typeMontaior['03'].map((obj) => {
            return 'd:' + obj.id;
          });
          newSelectGroup.push(newCandidateUserVarName);
        }
        // 岗位
        if (typeMontaior['02']) {
          let newCandidateUserVarName = typeMontaior['02'].map((obj) => {
            return 'p:' + obj.id;
          });
          newSelectGroup.push(newCandidateUserVarName);
        }
        // 角色
        if (typeMontaior['01']) {
          let newCandidateUserVarName = typeMontaior['01'].map((obj) => {
            return 'r:' + obj.roleId;
          });
          newSelectGroup.push(newCandidateUserVarName);
        }

        this.setState(
          {
            selectGroup: newSelectGroup.toString(),
            selectGroupName: selectGroupTemp,
            selectGroupVisible: false,
            selectGroupType: 'org',
          },
          () => {
            this.delHandler('org');
          },
        );
      } else {
        this.delHandler('group');
      }
    }
    // 选择的机构、岗位、角色

    this.setState({ selectGroupVisible: false });
  };
  // 人员变量限定模态框
  candidateUserVar = (e) => {
    this.setState({
      candidateUserVarOrgVisible: true,
      candidateUserVarType: e,
    });
  };
  candidateUserVarHandleOk = () => {
    // 机构
    if (this.state.candidateUserVarOrgTemp.length > 0) {
      this.setState({
        candidateUserVarOrgName: this.state.candidateUserVarOrgTemp,
      });
    }
    if (!this.state.isCacscade) {
      this.setState(
        {
          candidateUserVarOrgVisible: false,
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
      return false;
    }
    this.setState(
      {
        candidateUserVarOrgVisible: false,
        candidateUserVarRoleTemp: [],
        candidateUserVarRoleName: [],
        candidateUserVarPostTemp: [],
        candidateUserVarPostName: [],
      },
      () => {
        this.saveUserTaskSetting();
      },
    );
  };
  candidateUserVarHandleCancel = () => {
    this.setState({ candidateUserVarOrgTemp: [] });
    this.setState({ candidateUserVarOrgVisible: false }, () => {});
  };

  // 人员变量机构限定
  transferCandidateUserList = (e) => {
    if (this.state.candidateUserVarType == 'org') {
      this.setState({
        candidateUserVarOrgTemp: e,
        candidateUserVarRoleTemp: [],
        candidateUserVarPostTemp: [],
      });
    }
  };
  // 回显角色
  roleIds = (e) => {
    getInfosByIds({
      ids: '05,' + e,
    }).then((res) => {
      if (res.sysHead.retCd !== '000000') {
        this.setState({
          candidateUserVarRoleName: [e],
        });
        return false;
      }
      const result = res?.body?.infosByIds ? res?.body?.infosByIds : res.body;
      this.setState({
        candidateUserVarRoleName: result,
      });
    });
  };
  // 回显岗位
  postIdsName = (e) => {
    getInfosByIds({
      ids: '06,' + e,
    }).then((res) => {
      if (res.sysHead.retCd !== '000000') {
        this.setState({
          candidateUserVarPostName: [e],
        });
        return false;
      }
      const result = res?.body?.infosByIds ? res?.body?.infosByIds : res.body;
      this.setState({
        candidateUserVarPostName: result,
      });
    });
  };
  // 回显机构
  departmentIds = (e) => {
    getInfosByIds({
      ids: '07,' + e,
    }).then((res) => {
      if (res.sysHead.retCd !== '000000') {
        this.setState({
          candidateUserVarOrgName: [e],
        });
        return false;
      }
      const result = res?.body?.infosByIds ? res?.body?.infosByIds : res.body;
      this.setState({
        candidateUserVarOrgName: result,
      });
    });
  };
  // 岗位和角色
  candidateUserVarPostAndRole = (e) => {
    this.setState({
      candidateUserVarPostAndRoleVisible: true,
      candidateUserVarType: e,
    });
  };
  candidateUserVarPostAndRoleHandleOk = () => {
    // 角色
    if (this.state.candidateUserVarRoleTemp.length > 0) {
      this.setState(
        {
          candidateUserVarRoleName: this.state.candidateUserVarRoleTemp,
          candidateUserVarPostAndRoleVisible: false,
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    }
    // 岗位
    if (this.state.candidateUserVarPostTemp.length > 0) {
      if (!this.state.isCacscade) {
        this.setState(
          {
            candidateUserVarPostName: this.state.candidateUserVarPostTemp,
            candidateUserVarPostAndRoleVisible: false,
          },
          () => {
            this.saveUserTaskSetting();
          },
        );
        return false;
      }
      this.setState(
        {
          candidateUserVarPostName: this.state.candidateUserVarPostTemp,
          candidateUserVarRoleName: [],
          candidateUserVarRoleTemp: [],
          candidateUserVarPostAndRoleVisible: false,
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    }
  };
  candidateUserVarPostAndRoleHandleCancel = () => {
    if (this.state.candidateUserVarType == 'role') {
      this.setState({ candidateUserVarRoleTemp: [] });
    }
    if (this.state.candidateUserVarType == 'post') {
      this.setState({ candidateUserVarPostTemp: [] });
    }
    this.setState({ candidateUserVarPostAndRoleVisible: false });
  };

  // 岗位和角色 传值
  transferPostOrRole = (e) => {
    if (this.state.candidateUserVarType == 'post') {
      this.setState({
        candidateUserVarPostTemp: e,
        candidateUserVarRoleTemp: [],
        candidateUserVarOrgTemp: [],
      });
    }
    if (this.state.candidateUserVarType == 'role') {
      this.setState({
        candidateUserVarRoleTemp: e,
        candidateUserVarPostTemp: [],
        candidateUserVarOrgTemp: [],
      });
    }
  };
  // 回显审核人方法
  getInfosByIds = (e) => {
    if (!e) {
      return false;
    }
    if (e.indexOf('$') == 0) {
      this.setState({ personnelLimit: true });
    } else {
      this.setState({ personnelLimit: false });
    }
    this.setState({ peopleList: e != '' ? [e] : [] });
    if (e.includes('${') == false && e != '') {
      const countPeople = e.split(',');
      if (countPeople[0] == '01' || countPeople[0] == '05') {
        this.setState({ selectType: 'role' });
      }
      if (countPeople[0] == '02' || countPeople[0] == '06') {
        this.setState({ selectType: 'post' });
      }
      if (countPeople[0] == '03' || countPeople[0] == '07') {
        this.setState({ selectType: 'org' });
      }
      if (
        countPeople[0] != '01' &&
        countPeople[0] != '02' &&
        countPeople[0] != '03' &&
        countPeople[0] != '04' &&
        countPeople[0] != '05' &&
        countPeople[0] != '06' &&
        countPeople[0] != '07' &&
        countPeople.length > 1
      ) {
        this.setState({ selectType: 'candidateUsers' });
      }
      getInfosByIds({
        ids: e,
      }).then((res) => {
        if (res.sysHead.retCd == '000000') {
          const result = res?.body?.infosByIds
            ? res?.body?.infosByIds
            : res.body;
          result?.map((item) => {
            item.id = item.empNo ? item.empNo : item.id;
          });
          this.setState({ peopleList: result });
        }
      });
    } else {
      if (this.state.selectType == 'userVar' && e != '') {
        this.setState({ peopleList: [{ name: '用户变量: ' + e }] });
      }
      if (this.state.selectType == 'candidateUserVar' && e != '') {
        this.setState({ peopleList: [{ name: '候选用户变量: ' + e }] });
      }
      if (this.state.selectType == 'assignee' && e != '') {
        this.setState({ peopleList: [{ name: '用户变量: ' + e }] });
      }
    }
  };

  // 更新自定义属性
  updateProperties = (properties) => {
    const modeling = this.props.modeler.get('modeling');
    modeling.updateProperties(this.state.currentElement, properties);
  };
  // 更新节点颜色
  setColor = (properties) => {
    const modeling = this.props.modeler.get('modeling');
    modeling.setColor(this.state.currentElement, properties);
  };
  // 更新Label
  updateLabel = (label) => {
    const modeling = this.props.modeler.get('modeling');
    modeling.updateLabel(this.state.currentElement, label);
  };

  // 流程续跑开关
  processContinuationListener = (e) => {
    delete this.state.currentElement.businessObject.$attrs['flowable:assignee'];
    delete this.state.currentElement.businessObject.loopCharacteristics;
    if (e) {
      this.setColor({ fill: '#7D4646', stroke: '#7D4646' });

      this.executeMonitor.current?.resetFields();
      this.setState(
        {
          processContinuationListener: e,
          isCommittee: false,
          executeNum: 0,
          taskNum: 1,
          addExecuteList: [],
          addTaskList: ['1'],
          executionListenersList: [],
          taskListenersList: [],
          delegateList: [],
        },
        () => {
          this.taskMonitor.current?.setFieldsValue({
            event0: 'create',
            type0: 'delegateExpression',
            value0: '${processContinuationListener}',
          });
          this.saveUserTaskSetting();
        },
      );
    } else {
      this.setColor({
        stroke: null,
        fill: null,
      });
      this.taskMonitor.current?.resetFields();
      this.setState(
        {
          processContinuationListener: e,
          executeNum: 0,
          taskNum: 0,
          addExecuteList: [],
          addTaskList: [],
          executionListenersList: [],
          taskListenersList: [],
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    }
  };
  // 关闭执行监听器对话框
  closeExecutionListenersModal = () => {
    this.setState({ executionListenersModalVisible: false });
    this.echoMonitor();
  };

  // 确认添加执行监听器
  executeListenersModalOk = async (e) => {
    try {
      // 表单校验
      const value = await this.executeMonitor.current.validateFields();
      const executeListeners = this.executeMonitor.current.getFieldsValue();
      const taskListeners = this.taskMonitor.current.getFieldsValue();
      // 处理form表单的值，对象变数组  objectVariableArray监听器处理函数
      const executeDest = objectVariableArray(executeListeners);
      const taskDest = objectVariableArray(taskListeners);
      this.setState(
        {
          executionListenersList: executeDest,
          taskListenersList: taskDest,
          executionListenersModalVisible: false,
          executeNum: executeDest.length,
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 添加一条执行监听器
  addExecuteList = () => {
    const num = this.state.addExecuteList;
    if (this.state.addExecuteList.length == 0) {
      num.push(String(this.state.addExecuteList.length));
    } else {
      num.push(String(Number(num[num.length - 1]) + 1));
    }
    this.setState({
      addExecuteList: num,
    });
  };
  // 有监听器就执行这一个
  taskListenersAndExecListerers = () => {
    // 表单校验
    const executeListeners = this.executeMonitor.current.getFieldsValue();
    const taskListeners = this.taskMonitor.current.getFieldsValue();
    // 处理form表单的值，对象变数组  objectVariableArray监听器处理函数
    const executeDest = objectVariableArray(executeListeners);
    const taskDest = objectVariableArray(taskListeners);
    this.setState({
      executionListenersList: executeDest,
      taskListenersList: taskDest,
      executionListenersModalVisible: false,
    });
  };
  // 关闭任务监听器
  closeTaskListenersModal = () => {
    this.setState({
      taskListenersModalVisible: false,
      // addTaskList: []
    });
    this.echoMonitor();
  };

  // 确认添加任务监听器Modal
  taskListenersModalOk = async (e) => {
    try {
      const value = await this.taskMonitor.current.validateFields();
      const executeListeners = this.executeMonitor.current.getFieldsValue();
      const taskListeners = this.taskMonitor.current.getFieldsValue();
      // 处理form表单的值，引入objectVariableArray方法将对象变数组
      const executeDest = objectVariableArray(executeListeners);
      const taskDest = objectVariableArray(taskListeners);
      this.setState(
        {
          executionListenersList: executeDest,
          taskListenersList: taskDest,
          taskListenersModalVisible: false,
          taskNum: taskDest.length,
        },
        () => {
          this.saveUserTaskSetting();
        },
      );
    } catch (errorInof) {
      message.error('请注意必输字段');
    }
  };

  // 添加一条任务监听器
  addTaskList = () => {
    const num = this.state.addTaskList;
    if (this.state.addTaskList.length == 0) {
      num.push(String(this.state.addTaskList.length));
    } else {
      num.push(String(Number(num[num.length - 1]) + 1));
    }
    this.setState({
      addTaskList: num,
    });
  };

  // 删除添加的执行监听器
  deletExecuteAdd = (e) => {
    const addListTem = this.state.addExecuteList;
    addListTem.splice(this.state.addExecuteList.length - 1, 1);
    this.setState({ addExecuteList: addListTem }, () => {
      const exexuted = this.executeMonitor.current.getFieldsValue();
      this.executeMonitor.current.resetFields();
      this.executeMonitor.current.setFieldsValue({ ...exexuted });
    });
  };

  // 删除添加的任务监听器
  deletTaskAdd = (e) => {
    const addListTem = this.state.addTaskList;
    addListTem.splice(this.state.addTaskList.length - 1, 1);
    this.setState({ addTaskList: addListTem }, () => {
      const task = this.taskMonitor.current.getFieldsValue();
      this.taskMonitor.current.resetFields();
      this.taskMonitor.current.setFieldsValue({ ...task });
    });
  };
  // 人员限定，是否级联
  isCacscadeOnChange = (e) => {
    this.setState({ isCacscade: e });
    this.delHandler('org');
    this.delHandler('post');
    this.delHandler('role');
  };
  // 是否为审委会
  isCommitteeChange = (e) => {
    if (e) {
      this.taskMonitor?.current.setFieldsValue({
        value0: '${multiDirectorTaskListener}',
      });
    } else {
      this.taskMonitor?.current.setFieldsValue({
        value0: '${multiTaskListener}',
      });
    }

    this.setState({ isCommittee: e }, () => {
      this.setListenerList();
      this.saveUserTaskSetting();
    });
  };

  /**
   * 监听比例数据 input
   * @param {*} e
   */
  proportion = (e) => {
    const settings = this.userTaskSettingRef.current.getFieldsValue();
    console.log(settings);
    console.log(e);
    // let propor=e.target.value
    this.saveUserTaskSetting();
  };

  render() {
    return (
      <>
        <div className={StyleSheet.panpelPaddingBottom}>
          <Form
            ref={this.userTaskSettingRef}
            labelAlign="right"
            layout="horizontal"
            labelCol={{ span: 9 }}
            wrapperCol={{ span: 15 }}
            // onFinish={this.saveUserTaskSetting}
          >
            <Collapse
              accordion
              style={{ background: '#f8f8f8', paddingBottomg: 8 }}
              defaultActiveKey={['3']}
            >
              <Panel header="节点事件" key="1" forceRender={true}>
                {!this.state.processContinuationListener && (
                  <Form.Item name="executionListeners" label="执行监听器">
                    <Badge
                      count={this.state.executeNum}
                      style={{ backgroundColor: '#52c41a' }}
                    >
                      <Button onClick={this.openExecutionListenersModal}>
                        编辑
                      </Button>
                    </Badge>
                  </Form.Item>
                )}
                <Form.Item
                  name="taskListeners"
                  label="任务监听器"
                  style={{ marginBottom: 0 }}
                >
                  <Badge
                    count={this.state.taskNum}
                    style={{ backgroundColor: '#52c41a' }}
                  >
                    <Button onClick={this.openTaskListenersModal}>编辑</Button>
                  </Badge>
                </Form.Item>
              </Panel>

              {!this.state.processContinuationListener && (
                <>
                  {/* sign 判断是流程设计还是业务配置 */}
                  <Panel header="多实例任务(会签)" key="2" forceRender={true}>
                    <Form.Item
                      label="是否为审委会"
                      labelAlign="left"
                      labelCol="5"
                      name="isCommittee"
                      style={{ marginBottom: 8, marginLeft: '5px' }}
                    >
                      <Switch
                        name="process"
                        onChange={this.isCommitteeChange}
                        checkedChildren="开启"
                        checked={this.state.isCommittee}
                        unCheckedChildren="关闭"
                      />
                    </Form.Item>
                    <Form.Item
                      name="executionMethod"
                      label="执行方式"
                      style={{ marginBottom: 0 }}
                    >
                      <Select onChange={this.saveUserTaskSetting}>
                        <Select.Option value="">请选择</Select.Option>
                        <Select.Option value="false">并行</Select.Option>
                        <Select.Option value="true">串行</Select.Option>
                      </Select>
                    </Form.Item>
                    {this.state.executionMethod && (
                      <Form.Item
                        name="type"
                        label="通过策略"
                        style={{ marginTop: 15, marginBottom: 0 }}
                      >
                        <Select onChange={this.throughStrategy}>
                          <Select.Option value="">请选择</Select.Option>
                          <Select.Option value="per">比例通过制</Select.Option>
                          <Select.Option value="expression">
                            表达式通过制
                          </Select.Option>
                          <Select.Option value="avg">权重通过制</Select.Option>
                        </Select>
                      </Form.Item>
                    )}
                    {this.state.throughStrategy == 'per' && (
                      <Form.Item
                        name="proportion"
                        label="通过比例"
                        style={{ marginTop: 15, marginBottom: 0 }}
                        rules={[
                          {
                            pattern: /^[01]\.\d{0,2}$/,
                            message:
                              '只能输入0到1之间的小数且小数位最多只能有两位',
                          },
                        ]}
                      >
                        {/* /^(0(\.\d{1,2})?|1(\.0{1,2})?)$/ */}
                        {/* <Select onChange={this.saveUserTaskSetting}>
                          <Select.Option value="">请选择</Select.Option>
                          <Select.Option value="0.1">10%</Select.Option>
                          <Select.Option value="0.2">20%</Select.Option>
                          <Select.Option value="0.3">30%</Select.Option>
                          <Select.Option value="0.4">40%</Select.Option>
                          <Select.Option value="0.5">50%</Select.Option>
                          <Select.Option value="0.6">60%</Select.Option>
                          <Select.Option value="0.7">70%</Select.Option>
                          <Select.Option value="0.8">80%</Select.Option>
                          <Select.Option value="0.9">90%</Select.Option>
                          <Select.Option value="1.0">100%</Select.Option>
                        </Select> */}
                        <Input
                          type="number"
                          max="1.01"
                          onChange={this.proportion}
                          autoComplete="off"
                        ></Input>
                        {/* <FcInputNumber
                          style={{ width: '100%',padding:'4px 0px' }}
                          min="0"
                          max="2"
                          step="0.01"
                          onChange={this.proportion}
                          stringMode
                        /> */}
                      </Form.Item>
                    )}
                    {this.state.throughStrategy == 'avg' && (
                      <Form.Item
                        name="proportion"
                        label="通过比例"
                        style={{ marginTop: 15, marginBottom: 0 }}
                      >
                        <Select onChange={this.saveUserTaskSetting}>
                          <Select.Option value="">请选择</Select.Option>
                          <Select.Option value="0.1">10%</Select.Option>
                          <Select.Option value="0.2">20%</Select.Option>
                          <Select.Option value="0.3">30%</Select.Option>
                          <Select.Option value="0.4">40%</Select.Option>
                          <Select.Option value="0.5">50%</Select.Option>
                          <Select.Option value="0.6">60%</Select.Option>
                          <Select.Option value="0.7">70%</Select.Option>
                          <Select.Option value="0.8">80%</Select.Option>
                          <Select.Option value="0.9">90%</Select.Option>
                          <Select.Option value="1.0">100%</Select.Option>
                        </Select>
                      </Form.Item>
                    )}
                    {this.state.throughStrategy == 'expression' && (
                      <Form.Item
                        name="expression"
                        label="通过表达式"
                        style={{ marginTop: 15, marginBottom: 0 }}
                      >
                        <Input
                          placeholder="请输入"
                          onChange={this.saveUserTaskSetting}
                        ></Input>
                      </Form.Item>
                    )}
                  </Panel>
                  <Panel header="节点审核人员" key="3" forceRender={true}>
                    <Button type="primary" onClick={this.selectUser}>
                      处理人
                    </Button>
                    {this.state.peopleList.length > 0 && (
                      <Button
                        onClick={() => {
                          this.delHandler('userHandler');
                        }}
                        type="default"
                        style={{ marginLeft: 8 }}
                      >
                        清空
                      </Button>
                    )}
                    <br></br>
                    {/* 显示人员 */}
                    <div className="session">
                      {this.state.peopleList &&
                        this.state.peopleList.map((item, index) => {
                          return (
                            <Tag
                              style={{
                                lineHeight: '26px',
                                marginTop: 5,
                                height: '30px',
                                maxWidth: 247,
                                textOverflow: 'ellipsis',
                                overflow: 'hidden',
                              }}
                              key={'key' + index}
                              color="blue"
                            >
                              {item.name ? item.name : item}
                            </Tag>
                          );
                        })}
                    </div>
                    {/* 选择 处理人 */}
                    {this.state.selectUserVisible && (
                      <OrgTreeModal
                        transfer={this.transferSelectReviewer}
                        transferSelectType={this.transferSelectType}
                        activityId={this.state.currentElement.id}
                        throughStrategy={this.state.throughStrategy}
                        delegateList={this.state.peopleList}
                        selectType={this.state.selectType}
                        selectUserHandleCancel={() => {
                          this.setState({ selectUserVisible: false });
                        }}
                        userOvg={this.state.userOvg}
                        transferUserOvg={this.transferUserOvg}
                      ></OrgTreeModal>
                    )}
                  </Panel>
                  <Panel header="节点审核组" key="4" forceRender={true}>
                    <Button
                      type="primary"
                      onClick={this.selectGroup}
                      disabled={
                        this.state.selectType == 'user'
                          ? true
                          : this.state.selectType == 'candidateUsers'
                          ? true
                          : false
                      }
                    >
                      处理组
                    </Button>
                    {this.state.selectGroupName.length > 0 && (
                      <Button
                        onClick={() => {
                          this.delHandler('group');
                        }}
                        type="default"
                        style={{ marginLeft: 8 }}
                      >
                        清空
                      </Button>
                    )}
                    <br></br>
                    {/* 显示节点审核组 */}
                    <div className="session">
                      {this.state.selectGroupName &&
                        this.state.selectGroupName.map((item, index) => {
                          return (
                            <Tag
                              style={{
                                lineHeight: '26px',
                                marginTop: 5,
                                height: '30px',
                              }}
                              key={'key' + index}
                              color="blue"
                            >
                              {item.name ? item.name : item}
                            </Tag>
                          );
                        })}
                    </div>
                    {/* 选择 节点审核组 */}

                    {/* 弹框审核人选择 */}
                    {this.state.selectGroupVisible && (
                      <OrgTreeGroup
                        selectUserHandleCancel={() => {
                          this.setState({ selectGroupVisible: false });
                        }}
                        delegateList={this.state.selectGroupName}
                        transfer={this.transferSelectGroup}
                        transferSelectType={this.transferSelectGroupType}
                        activityId={this.state.currentElement.id}
                        selectType={this.state.selectGroupType}
                      ></OrgTreeGroup>
                    )}
                  </Panel>

                  {this.state.personnelLimit && (
                    <Panel header="人员变量限定" key="5">
                      <Form.Item
                        label="是否级联"
                        labelAlign="left"
                        labelCol="5"
                        name="isCacscade"
                        style={{ marginBottom: 8 }}
                      >
                        <Switch
                          onChange={this.isCacscadeOnChange}
                          checkedChildren="开启"
                          checked={this.state.isCacscade}
                          unCheckedChildren="关闭"
                        />
                      </Form.Item>
                      <Divider style={{ margin: 0, marginBottom: 1 }}></Divider>
                      <Form.Item name="org" noStyle>
                        <Button
                          style={{ marginBottom: 0, marginTop: 8 }}
                          onClick={() => {
                            this.candidateUserVar('org');
                          }}
                          type="primary"
                        >
                          ＋ 机构限定:
                        </Button>
                        {this.state.candidateUserVarOrgName?.length > 0 && (
                          <Button
                            onClick={() => {
                              this.delHandler('org');
                            }}
                            type="default"
                            style={{ marginLeft: 8 }}
                          >
                            清空
                          </Button>
                        )}
                        <div>
                          {this.state.candidateUserVarOrgName &&
                            this.state.candidateUserVarOrgName?.map(
                              (item, index) => {
                                return (
                                  <Tag
                                    style={{
                                      lineHeight: '26px',
                                      marginTop: 5,
                                      height: '30px',
                                    }}
                                    key={'OrgName' + index}
                                    color="blue"
                                  >
                                    {item.name ? item.name : item}
                                  </Tag>
                                );
                              },
                            )}
                        </div>
                      </Form.Item>
                      {this.state.isCacscade &&
                        this.state.candidateUserVarOrgName?.length > 0 && (
                          <Form.Item name="post" noStyle>
                            <Button
                              style={{ marginBottom: 0, marginTop: 8 }}
                              onClick={() => {
                                this.candidateUserVarPostAndRole('post');
                              }}
                              type="primary"
                            >
                              ＋ 岗位限定:
                            </Button>
                            {this.state.candidateUserVarPostName?.length >
                              0 && (
                              <Button
                                onClick={() => {
                                  this.delHandler('post');
                                }}
                                type="default"
                                style={{ marginLeft: 8 }}
                              >
                                清空
                              </Button>
                            )}
                            <div>
                              {this.state.candidateUserVarPostName &&
                                this.state.candidateUserVarPostName?.map(
                                  (item, index) => {
                                    return (
                                      <Tag
                                        style={{
                                          lineHeight: '26px',
                                          marginTop: 5,
                                          height: '30px',
                                        }}
                                        key={'PostName' + index}
                                        color="blue"
                                        // closable
                                        onClose={(e) => {
                                          e.preventDefault();
                                        }}
                                      >
                                        {item.name ? item.name : item}
                                      </Tag>
                                    );
                                  },
                                )}
                            </div>
                          </Form.Item>
                        )}

                      {this.state.isCacscade &&
                        this.state.candidateUserVarPostName?.length > 0 && (
                          <Form.Item name="role" noStyle>
                            <Button
                              style={{ marginBottom: 0, marginTop: 8 }}
                              onClick={() => {
                                this.candidateUserVarPostAndRole('role');
                              }}
                              type="primary"
                            >
                              ＋ 角色限定:
                            </Button>
                            {this.state.candidateUserVarRoleName?.length >
                              0 && (
                              <Button
                                onClick={() => {
                                  this.delHandler('role');
                                }}
                                type="default"
                                style={{ marginLeft: 8 }}
                              >
                                清空
                              </Button>
                            )}
                            <div>
                              {this.state.candidateUserVarRoleName &&
                                this.state.candidateUserVarRoleName?.map(
                                  (item, index) => {
                                    {
                                      if (index === 0) {
                                        return <div>123456789</div>;
                                      } else {
                                        return (
                                          <Tag
                                            style={{
                                              lineHeight: '26px',
                                              marginTop: 5,
                                              height: '30px',
                                            }}
                                            key={'RoleName' + index}
                                            color="blue"
                                            onClose={(e) => {
                                              e.preventDefault();
                                            }}
                                          >
                                            {item.name ? item.name : item}
                                          </Tag>
                                        );
                                      }
                                    }
                                  },
                                )}
                            </div>
                          </Form.Item>
                        )}
                      {/* 不级联 */}
                      {!this.state.isCacscade && (
                        <>
                          <Form.Item name="post" noStyle>
                            <Button
                              style={{ marginBottom: 0, marginTop: 8 }}
                              onClick={() => {
                                this.candidateUserVarPostAndRole('post');
                              }}
                              type="primary"
                            >
                              ＋ 岗位限定:
                            </Button>
                            {this.state.candidateUserVarPostName?.length >
                              0 && (
                              <Button
                                onClick={() => {
                                  this.delHandler('post');
                                }}
                                type="default"
                                style={{ marginLeft: 8 }}
                              >
                                清空
                              </Button>
                            )}
                            <div>
                              {this.state.candidateUserVarPostName &&
                                this.state.candidateUserVarPostName?.map(
                                  (item, index) => {
                                    return (
                                      <Tag
                                        style={{
                                          lineHeight: '26px',
                                          marginTop: 5,
                                          height: '30px',
                                        }}
                                        key={'PostName' + index}
                                        color="blue"
                                        // closable
                                        onClose={(e) => {
                                          e.preventDefault();
                                        }}
                                      >
                                        {item.name ? item.name : item}
                                      </Tag>
                                    );
                                  },
                                )}
                            </div>
                          </Form.Item>

                          <Form.Item name="role" noStyle>
                            <Button
                              style={{ marginBottom: 0, marginTop: 8 }}
                              onClick={() => {
                                this.candidateUserVarPostAndRole('role');
                              }}
                              type="primary"
                            >
                              ＋ 角色限定:
                            </Button>
                            {this.state.candidateUserVarRoleName?.length >
                              0 && (
                              <Button
                                onClick={() => {
                                  this.delHandler('role');
                                }}
                                type="default"
                                style={{ marginLeft: 8 }}
                              >
                                清空
                              </Button>
                            )}
                            <div>
                              {this.state.candidateUserVarRoleName &&
                                this.state.candidateUserVarRoleName?.map(
                                  (item, index) => {
                                    {
                                      if (this.state.isCommittee) {
                                        if (index === 0) {
                                          return (
                                            <div>
                                              <span>委员：</span>{' '}
                                              <Tag
                                                style={{
                                                  lineHeight: '26px',
                                                  marginTop: 5,
                                                  height: '30px',
                                                }}
                                                key={'RoleName' + index}
                                                color="blue"
                                                onClose={(e) => {
                                                  e.preventDefault();
                                                }}
                                              >
                                                {item.name ? item.name : item}
                                              </Tag>
                                            </div>
                                          );
                                        } else {
                                          return (
                                            <div>
                                              <span>主任：</span>
                                              <Tag
                                                style={{
                                                  lineHeight: '26px',
                                                  marginTop: 5,
                                                  height: '30px',
                                                }}
                                                key={'RoleName' + index}
                                                color="blue"
                                                onClose={(e) => {
                                                  e.preventDefault();
                                                }}
                                              >
                                                {item.name ? item.name : item}
                                              </Tag>
                                            </div>
                                          );
                                        }
                                      } else {
                                        return (
                                          <Tag
                                            style={{
                                              lineHeight: '26px',
                                              marginTop: 5,
                                              height: '30px',
                                            }}
                                            key={'RoleName' + index}
                                            color="blue"
                                            onClose={(e) => {
                                              e.preventDefault();
                                            }}
                                          >
                                            {item.name ? item.name : item}
                                          </Tag>
                                        );
                                      }
                                    }
                                  },
                                )}
                            </div>
                          </Form.Item>
                        </>
                      )}
                      {/* 机构变量 */}
                      {this.state.candidateUserVarOrgVisible && (
                        <Modal
                          visible={this.state.candidateUserVarOrgVisible}
                          title={'节点人员变量限定——机构'}
                          width="60%"
                          forceRender
                          style={{ paddingTop: 0 }}
                          onOk={this.candidateUserVarHandleOk}
                          onCancel={this.candidateUserVarHandleCancel}
                          bodyStyle={{ paddingTop: 0 }}
                          footer={[
                            <Button
                              key="back"
                              onClick={this.candidateUserVarHandleCancel}
                            >
                              取消
                            </Button>,
                            <Button
                              key="submit"
                              type="primary"
                              onClick={this.candidateUserVarHandleOk}
                            >
                              确认
                            </Button>,
                          ]}
                        >
                          {/* 人员变量限定 */}
                          <OrgLimit
                            candidateUserVarOrg={
                              this.state.candidateUserVarOrgName
                            }
                            candidateUserVarType={
                              this.state.candidateUserVarType
                            }
                            transferCandidateUserList={
                              this.transferCandidateUserList
                            }
                          ></OrgLimit>
                        </Modal>
                      )}
                      {/* 岗位和角色变量 */}
                      {this.state.candidateUserVarPostAndRoleVisible && (
                        <Modal
                          visible={
                            this.state.candidateUserVarPostAndRoleVisible
                          }
                          title={
                            '节点人员变量限定——' +
                            (this.state.candidateUserVarType == 'post'
                              ? '岗位'
                              : '角色')
                          }
                          width="60%"
                          forceRender
                          onOk={this.candidateUserVarPostAndRoleHandleOk}
                          onCancel={
                            this.candidateUserVarPostAndRoleHandleCancel
                          }
                          footer={[
                            <Button
                              key="back"
                              onClick={
                                this.candidateUserVarPostAndRoleHandleCancel
                              }
                            >
                              取消
                            </Button>,
                            <Button
                              key="submit"
                              type="primary"
                              onClick={this.candidateUserVarPostAndRoleHandleOk}
                            >
                              确认
                            </Button>,
                          ]}
                        >
                          {/* 人员变量限定 */}
                          <PostAndRoleLimit
                            candidateUserVarLimit={
                              this.state.candidateUserVarType == 'post'
                                ? this.state.candidateUserVarPostName
                                : this.state.candidateUserVarRoleName
                            }
                            thePrevious={
                              this.state.candidateUserVarType == 'post'
                                ? this.state.candidateUserVarRoleName
                                : this.state.candidateUserVarPostName
                            }
                            isCacscade={this.state.isCacscade}
                            candidateUserVarType={
                              this.state.candidateUserVarType
                            }
                            orgIds={this.state.candidateUserVarOrgName}
                            postIds={this.state.candidateUserVarPostName}
                            transferPostOrRole={this.transferPostOrRole}
                          ></PostAndRoleLimit>
                        </Modal>
                      )}
                    </Panel>
                  )}
                  <Panel header="额外属性配置" key="6" forceRender={true}>
                    <Form.Item
                      name="urlAddress"
                      label="URL地址配置"
                      labelCol={{ span: 8 }}
                      wrapperCol={{ span: 16 }}
                      // style={{ marginBottom: 16 }}
                    >
                      <Input
                        onChange={this.saveUserTaskSetting}
                        style={{ width: '100%', float: 'right' }}
                      ></Input>
                    </Form.Item>
                    <Form.Item
                      name="claimLimit"
                      label="人员认领限制"
                      style={{ marginBottom: 0 }}
                      labelCol={{ span: 8 }}
                      wrapperCol={{ span: 16 }}
                    >
                      <Input
                        onChange={this.saveUserTaskSetting}
                        style={{ width: '100%', float: 'right' }}
                      ></Input>
                    </Form.Item>
                  </Panel>
                </>
              )}

              <Panel header="流程续跑" key="9">
                <Form.Item
                  label="流程续跑"
                  labelAlign="left"
                  labelCol="5"
                  name="processContinuationListener"
                  style={{ marginBottom: 8 }}
                >
                  <Switch
                    name="process"
                    onChange={this.processContinuationListener}
                    checkedChildren="开启"
                    checked={this.state.processContinuationListener}
                    unCheckedChildren="关闭"
                  />
                </Form.Item>
              </Panel>
            </Collapse>
          </Form>
          {/* 执行监听器 */}
          <Form
            labelAlign="right"
            initialValues={{ remember: true }}
            layout="horizontal"
            ref={this.executeMonitor}
          >
            <Modal
              title="执行监听器"
              visible={this.state.executionListenersModalVisible}
              okText="确认"
              cancelText="取消"
              maskClosable={false}
              width="50%"
              forceRender
              zIndex="1001"
              onOk={this.executeListenersModalOk}
              onCancel={this.closeExecutionListenersModal}
              footer={[
                <Button
                  key="submit"
                  type="primary"
                  onClick={this.executeListenersModalOk}
                >
                  确认
                </Button>,
                <Button key="back" onClick={this.closeExecutionListenersModal}>
                  取消
                </Button>,
              ]}
            >
              <Button
                style={{
                  marginBottom: '13px',
                }}
                type="primary"
                onClick={this.addExecuteList}
              >
                添加
              </Button>
              <Button
                style={{
                  marginLeft: 8,
                  marginBottom: '13px',
                }}
                danger
                type="primary"
                onClick={() => {
                  this.deletExecuteAdd('item');
                }}
              >
                删除
              </Button>
              <List
                style={{ zIndex: '10001', marginBottom: 8 }}
                header={
                  <Row style={{ width: '100%', padding: 0 }}>
                    <Col style={{ width: '33%', textAlign: 'center' }}>
                      执行周期
                      <Tooltip
                        placement="top"
                        title="开始：开始时触发，启用：执行时触发，结束：结束时触发"
                      >
                        <i className="iconfont">&#xe62a;</i>
                      </Tooltip>
                    </Col>
                    <Col style={{ width: '33%', textAlign: 'center' }}>
                      类型
                      <Tooltip
                        placement="top"
                        title="类型：自定义类必须实现 org.flowable.engine.delegate.TaskListener 接口，委托表达式：示例 ${multiExecutionListener}"
                      >
                        <i className="iconfont">&#xe62a;</i>
                      </Tooltip>
                    </Col>
                    <Col style={{ width: '33%', textAlign: 'center' }}>
                      值
                      <Tooltip
                        placement="top"
                        title="如选择委托表达式：${multiExecutionListener}"
                      >
                        <i className="iconfont">&#xe62a;</i>
                      </Tooltip>{' '}
                    </Col>
                  </Row>
                }
                bordered
                dataSource={this.state.addExecuteList}
                renderItem={(item, index) => (
                  <List.Item style={{ padding: 0 }}>
                    <Row style={{ width: '100%' }}>
                      <Form.Item
                        name={'event' + index}
                        style={{
                          width: '33%',
                          margin: '8px 0',
                          textAlign: 'center',
                        }}
                        rules={[{ required: true, message: '请选择' }]}
                      >
                        <Select style={{ width: '90%' }}>
                          <Select.Option value="start">开始</Select.Option>
                          <Select.Option value="take">启用</Select.Option>
                          <Select.Option value="end">结束</Select.Option>
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name={'type' + index}
                        style={{
                          width: '33%',
                          margin: '8px 0',
                          textAlign: 'center',
                        }}
                        rules={[{ required: true, message: '请选择' }]}
                      >
                        <Select style={{ width: '90%' }}>
                          <Select.Option value="class">类</Select.Option>
                          <Select.Option value="delegateExpression">
                            委托表达式
                          </Select.Option>
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name={'value' + index}
                        style={{
                          width: '33%',
                          margin: '8px 0',
                          textAlign: 'center',
                        }}
                        rules={[{ required: true, message: '请输入' }]}
                      >
                        <Input
                          id={'executeList' + index}
                          style={{ width: '90%', textAlign: 'center' }}
                        ></Input>
                      </Form.Item>
                    </Row>
                  </List.Item>
                )}
              ></List>
            </Modal>
          </Form>
          {/* 任务监听器 */}
          <Form labelAlign="right" layout="horizontal" ref={this.taskMonitor}>
            <Modal
              title="任务监听器"
              visible={this.state.taskListenersModalVisible}
              okText="确认"
              cancelText="取消"
              width="50%"
              zIndex="1001"
              maskClosable={false}
              forceRender
              onOk={this.taskListenersModalOk}
              onCancel={this.closeTaskListenersModal}
              footer={[
                <Button
                  key="submit"
                  type="primary"
                  onClick={this.taskListenersModalOk}
                >
                  确认
                </Button>,
                <Button key="back" onClick={this.closeTaskListenersModal}>
                  取消
                </Button>,
              ]}
            >
              <Button
                style={{
                  marginBottom: '13px',
                }}
                type="primary"
                onClick={this.addTaskList}
              >
                添加
              </Button>
              <Button
                style={{
                  marginBottom: '13px',
                  marginLeft: 8,
                }}
                danger
                type="primary"
                onClick={() => {
                  if (
                    this.state.processContinuationListener &&
                    this.state.addTaskList.length == 1
                  ) {
                    return false;
                  }
                  this.deletTaskAdd('item');
                }}
                disabled={
                  this.state.processContinuationListener &&
                  this.state.addTaskList.length == 1
                }
              >
                删除
              </Button>
              <List
                style={{ marginBottom: 8 }}
                header={
                  <Row style={{ width: '100%', padding: 0 }}>
                    <Col style={{ width: '33%', textAlign: 'center' }}>
                      执行周期
                      <Tooltip
                        placement="top"
                        title="创建:任务被创建，且所有任务属性设置完成后才触发、分配人:指定分配用户（即任务执行人）时触发、删除:删除任务时触发、完成:完成任务时触发"
                      >
                        <i className="iconfont">&#xe62a;</i>
                      </Tooltip>
                    </Col>
                    <Col style={{ width: '33%', textAlign: 'center' }}>
                      类型
                      <Tooltip
                        placement="top"
                        title="class 类绑定方式（多例）（触发事件为create）,委托表达式"
                      >
                        <i className="iconfont">&#xe62a;</i>
                      </Tooltip>
                    </Col>
                    <Col style={{ width: '33%', textAlign: 'center' }}>
                      值
                      <Tooltip
                        placement="top"
                        title="如选择委托表达式：${multiTaskListener}"
                      >
                        <i className="iconfont">&#xe62a;</i>
                      </Tooltip>
                    </Col>
                  </Row>
                }
                bordered
                dataSource={this.state.addTaskList}
                renderItem={(item, index) => (
                  <List.Item style={{ padding: 0 }}>
                    <Row style={{ width: '100%' }}>
                      <Form.Item
                        name={'event' + index}
                        style={{
                          width: '33%',
                          margin: '8px 0',
                          textAlign: 'center',
                        }}
                        rules={[{ required: true, message: '请选择' }]}
                      >
                        <Select
                          style={{ width: '90%' }}
                          disabled={
                            this.state.processContinuationListener && index == 0
                          }
                        >
                          <Select.Option value="create">创建</Select.Option>
                          {!this.state.processContinuationListener && (
                            <>
                              <Select.Option value="assignment">
                                分配人
                              </Select.Option>
                              <Select.Option value="delete">删除</Select.Option>
                            </>
                          )}

                          <Select.Option value="complete">完成</Select.Option>
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name={'type' + index}
                        style={{
                          width: '33%',
                          margin: '8px 0',
                          textAlign: 'center',
                        }}
                        rules={[{ required: true, message: '请选择' }]}
                      >
                        <Select
                          style={{ width: '90%' }}
                          disabled={
                            this.state.processContinuationListener && index == 0
                          }
                        >
                          <Select.Option value="class">类</Select.Option>
                          <Select.Option value="delegateExpression">
                            委托表达式
                          </Select.Option>
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name={'value' + index}
                        style={{
                          width: '33%',
                          margin: '10px 0',
                          textAlign: 'center',
                        }}
                        rules={[{ required: true, message: '请输入' }]}
                      >
                        <Input
                          id={'taskList' + index}
                          style={{ width: '90%', textAlign: 'center' }}
                          disabled={
                            this.state.processContinuationListener && index == 0
                          }
                        ></Input>
                      </Form.Item>
                    </Row>
                  </List.Item>
                )}
              ></List>
            </Modal>
          </Form>
        </div>
      </>
    );
  }
}

export default UserTask;
