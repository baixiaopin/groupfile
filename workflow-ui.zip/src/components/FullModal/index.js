// @ts-nocheck
import React, { Component } from 'react';
import { FcModal as Modal } from '@ngfed/fc-components';
import styles from './index.module.less';

class FullModal extends Component {
  render() {
    const { visible, title = '', onCancel, children } = this.props;

    return (
      <Modal
        title={title}
        visible={visible}
        onCancel={onCancel}
        width={'calc(100% - 20px)'}
        height={'calc(100% - 10px)'}
        footer={null}
        className={styles.fullModal}
      >
        {children}
      </Modal>
    );
  }
}

export default FullModal;
