// @ts-nocheck
import React, { Component } from 'react';
import {
  FcButton as Button,
  FcTreeSelect as TreeSelect,
  FcPopconfirm as Popconfirm,
  FcMessage as message,
  FcModal as Modal,
  FcInput as Input,
  FcTable as Table,
  FcSelect as Select,
} from '@ngfed/fc-components';
const { SHOW_PARENT } = TreeSelect;

class ManualTask extends Component {
  formRef = React.createRef();
  state = {
    // 配置列表
    configurationKeyList: [],
    manualTaskModal: true,
    columns: [
      {
        dataIndex: 'event',
        key: 'event',
        title: '执行周期',

        render: (_, record, index) => {
          return (
            <Select
              placeholder="默认值"
              onChange={(value) => this.handleChangeKey(value, record, index)}
              value={record.event}
              style={{ width: '200px' }}
            >
              <Select.Option value="start">开始</Select.Option>
              <Select.Option value="take">启用</Select.Option>
              <Select.Option value="end">结束</Select.Option>
            </Select>
          );
        },
      },
      {
        dataIndex: 'type',
        key: 'type',
        title: '类型',

        render: (_, record, index) => {
          return (
            <Select
              placeholder="默认值"
              onChange={(value) => this.handleChangeType(value, record, index)}
              value={record.type}
              style={{ width: '200px' }}
            >
              <Select.Option value="class">类</Select.Option>
              <Select.Option value="delegateExpression">
                委托表达式
              </Select.Option>
            </Select>
          );
        },
      },

      {
        dataIndex: 'value',
        key: 'value',
        title: '值',

        render: (_, record, index) => {
          return (
            <Input
              placeholder="请输入"
              value={record.value}
              onChange={(value) => this.handleChangeDec(value, record, index)}
            ></Input>
          );
        },
      },

      {
        dataIndex: 'action',
        key: 'action',
        title: '操作',

        render: (_, record, index) => {
          return (
            <>
              {this.state.configurationKeyList.length >= 1 ? (
                <Popconfirm
                  title="确定删除这条数据吗？"
                  onConfirm={() => this.handleDelete(index)}
                >
                  <Button type="link">删除</Button>
                </Popconfirm>
              ) : null}
            </>
          );
        },
      },
    ],
    count: 1,
    currentElement: {},
  };

  componentDidMount() {
    const mapping = this.props.currentElement;
    // console.log(mapping);
    this.setState({ currentElement: mapping });
    const echoExtension = this.props.currentElement.businessObject
      .extensionElements?.values;

    if (echoExtension) {
      echoExtension.map((item) => {
        for (let key in item) {
          if (Object.prototype.hasOwnProperty.call(item, key)) {
            if (key.includes('class')) {
              item['type'] = 'class';
              item['value'] = item[key];
            }
            if (key.includes('delegateExpression')) {
              item['type'] = 'delegateExpression';
              item['value'] = item[key];
            }
          }
        }
      });
      this.setState({
        configurationKeyList: echoExtension,
      });
    }
  }

  /**
   * 获取限额对象类型
   * @param {String} value
   */
  getLimitObjectType(value) {
    //测试数据
    let obj = {};
    if (value === '名称1') {
      obj = {
        type: 'ID名称1',
        value: '名称1',
      };
    } else {
      obj = {
        type: 'ID名称2',
        value: '其他',
      };
    }
    return obj;
  }

  /**
   * 校验名称的唯一
   * @param {Object} record
   * @param {String} value
   */
  checkData(value) {
    const { configurationKeyList } = this.state;
    const index = configurationKeyList.findIndex((item) => {
      return item.event === value;
    });
    if (index !== -1) {
      message.error('key不能重复');
      return false;
    }
    return true;
  }

  /**
   * 处理key的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeKey(value, record, index) {
    //校验是否重复
    if (!this.checkData(value)) return;

    const newData = [...this.state.configurationKeyList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.event = value;
    //获取id
    // cpRecord.key = this.getLimitObjectType(value).key;
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      configurationKeyList: newData,
    });
  }

  /**
   * 处理字段的改变
   * @param {String} value   改变的值
   * @param {Object} record
   */
  handleChangeDec(value, record, index) {
    //校验是否重复
    if (!this.checkData(value.target.value)) return;

    const newData = [...this.state.configurationKeyList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.value = value.target.value;
    //获取id
    // cpRecord.key = this.getLimitObjectType(value).key;
    newData.splice(index, 1, { ...item, ...cpRecord });
    this.setState({
      configurationKeyList: newData,
    });
  }

  handleChangeType(value, record, index) {
    //校验是否重复
    if (!this.checkData(value)) return;
    const newData = [...this.state.configurationKeyList];
    //在列表中找到这条记录
    const item = newData[index];
    const cpRecord = record;
    cpRecord.type = value;
    // cpRecord.type = this.getLimitObjectType(value).type;
    //获取id
    // cpRecord.dec = value.target.value;
    newData.splice(index, 1, { ...item, ...cpRecord });

    this.setState({
      configurationKeyList: newData,
    });
    // 组件间传值
  }
  /**
   * 删除一条表格
   * @param {String} index
   */
  handleDelete = (index) => {
    const { count } = this.state;
    const newData = [...this.state.configurationKeyList];
    newData.splice(index, 1);
    this.setState({
      configurationKeyList: newData,
      count: count - 1,
    });
  };

  /**
   * 新增一条表格
   */
  handleAdd = () => {
    const { count, configurationKeyList } = this.state;
    const newData = {
      type: null,
      value: null,
    };
    this.setState({
      configurationKeyList: [...configurationKeyList, newData],
      count: count + 1,
    });
  };

  // 处理监听器 添加的值，添加到传值过来的 currentElement,将处理过的数据在传回父组件
  manualTaskModalOk = () => {
    //  this.setState({manualTaskModal:false})
    // console.log(this.state.configurationKeyList);

    let currentElement = this.state.currentElement;
    let extensionElements = this.state.currentElement.businessObject.get(
      'extensionElements',
    );
    if (!extensionElements) {
      extensionElements = this.props.modeler
        .get('moddle')
        .create('bpmn:ExtensionElements');
      currentElement.businessObject.extensionElements = extensionElements;
    }
    currentElement.businessObject.extensionElements.values = [];
    this.state.configurationKeyList.map((item) => {
      const executeListener = this.props.modeler
        .get('moddle')
        .create('flowable:ExecutionListener');
      executeListener['event'] = item.event;
      executeListener[item.type] = item.value;
      currentElement.businessObject.extensionElements.values.push(
        executeListener,
      );
    });
    // console.log(currentElement);
    this.props.manualTaskok(currentElement);
  };

  manualTaskModalCancle = () => {
    this.setState({ manualTaskModal: false });
    this.props.manualTaskCancle();
  };
  render() {
    return (
      <>
        <Modal
          title="服务设置"
          visible={this.state.manualTaskModal}
          okText="确认"
          cancelText="取消"
          width="55%"
          maskClosable={false}
          onOk={this.manualTaskModalOk}
          onCancel={this.manualTaskModalCancle}
        >
          <Button
            onClick={this.handleAdd}
            type="primary"
            style={{ marginBottom: 16 }}
          >
            {' '}
            + 添加{' '}
          </Button>

          <Table
            key={(record) => {
              record.key;
            }}
            bordered
            dataSource={this.state.configurationKeyList}
            columns={this.state.columns}
            pagination={false}
          />
        </Modal>
      </>
    );
  }
}
export default ManualTask;
