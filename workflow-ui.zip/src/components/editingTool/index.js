import React, { Component } from 'react';
import styles from './index.module.less';

import { FcButton as Button } from '@ngfed/fc-components';
class EditingTool extends Component {
  handleOpen = (e) => {
    document.getElementById('clear').value = '';
    this.file.click();
  };

  render() {
    const { onOpenFIle } = this.props;
    return (
      <Button type="primary" title="导入JSON文件" onClick={this.handleOpen}>
        <input
          id="clear"
          ref={(file) => {
            this.file = file;
          }}
          style={{ display: 'none' }}
          type="file"
          onChange={onOpenFIle}
        />
        导入
      </Button>
    );
  }
}

export default EditingTool;
