import React from 'react';
import { FcTag } from '@ngfed/fc-components';

const tags = (props: { value: any; type?: any }) => {
  const { value, type } = props;
  switch (value) {
    case '01':
      return <FcTag color="#ee5d55">特急</FcTag>;
    case '02':
      return <FcTag color="red">加急</FcTag>;
    case '03':
      return <FcTag color="orange">平急</FcTag>;
    case '99':
      return <FcTag>一般</FcTag>;
    default:
      return <FcTag dashed>无</FcTag>;
  }
};

export default tags;
