import React, { Component, useState, useEffect } from 'react';
import OrgTree from '../../pages/OrgTree';
import {
  FcTabs as Tabs,
  FcTransfer as Transfer,
  FcTree as Tree,
} from '@ngfed/fc-components';
import { getListOrgTrees, getInfosByIds } from './service';
const { TabPane } = Tabs;
class orgLimit extends Component {
  state = {
    candidateUserVarOrg: '',
    candidateUserVarType: '',
    tabPaneIndex: '1',
    treeData: null,
    selectedKeys: [],
  };
  componentWillMount() {
    const candidateUserVarOrg = this.props.candidateUserVarOrg;
    const candidateUserVarType = this.props.candidateUserVarType;
    if (candidateUserVarOrg) {
      const selectedKeysTemp = candidateUserVarOrg.map((obj) => {
        return obj.id;
      });
      this.setState({
        candidateUserVarOrg: candidateUserVarOrg,
        candidateUserVarType,
        selectedKeys: selectedKeysTemp,
      });
      getListOrgTrees().then(async (res) => {
        await this.setState({ treeData: res.body });
      });
    }
  }
  componentDidMount() {
    // console.log(this.props.candidateUserVarType);
  }
  transferSelectOrgs = (value, type) => {
    this.props.transferCandidateUserList(value);
    const selectedKeysTemp = value.map((obj) => {
      return obj.id;
    });
    this.setState({
      candidateUserVarOrg: value,
      selectedKeys: selectedKeysTemp,
    });
  };
  transferSelectOrgsType = (value, type) => {};
  // callback
  callback = (e) => {
    console.log(e);
    this.setState({ tabPaneIndex: e });
  };
  transferSecond = (e) => {
    console.log(e, '方式二传值');
    this.props.transferCandidateUserList(e);
    const selectedKeysTemp = e.map((obj) => {
      return obj.id;
    });
    this.setState({ candidateUserVarOrg: e, selectedKeys: selectedKeysTemp });
  };
  render() {
    return (
      <div>
        {/* <OrgTree
      candidateUserVarOrg={this.state.candidateUserVarOrg}
      candidateUserVarType={this.state.candidateUserVarType}
      transfer={this.transferSelectOrgs}
      transferSelectType={this.transferSelectOrgsType}
    ></OrgTree> */}
        <Tabs defaultActiveKey="1" onChange={this.callback}>
          <TabPane tab="方式一" key="1">
            {this.state.tabPaneIndex == 1 && (
              <OrgTree
                candidateUserVarOrg={this.state.candidateUserVarOrg}
                candidateUserVarType={this.state.candidateUserVarType}
                searchVisable={false}
                transfer={this.transferSelectOrgs}
                transferSelectType={this.transferSelectOrgsType}
              ></OrgTree>
            )}
          </TabPane>
          <TabPane tab="方式二" key="2">
            {this.state.tabPaneIndex == 2 && (
              <App
                selectedKeys={this.state.selectedKeys}
                treeData={this.state.treeData}
                transferSecond={this.transferSecond}
              />
            )}
          </TabPane>
        </Tabs>
      </div>
    );
  }
}
export default orgLimit;

/**
 *
 * @returns 穿梭框
 */

const isChecked = (selectedKeys, eventKey) =>
  selectedKeys.indexOf(eventKey) !== -1;

const generateTree = (treeNodes = [], checkedKeys = []) =>
  treeNodes?.map(({ children, ...props }) => ({
    ...props,
    disabled: checkedKeys.includes(props.key),
    children: generateTree(children, checkedKeys),
  }));

const TreeTransfer = ({ dataSource, targetKeys, ...restProps }) => {
  const transferDataSource = [];
  function flatten(list = []) {
    list?.forEach((item) => {
      transferDataSource.push(item);
      flatten(item.children);
    });
  }
  flatten(dataSource);
  // 左侧数据源
  // console.log(dataSource);
  return (
    <Transfer
      {...restProps}
      targetKeys={targetKeys}
      dataSource={transferDataSource}
      className="tree-transfer"
      render={(item) => item.title}
      showSelectAll={false}
    >
      {({ direction, onItemSelect, selectedKeys }) => {
        if (direction === 'left') {
          const checkedKeys = [...selectedKeys, ...targetKeys];
          return (
            <Tree
              blockNode
              checkable
              checkStrictly
              defaultExpandAll
              height={392}
              checkedKeys={checkedKeys}
              treeData={generateTree(dataSource, targetKeys)}
              onCheck={(_, { node: { key } }) => {
                onItemSelect(key, !isChecked(checkedKeys, key));
              }}
              onSelect={(_, { node: { key } }) => {
                onItemSelect(key, !isChecked(checkedKeys, key));
              }}
            />
          );
        }
      }}
    </Transfer>
  );
};

const treeData = [
  { key: '0-0', title: '0-0' },
  {
    key: '0-1',
    title: '0-1',
    children: [
      { key: '0-1-0', title: '0-1-0' },
      { key: '0-1-1', title: '0-1-1' },
    ],
  },
  { key: '0-2', title: '0-3' },
];

const App = (props) => {
  const [targetKeys, setTargetKeys] = useState([]);
  const [treeData, setTreeData] = useState(null);
  const onChange = (keys) => {
    setTargetKeys(keys);
    console.log(keys);
    getInfosByIds({
      ids: '07,' + keys,
    }).then((res) => {
      console.log(res);
      const result = res?.body?.infosByIds ? res?.body?.infosByIds : res.body;
      props.transferSecond(result ? result : []);
    });
  };
  // 数据加载
  useEffect(() => {
    console.log(props.selectedKeys);
    getDatas();
  }, []);

  /**
   * 数据查询
   * @param params 查询的参数对象
   */
  const getDatas = (params) => {
    // getListOrgTrees({}).then(res=>{
    //   console.log(res);
    //   setTreeData(res.body)
    // })
    setTreeData(props.treeData);
    setTargetKeys(props.selectedKeys);
  };

  return (
    <>
      {treeData ? (
        <TreeTransfer
          dataSource={treeData}
          targetKeys={targetKeys}
          onChange={onChange}
          //  selectedKeys={['0-2']}
        />
      ) : (
        '加载中...'
      )}
    </>
  );
};
