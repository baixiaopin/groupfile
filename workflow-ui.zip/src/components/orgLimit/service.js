import request from '../../utils/request';

// 获取机构树
export function getListOrgTrees(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'OrgManagementSVC',
        stdIntfcInd: 'getListOrgTrees',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}

// 查询回显
export function getInfosByIds(data) {
  return request('', {
    data: {
      sysHead: {
        stdSvcInd: processEnvORGANIZATIONALDesign + 'CommonManagementSVC',
        stdIntfcInd: 'getInfosByIds',
        stdIntfcVerNo: '1.0.0',
        srcConsmSysInd: processEnvORGANIZATIONALSrcConsmSysInd,
      },
      localHead: {},
      body: data,
    },
  });
}
