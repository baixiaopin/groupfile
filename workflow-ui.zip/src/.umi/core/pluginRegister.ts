// @ts-nocheck
import { plugin } from './plugin';


export const __mfsu = 1;
