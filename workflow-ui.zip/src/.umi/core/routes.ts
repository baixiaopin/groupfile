// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from 'D:/工作流/workflow-ui/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/~demos/:uuid",
    "layout": false,
    "wrappers": [require('../dumi/layout').default],
    "component": ((props) => {
        const React = require('react');
        const { default: getDemoRenderArgs } = require('D:/工作流/workflow-ui/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
        const { default: Previewer } = require('dumi-theme-default/es/builtins/Previewer.js');
        const { usePrefersColor, context } = require('dumi/theme');

        
      const { demos } = React.useContext(context);
      const [renderArgs, setRenderArgs] = React.useState([]);

      // update render args when props changed
      React.useLayoutEffect(() => {
        setRenderArgs(getDemoRenderArgs(props, demos));
      }, [props.match.params.uuid, props.location.query.wrapper, props.location.query.capture]);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
        })
  },
  {
    "path": "/_demos/:uuid",
    "redirect": "/~demos/:uuid"
  },
  {
    "__dumiRoot": true,
    "layout": false,
    "path": "/",
    "wrappers": [require('../dumi/layout').default, require('D:/工作流/workflow-ui/node_modules/dumi-theme-default/es/layout.js').default],
    "routes": [
      {
        "path": "/",
        "component": require('../../../README.md').default,
        "exact": true,
        "meta": {
          "locale": "en-US",
          "order": null,
          "filePath": "README.md",
          "updatedTime": 1660094547000,
          "slugs": [
            {
              "depth": 1,
              "value": "流程引擎组件",
              "heading": "流程引擎组件"
            },
            {
              "depth": 2,
              "value": "环境变量",
              "heading": "环境变量"
            }
          ],
          "title": "流程引擎组件"
        },
        "title": "流程引擎组件"
      },
      {
        "path": "/authorized-to-do",
        "component": require('../../../docs/AuthorizedToDo.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/AuthorizedToDo.md",
          "updatedTime": 1611888268000,
          "title": "授权待办",
          "order": 9,
          "slugs": [
            {
              "depth": 1,
              "value": "授权待办（AuthorizedToDo）",
              "heading": "授权待办authorizedtodo"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "授权待办 - ngdf-engine-ui"
      },
      {
        "path": "/businesses-design",
        "component": require('../../../docs/BusinessesDesign.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/BusinessesDesign.md",
          "updatedTime": 1693274677000,
          "title": "业务流程设计器",
          "order": 14,
          "slugs": [
            {
              "depth": 1,
              "value": "业务流程设计器（BusinessesModelar）",
              "heading": "业务流程设计器businessesmodelar"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "业务流程设计器 - ngdf-engine-ui"
      },
      {
        "path": "/businesses-template",
        "component": require('../../../docs/BusinessesTemplate.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/BusinessesTemplate.md",
          "updatedTime": 1618457225000,
          "title": "业务流程模板",
          "order": "8 // <OrgTree transfer={this.click} />",
          "slugs": [
            {
              "depth": 1,
              "value": "业务流程模板（BusinessesTemplate）",
              "heading": "业务流程模板businessestemplate"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "业务流程模板 - ngdf-engine-ui"
      },
      {
        "path": "/businesses-viewer",
        "component": require('../../../docs/BusinessesViewer.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/BusinessesViewer.md",
          "updatedTime": 1693274677000,
          "title": "业务流程预览",
          "order": 15,
          "slugs": [
            {
              "depth": 1,
              "value": "授权待办（BusinessesViewer）",
              "heading": "授权待办businessesviewer"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "业务流程预览 - ngdf-engine-ui"
      },
      {
        "path": "/business-type",
        "component": require('../../../docs/BusinessType.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/BusinessType.md",
          "updatedTime": 1618313498000,
          "title": "业务类型管理",
          "order": "8 // <OrgTree transfer={this.click} />",
          "slugs": [
            {
              "depth": 1,
              "value": "业务类型管理（bussinessConfig）",
              "heading": "业务类型管理bussinessconfig"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "业务类型管理 - ngdf-engine-ui"
      },
      {
        "path": "/data-migration",
        "component": require('../../../docs/DataMigration.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/DataMigration.md",
          "updatedTime": 1618313498000,
          "title": "数据迁移",
          "order": 9,
          "slugs": [
            {
              "depth": 1,
              "value": "数据迁移（DataMigration）",
              "heading": "数据迁移datamigration"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "数据迁移 - ngdf-engine-ui"
      },
      {
        "path": "/history-process-instance",
        "component": require('../../../docs/HistoryProcessInstance.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/HistoryProcessInstance.md",
          "updatedTime": 1607755037000,
          "title": "历史流程实例",
          "order": 3,
          "slugs": [
            {
              "depth": 1,
              "value": "历史流程实例（HistoryProcessInstance）",
              "heading": "历史流程实例historyprocessinstance"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "历史流程实例 - ngdf-engine-ui"
      },
      {
        "path": "/history-task",
        "component": require('../../../docs/HistoryTask.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/HistoryTask.md",
          "updatedTime": 1618313498000,
          "title": "历史任务",
          "order": 10,
          "slugs": [
            {
              "depth": 1,
              "value": "历史任务（HistoryTask）",
              "heading": "历史任务historytask"
            }
          ],
          "hasPreviewer": true
        },
        "title": "历史任务 - ngdf-engine-ui"
      },
      {
        "path": "/model-designer",
        "component": require('../../../docs/ModelDesigner.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/ModelDesigner.md",
          "updatedTime": 1603868085000,
          "title": "模型设计器",
          "order": 3,
          "slugs": [
            {
              "depth": 1,
              "value": "模型设计器（ModelDesigner）",
              "heading": "模型设计器modeldesigner"
            }
          ]
        },
        "title": "模型设计器 - ngdf-engine-ui"
      },
      {
        "path": "/model-manage",
        "component": require('../../../docs/ModelManage.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/ModelManage.md",
          "updatedTime": 1648458788000,
          "title": "模型管理",
          "order": 2,
          "slugs": [
            {
              "depth": 1,
              "value": "模型管理（ModelManage）",
              "heading": "模型管理modelmanage"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "模型管理 - ngdf-engine-ui"
      },
      {
        "path": "/model-type",
        "component": require('../../../docs/ModelType.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/ModelType.md",
          "updatedTime": 1607755037000,
          "title": "模型类型",
          "order": 1,
          "slugs": [
            {
              "depth": 1,
              "value": "模型类型（ModelType）",
              "heading": "模型类型modeltype"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "模型类型 - ngdf-engine-ui"
      },
      {
        "path": "/model-viewer",
        "component": require('../../../docs/ModelViewer.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/ModelViewer.md",
          "updatedTime": 1618313498000,
          "title": "模型查看器",
          "order": 4,
          "slugs": [
            {
              "depth": 1,
              "value": "模型查看器（ModelViewer）",
              "heading": "模型查看器modelviewer"
            }
          ]
        },
        "title": "模型查看器 - ngdf-engine-ui"
      },
      {
        "path": "/process-continue-run",
        "component": require('../../../docs/ProcessContinueRun.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/ProcessContinueRun.md",
          "updatedTime": 1642987208000,
          "title": "流程续跑",
          "order": 10,
          "slugs": [
            {
              "depth": 1,
              "value": "流程续跑（ProcessContinueRun）",
              "heading": "流程续跑processcontinuerun"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "流程续跑 - ngdf-engine-ui"
      },
      {
        "path": "/process-instance",
        "component": require('../../../docs/ProcessInstance.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/ProcessInstance.md",
          "updatedTime": 1618313498000,
          "title": "流程实例",
          "order": 5,
          "slugs": [
            {
              "depth": 1,
              "value": "流程实例（ProcessInstance）",
              "heading": "流程实例processinstance"
            },
            {
              "depth": 1,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "流程实例 - ngdf-engine-ui"
      },
      {
        "path": "/process-task",
        "component": require('../../../docs/ProcessTask.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/ProcessTask.md",
          "updatedTime": 1618313498000,
          "title": "流程任务",
          "order": 6,
          "slugs": [
            {
              "depth": 1,
              "value": "流程任务（ProcessTask）",
              "heading": "流程任务processtask"
            },
            {
              "depth": 2,
              "value": "代码演示",
              "heading": "代码演示"
            }
          ],
          "hasPreviewer": true
        },
        "title": "流程任务 - ngdf-engine-ui"
      }
    ],
    "title": "ngdf-engine-ui",
    "component": (props) => props.children
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
