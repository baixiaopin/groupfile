// @ts-nocheck
import React from 'react';
import { dynamic } from 'dumi';

export default {
  'AuthorizedToDo-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.AuthorizedToDo, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { AuthorizedToDo } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <AuthorizedToDo />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"AuthorizedToDo-demo"},
  },
  'BusinessesDesign-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      var _this;

      (0, _classCallCheck2["default"])(this, Demo);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));
      _this.state = {};
      return _this;
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.BusinessesModelar, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { BusinessesModelar } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  state = {};\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <BusinessesModelar />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"BusinessesDesign-demo"},
  },
  'BusinessesTemplate-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      var _this;

      (0, _classCallCheck2["default"])(this, Demo);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));

      _this.click = function (e) {
        console.log(e);
      };

      _this.transferSelectType = function (e) {
        console.log(e);
      };

      return _this;
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.BusinessesTemplate, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { ModelManage, OrgTree, BusinessesTemplate } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  click = (e) => {\n    console.log(e);\n  };\n  transferSelectType = (e) => {\n    console.log(e);\n  };\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <BusinessesTemplate />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"BusinessesTemplate-demo"},
  },
  'BusinessesViewer-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      var _this;

      (0, _classCallCheck2["default"])(this, Demo);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));
      _this.state = {
        nodeConfig: {
          activityId: 'sid-start-node',
          nodeName: '章子航',
          type: '00',
          assignee: '王未',
          conditionList: [],
          nodeUserList: [],
          childNode: {
            activityId: 'ActId1692006171820',
            nodeName: '图标管理员',
            type: '01',
            assignee: '张三',
            conditionList: [],
            nodeUserList: [],
            childNode: {
              activityId: 'ActId1692006189555gatWay',
              childNode: null,
              nodeName: '路由',
              type: '04',
              conditionNodes: [{
                activityId: 'ActId1692006189555condition1',
                conditionList: [],
                nodeName: '请设置条件',
                nodeUserList: [],
                type: '03',
                childNode: {
                  activityId: 'ActId1692006192323',
                  childNode: null,
                  error: true,
                  nodeName: '审核人添加',
                  nodeUserList: [],
                  type: '01'
                }
              }, {
                activityId: 'ActId1692006189555condition2',
                conditionList: [],
                nodeName: '请设置条件',
                nodeUserList: [],
                type: '03',
                childNode: {
                  activityId: 'ActId169200619232',
                  childNode: null,
                  error: true,
                  nodeName: '审核人添加',
                  nodeUserList: [],
                  type: '02'
                }
              }]
            },
            conditionNodes: []
          },
          conditionNodes: []
        }
      };
      return _this;
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.BusinessesViewer, {
          businessViewer: this.state.nodeConfig,
          taskData: {
            ActId1692006171820: {
              status: '1',
              numOfExecution: '1'
            }
          }
        }));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { BusinessesViewer } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  state = {\n    nodeConfig: {\n      activityId: 'sid-start-node',\n      nodeName: '章子航',\n      type: '00',\n      assignee: '王未',\n      conditionList: [],\n      nodeUserList: [],\n      childNode: {\n        activityId: 'ActId1692006171820',\n        nodeName: '图标管理员',\n        type: '01',\n        assignee: '张三',\n        conditionList: [],\n        nodeUserList: [],\n        childNode: {\n          activityId: 'ActId1692006189555gatWay',\n          childNode: null,\n          nodeName: '路由',\n          type: '04',\n          conditionNodes: [\n            {\n              activityId: 'ActId1692006189555condition1',\n              conditionList: [],\n              nodeName: '请设置条件',\n              nodeUserList: [],\n              type: '03',\n              childNode: {\n                activityId: 'ActId1692006192323',\n                childNode: null,\n                error: true,\n                nodeName: '审核人添加',\n                nodeUserList: [],\n                type: '01',\n              },\n            },\n            {\n              activityId: 'ActId1692006189555condition2',\n              conditionList: [],\n              nodeName: '请设置条件',\n              nodeUserList: [],\n              type: '03',\n              childNode: {\n                activityId: 'ActId169200619232',\n                childNode: null,\n                error: true,\n                nodeName: '审核人添加',\n                nodeUserList: [],\n                type: '02',\n              },\n            },\n          ],\n        },\n        conditionNodes: [],\n      },\n      conditionNodes: [],\n    },\n  };\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <BusinessesViewer\n          businessViewer={this.state.nodeConfig}\n          taskData={{\n            ActId1692006171820: { status: '1', numOfExecution: '1' },\n          }}\n        />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"BusinessesViewer-demo"},
  },
  'BusinessType-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      var _this;

      (0, _classCallCheck2["default"])(this, Demo);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));

      _this.click = function (e) {
        console.log(e);
      };

      _this.transferSelectType = function (e) {
        console.log(e);
      };

      return _this;
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.BusinessesTypeManage, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { ModelManage, OrgTree, BusinessesTypeManage } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  click = (e) => {\n    console.log(e);\n  };\n  transferSelectType = (e) => {\n    console.log(e);\n  };\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <BusinessesTypeManage />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"BusinessType-demo"},
  },
  'DataMigration-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.DataMigration, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { DataMigration } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <DataMigration />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"DataMigration-demo"},
  },
  'HistoryProcessInstance-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.HistoryProcessInstance, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { HistoryProcessInstance } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <HistoryProcessInstance />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"HistoryProcessInstance-demo"},
  },
  'HistoryTask-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.HistoryTask, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { HistoryTask } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <HistoryTask />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"HistoryTask-demo"},
  },
  'ModelManage-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      var _this;

      (0, _classCallCheck2["default"])(this, Demo);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));

      _this.click = function (e) {
        console.log(e);
      };

      _this.transferSelectType = function (e) {
        console.log(e);
      };

      return _this;
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.ModelManage, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { ModelManage, OrgTree } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  click = (e) => {\n    console.log(e);\n  };\n  transferSelectType = (e) => {\n    console.log(e);\n  };\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <ModelManage />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"ModelManage-demo"},
  },
  'ModelType-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.ModelType, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { ModelType } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <ModelType />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"ModelType-demo"},
  },
  'ProcessContinueRun-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.ProcessContinueRun, {
          stdSvcInd: "BaseBusinessTaskSVC",
          stdIntfcInd: "processInstanceContinueRunning",
          srcConsmSysInd: "NGCMSS",
          stdIntfcVerNo: "1.0.0"
        }));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { ProcessContinueRun } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <ProcessContinueRun\n          stdSvcInd=\"BaseBusinessTaskSVC\"\n          stdIntfcInd=\"processInstanceContinueRunning\"\n          srcConsmSysInd=\"NGCMSS\"\n          stdIntfcVerNo=\"1.0.0\"\n        />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"ProcessContinueRun-demo"},
  },
  'ProcessInstance-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.ProcessInstance, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { ProcessInstance } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <ProcessInstance />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"ProcessInstance-demo"},
  },
  'ProcessTask-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _classCallCheck2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/classCallCheck"));

  var _createClass2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createClass"));

  var _inherits2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/inherits"));

  var _createSuper2 = _interopRequireDefault(require("D:/\u5DE5\u4F5C\u6D41/workflow-ui/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/esm/createSuper"));

  var _react = _interopRequireDefault(require("react"));

  var _ngdfEngineUi = require("ngdf-engine-ui");

  var Demo = /*#__PURE__*/function (_React$Component) {
    (0, _inherits2["default"])(Demo, _React$Component);

    var _super = (0, _createSuper2["default"])(Demo);

    function Demo() {
      (0, _classCallCheck2["default"])(this, Demo);
      return _super.apply(this, arguments);
    }

    (0, _createClass2["default"])(Demo, [{
      key: "render",
      value: function render() {
        return /*#__PURE__*/_react["default"].createElement("div", {
          style: {
            backgroundColor: '#f0f2f5',
            padding: 16
          }
        }, /*#__PURE__*/_react["default"].createElement(_ngdfEngineUi.ProcessTask, null));
      }
    }]);
    return Demo;
  }(_react["default"].Component);

  return _react["default"].createElement(Demo);
},
    previewerProps: {"sources":{"_":{"jsx":"import React from 'react';\nimport { ProcessTask } from 'ngdf-engine-ui';\n\nexport default class Demo extends React.Component {\n  render() {\n    return (\n      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>\n        <ProcessTask />\n      </div>\n    );\n  }\n}"}},"dependencies":{"react":{"version":"16.14.0"},"ngdf-engine-ui":{"version":"1.3.16"}},"identifier":"ProcessTask-demo"},
  },
};
