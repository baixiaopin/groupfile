export var xmlStr = `
<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:omgdi="http://www.omg.org/spec/DD/20100524/DI" xmlns:omgdc="http://www.omg.org/spec/DD/20100524/DC" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="sid-38422fae-e03e-43a3-bef4-bd33b32041b2" targetNamespace="http://bpmn.io/bpmn" exporter="bpmn-js (https://demo.bpmn.io)" exporterVersion="5.1.2">
  <process id="Process_1" isExecutable="false">
    <startEvent id="StartEvent_1y45yut" name="开始">
      <outgoing>Flow_1spzq9d</outgoing>
    </startEvent>
    <userTask id="Activity_1ifwu4r" name="用户任务" flowable:assignee="6">
      <incoming>Flow_1spzq9d</incoming>
      <outgoing>Flow_10gop2t</outgoing>
    </userTask>
    <sequenceFlow id="Flow_1spzq9d" sourceRef="StartEvent_1y45yut" targetRef="Activity_1ifwu4r" />
    <endEvent id="Event_0fw54nb" name="结束">
      <incoming>Flow_10gop2t</incoming>
    </endEvent>
    <sequenceFlow id="Flow_10gop2t" sourceRef="Activity_1ifwu4r" targetRef="Event_0fw54nb" />
  </process>
  <bpmndi:BPMNDiagram id="BpmnDiagram_1">
    <bpmndi:BPMNPlane id="BpmnPlane_1" bpmnElement="Process_1">
      <bpmndi:BPMNEdge id="Flow_10gop2t_di" bpmnElement="Flow_10gop2t">
        <omgdi:waypoint x="210" y="75" />
        <omgdi:waypoint x="210" y="109" />
        <omgdi:waypoint x="83" y="109" />
        <omgdi:waypoint x="83" y="142" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1spzq9d_di" bpmnElement="Flow_1spzq9d">
        <omgdi:waypoint x="0" y="-10" />
        <omgdi:waypoint x="83" y="-10" />
        <omgdi:waypoint x="83" y="40" />
        <omgdi:waypoint x="165" y="40" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNShape id="StartEvent_1y45yut_di" bpmnElement="StartEvent_1y45yut">
        <omgdc:Bounds x="-40" y="-30" width="40" height="40" />
        <bpmndi:BPMNLabel>
          <omgdc:Bounds x="-31" y="13" width="22" height="14" font-size="22px" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1ifwu4r_di" bpmnElement="Activity_1ifwu4r">
        <omgdc:Bounds x="165" y="5" width="90" height="70" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_0fw54nb_di" bpmnElement="Event_0fw54nb">
        <omgdc:Bounds x="65" y="142" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <omgdc:Bounds x="72" y="185" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
`;
