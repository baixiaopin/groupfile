---
title: 流程任务
order: 6
---

# 流程任务（ProcessTask）

## 代码演示

```jsx
import React from 'react';
import { ProcessTask } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <ProcessTask />
      </div>
    );
  }
}
```
