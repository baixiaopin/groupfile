---
title: 模型类型
order: 1
---

# 模型类型（ModelType）

## 代码演示

```jsx
import React from 'react';
import { ModelType } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <ModelType />
      </div>
    );
  }
}
```
