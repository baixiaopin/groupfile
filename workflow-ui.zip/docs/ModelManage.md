---
title: 模型管理
order: 2
---

# 模型管理（ModelManage）

## 代码演示

```jsx
import React from 'react';
import { ModelManage, OrgTree } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  click = (e) => {
    console.log(e);
  };
  transferSelectType = (e) => {
    console.log(e);
  };
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <ModelManage />
      </div>
    );
  }
}
```
