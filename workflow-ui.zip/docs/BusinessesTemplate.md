---
title: 业务流程模板
order: 8
  // <OrgTree transfer={this.click} />
---

# 业务流程模板（BusinessesTemplate）

## 代码演示

```jsx
import React from 'react';
import { ModelManage, OrgTree, BusinessesTemplate } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  click = (e) => {
    console.log(e);
  };
  transferSelectType = (e) => {
    console.log(e);
  };
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <BusinessesTemplate />
      </div>
    );
  }
}
```
