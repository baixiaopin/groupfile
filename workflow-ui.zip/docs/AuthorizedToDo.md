---
title: 授权待办
order: 9
---

# 授权待办（AuthorizedToDo）

## 代码演示

```jsx
import React from 'react';
import { AuthorizedToDo } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <AuthorizedToDo />
      </div>
    );
  }
}
```
