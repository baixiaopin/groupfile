---
title: 业务流程预览
order: 15
---

# 授权待办（BusinessesViewer）

## 代码演示

```jsx
import React from 'react';
import { BusinessesViewer } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  state = {
    nodeConfig: {
      activityId: 'sid-start-node',
      nodeName: '章子航',
      type: '00',
      assignee: '王未',
      conditionList: [],
      nodeUserList: [],
      childNode: {
        activityId: 'ActId1692006171820',
        nodeName: '图标管理员',
        type: '01',
        assignee: '张三',
        conditionList: [],
        nodeUserList: [],
        childNode: {
          activityId: 'ActId1692006189555gatWay',
          childNode: null,
          nodeName: '路由',
          type: '04',
          conditionNodes: [
            {
              activityId: 'ActId1692006189555condition1',
              conditionList: [],
              nodeName: '请设置条件',
              nodeUserList: [],
              type: '03',
              childNode: {
                activityId: 'ActId1692006192323',
                childNode: null,
                error: true,
                nodeName: '审核人添加',
                nodeUserList: [],
                type: '01',
              },
            },
            {
              activityId: 'ActId1692006189555condition2',
              conditionList: [],
              nodeName: '请设置条件',
              nodeUserList: [],
              type: '03',
              childNode: {
                activityId: 'ActId169200619232',
                childNode: null,
                error: true,
                nodeName: '审核人添加',
                nodeUserList: [],
                type: '02',
              },
            },
          ],
        },
        conditionNodes: [],
      },
      conditionNodes: [],
    },
  };
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <BusinessesViewer
          businessViewer={this.state.nodeConfig}
          taskData={{
            ActId1692006171820: { status: '1', numOfExecution: '1' },
          }}
        />
      </div>
    );
  }
}
```
