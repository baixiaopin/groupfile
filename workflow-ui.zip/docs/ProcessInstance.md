---
title: 流程实例
order: 5
---

# 流程实例（ProcessInstance）

# 代码演示

```jsx
import React from 'react';
import { ProcessInstance } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <ProcessInstance />
      </div>
    );
  }
}
```
