---
title: 数据迁移
order: 9
---

# 数据迁移（DataMigration）

## 代码演示

```jsx
import React from 'react';
import { DataMigration } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <DataMigration />
      </div>
    );
  }
}
```
