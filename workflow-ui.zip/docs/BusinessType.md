---
title: 业务类型管理
order: 8
  // <OrgTree transfer={this.click} />
---

# 业务类型管理（bussinessConfig）

## 代码演示

```jsx
import React from 'react';
import { ModelManage, OrgTree, BusinessesTypeManage } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  click = (e) => {
    console.log(e);
  };
  transferSelectType = (e) => {
    console.log(e);
  };
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <BusinessesTypeManage />
      </div>
    );
  }
}
```
