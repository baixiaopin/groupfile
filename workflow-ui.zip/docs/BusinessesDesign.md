---
title: 业务流程设计器
order: 14
---

# 业务流程设计器（BusinessesModelar）

## 代码演示

```jsx
import React from 'react';
import { BusinessesModelar } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  state = {};
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <BusinessesModelar />
      </div>
    );
  }
}
```
