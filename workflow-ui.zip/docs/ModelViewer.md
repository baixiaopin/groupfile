---
title: 模型查看器
order: 4
---

# 模型查看器（ModelViewer）

暂不可单独使用，需配合模型管理，传入模型 ID 参数使用。
