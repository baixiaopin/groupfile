---
title: 流程续跑
order: 10
---

# 流程续跑（ProcessContinueRun）

## 代码演示

```jsx
import React from 'react';
import { ProcessContinueRun } from 'ngdf-engine-ui';

export default class Demo extends React.Component {
  render() {
    return (
      <div style={{ backgroundColor: '#f0f2f5', padding: 16 }}>
        <ProcessContinueRun
          stdSvcInd="BaseBusinessTaskSVC"
          stdIntfcInd="processInstanceContinueRunning"
          srcConsmSysInd="NGCMSS"
          stdIntfcVerNo="1.0.0"
        />
      </div>
    );
  }
}
```
