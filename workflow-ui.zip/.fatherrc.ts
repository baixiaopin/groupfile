import commonjs from '@rollup/plugin-commonjs';
import url from '@rollup/plugin-url';

export default {
  esm: 'rollup',
  cjs: 'rollup',
  extraRollupPlugins: [
    commonjs(),
    url({
      limit: 0,
    }),
  ],
};
