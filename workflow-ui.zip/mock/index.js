export default {
  'POST /agrs': (req, res) => {
    console.log(req);
  },
};
