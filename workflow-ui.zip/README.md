# 流程引擎组件

## 环境变量

在使用本组件前，请务必先在 `.umirc.ts` 中配置以下环境变量：

```typescript
export default {
  ...
  define: {
    // 组织架构树 项目标识前缀
   'processEnvORGANIZATIONALDesign':'Cms',
   // 组织架构树 应用标识
   'processEnvORGANIZATIONALSrcConsmSysInd':'NGCMSS',
   NGFE_REQUEST: {
     // 开发环境是否开启 mock
     mock: false,
     // sit2
     baseUrl: 'http://107.255.18.20:9098',
     // 设置需配置在 http header 中 aacCode（能力中心），询问项目经理/后端获取
     headerAacCode: '823',
     // 设置需配置在 http header 中 cadCode（能力域），询问项目经理/后端获取
     headerCadCode: '999998',
     openInMfeb: false,
     /** 是否动态配置后台网关地址 默认动态配置 true*/
     dynamicUrl: false,
   },
  },
  ...
};
```
