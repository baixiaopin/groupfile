import { defineConfig } from 'dumi';
import path from 'path';
export default defineConfig({
  title: 'ngdf-engine-ui',
  outputPath: 'docs-dist',
  nodeModulesTransform: {
    type: 'all',
  },
  targets: { ie: 11 },
  history: { type: 'hash' },
  define: {
    // // 组织架构树
    // 'process.env.ORGANIZATIONAL_STRUCTURE_TREE_REQUEST_BASE_URL':
    //   'http://107.255.18.20:9098/agrs',
    // // 组织架构树自定义 用户服务名
    // 'process.env.ORGANIZATIONAL_UserManagementSVC': 'CmsUserManagementSVC',
    // // 组织架构树自定义 角色服务名
    // 'process.env.ORGANIZATIONAL_RoleManagementSVC': 'CmsRoleManagementSVC',
    // // 组织架构树自定义 岗位服务名
    // 'process.env.ORGANIZATIONAL_OrgManagementSVC': 'CmsOrgManagementSVC',
    // // 组织架构树自定义 部门服务名
    // 'process.env.ORGANIZATIONAL_PositionManagementSVC':
    //   'CmsPositionManagementSVC',
    // // 组织架构树自定义 根据id回显
    // 'process.env.ORGANIZATIONAL_CommonManagementSVC': 'CmsCommonManagementSVC',
    // // 工作流引擎请求头变量能力域，能力中心
    // header_parameter_variable_cadCode: '999998',
    // header_parameter_variable_aacCode: '823',
    // // 组织架构树请求头能力域能力中心,应用标识
    // orgheader_parameter_variable_aacCode: '823',
    // orgheader_parameter_variable_cadCode: '999998',
    // orgHeader_parameter_variable_appCode: 'NGCMSS',
    // // 网关
    // 'process.env.WORKFLOW_UI_REQUEST_BASE_URL':
    //   'http://107.255.18.20:9098/agrs',
    // // 判断本地开发环境还是生产环境development production
    // 'process.env.WORKFLOW_UI.MODEL': 'production',

    // 组织架构树 项目标识
    processEnvORGANIZATIONALDesign: 'Cms',
    // 组织架构树 应用标识
    processEnvORGANIZATIONALSrcConsmSysInd: 'NGCMSS',
    NGFE_REQUEST: {
      // 开发环境是否开启 mock
      mock: false,
      // sit2
      baseUrl: 'http://107.255.18.20:9098',
      // 设置需配置在 http header 中 aacCode（能力中心），询问项目经理/后端获取
      headerAacCode: '823',
      // 设置需配置在 http header 中 cadCode（能力域），询问项目经理/后端获取
      headerCadCode: '999998',
      openInMfeb: false,
      /** 是否动态配置后台网关地址 默认动态配置 true*/
      dynamicUrl: false,
      chnlNo: '080032',
    },
  },
  // more config: https://d.umijs.org/config
  chainWebpack(memo, { env, webpack, createCSSRule }) {
    memo.module
      .rule('bpmn')
      .test(/\.bpmn$/)
      .use('raw')
      .loader('raw-loader');
    memo.module
      .rule('bpmnlintrc')
      .test(/\.bpmnlintrc$/)
      .use('raw')
      .loader('bpmnlint-loader');
  },
});
